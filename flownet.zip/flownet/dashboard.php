<?php
require_once 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];
$fullName = $_SESSION['full_name'];
$userRole = $_SESSION['role'] ?? 'user';
$userAvatar = $_SESSION['avatar'] ?? null;

// Ambil semua file user
$stmt = $conn->prepare("SELECT * FROM files WHERE user_id = ? ORDER BY uploaded_at DESC");
$stmt->execute([$userId]);
$myFiles = $stmt->fetchAll();

// Ambil file yang dibagikan ke user
$stmt = $conn->prepare("
    SELECT f.*, u.username as owner_username, sf.shared_at, sf.can_download 
    FROM files f 
    JOIN shared_files sf ON f.id = sf.file_id 
    JOIN users u ON f.user_id = u.id 
    WHERE sf.shared_with = ? 
    ORDER BY sf.shared_at DESC
");
$stmt->execute([$userId]);
$sharedFiles = $stmt->fetchAll();

// Hitung total storage
$stmt = $conn->prepare("SELECT SUM(file_size) as total_size FROM files WHERE user_id = ?");
$stmt->execute([$userId]);
$totalStorage = $stmt->fetch()['total_size'] ?? 0;

// Hitung jumlah file
$totalFiles = count($myFiles);

// Storage limit (example: 10GB)
$storageLimit = 10 * 1024 * 1024 * 1024;
$storagePercent = ($totalStorage / $storageLimit) * 100;

// Get storage by file type
$stmt = $conn->prepare("SELECT original_name, file_size FROM files WHERE user_id = ?");
$stmt->execute([$userId]);
$allFiles = $stmt->fetchAll();

$storageByType = [
    'Images' => 0,
    'Videos' => 0,
    'Audio' => 0,
    'Documents' => 0,
    'Archives' => 0,
    'Others' => 0
];

foreach ($allFiles as $file) {
    $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
    $size = $file['file_size'];
    
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])) {
        $storageByType['Images'] += $size;
    } elseif (in_array($ext, ['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv'])) {
        $storageByType['Videos'] += $size;
    } elseif (in_array($ext, ['mp3', 'wav', 'ogg', 'flac', 'm4a'])) {
        $storageByType['Audio'] += $size;
    } elseif (in_array($ext, ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'])) {
        $storageByType['Documents'] += $size;
    } elseif (in_array($ext, ['zip', 'rar', '7z', 'tar', 'gz'])) {
        $storageByType['Archives'] += $size;
    } else {
        $storageByType['Others'] += $size;
    }
}

// Get recent files (last 6)
$recentFiles = array_slice($myFiles, 0, 6);

$successMsg = $_SESSION['success'] ?? '';
$errorMsg = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - FlowNet Cloud Storage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <style>
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        :root {
            --bg-primary: #0f172a;
            --bg-secondary: #1e293b;
            --bg-card: #1e293b;
            --bg-hover: #334155;
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
            --text-muted: #94a3b8;
            --accent-blue: #3b82f6;
            --accent-purple: #8b5cf6;
            --accent-green: #10b981;
            --accent-orange: #f59e0b;
            --accent-red: #ef4444;
            --border-color: rgba(148, 163, 184, 0.12);
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.3);
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
            --shadow-lg: 0 10px 25px -3px rgba(0, 0, 0, 0.5);
        }
        
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1a1f35 100%);
            color: var(--text-primary);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', sans-serif;
            min-height: 100vh;
            font-size: 14px;
            line-height: 1.5;
        }
        
        /* Top Navbar */
        .top-navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 64px;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            padding: 0 1.5rem;
            z-index: 1000;
            box-shadow: var(--shadow);
        }
        
        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 0.625rem;
            text-decoration: none;
            margin-right: 2.5rem;
        }
        
        .navbar-brand i {
            font-size: 1.5rem;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .navbar-brand h4 {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .navbar-menu {
            display: flex;
            align-items: center;
            gap: 0.25rem;
            flex: 1;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.2s;
            font-weight: 500;
            font-size: 0.875rem;
            white-space: nowrap;
        }
        
        .nav-link:hover {
            background: rgba(59, 130, 246, 0.1);
            color: var(--accent-blue);
        }
        
        .nav-link.active {
            background: rgba(59, 130, 246, 0.15);
            color: var(--accent-blue);
        }
        
        .nav-link i {
            font-size: 1rem;
        }
        
        .nav-badge {
            background: var(--accent-blue);
            color: white;
            padding: 0.125rem 0.375rem;
            border-radius: 10px;
            font-size: 0.6875rem;
            font-weight: 600;
            min-width: 18px;
            text-align: center;
        }
        
        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-left: auto;
        }
        
        .search-box {
            position: relative;
        }
        
        .search-box input {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 0.5rem 1rem 0.5rem 2.25rem;
            border-radius: 6px;
            width: 240px;
            transition: all 0.2s;
            font-size: 0.875rem;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            width: 280px;
        }
        
        .search-box input::placeholder {
            color: var(--text-muted);
        }
        
        .search-box i {
            position: absolute;
            left: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 0.875rem;
        }
        
        .file-item.hidden {
            display: none;
        }
        
        .btn-upload {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            color: white;
            border: none;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }
        
        .btn-upload:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        
        .storage-indicator {
            display: flex;
            align-items: center;
            gap: 0.625rem;
            padding: 0.375rem 0.875rem;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .storage-indicator:hover {
            border-color: var(--accent-blue);
            background: rgba(59, 130, 246, 0.05);
        }
        
        .storage-circle {
            width: 36px;
            height: 36px;
            position: relative;
        }
        
        .storage-info {
            display: flex;
            flex-direction: column;
            gap: 0.125rem;
        }
        
        .storage-label {
            font-size: 0.625rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        
        .storage-value {
            font-size: 0.8125rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 0.625rem;
            padding: 0.375rem 0.75rem;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .user-menu:hover {
            border-color: var(--accent-blue);
            background: rgba(59, 130, 246, 0.05);
        }
        
        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            font-size: 0.875rem;
        }
        
        .user-info {
            display: flex;
            flex-direction: column;
            gap: 0;
        }
        
        .user-name {
            font-size: 0.8125rem;
            font-weight: 600;
            color: var(--text-primary);
            line-height: 1.2;
        }
        
        .user-role {
            font-size: 0.625rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Main Content */
        .main-content {
            margin-top: 64px;
            padding: 2rem;
            max-width: 1600px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Page Header */
        .page-header {
            margin-bottom: 2rem;
        }
        
        .page-title {
            font-size: 1.875rem;
            font-weight: 700;
            color: var(--text-primary);
            margin: 0 0 0.375rem 0;
            letter-spacing: -0.025em;
        }
        
        .page-subtitle {
            color: var(--text-muted);
            font-size: 0.9375rem;
        }
        
        /* Alerts */
        .alert-custom {
            padding: 0.875rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border: 1px solid;
            animation: slideDown 0.3s ease-out;
            font-size: 0.875rem;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border-color: rgba(16, 185, 129, 0.3);
            color: var(--accent-green);
        }
        
        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
            color: var(--accent-red);
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.25rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 1.5rem;
            transition: all 0.2s;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
            opacity: 0;
            transition: opacity 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            border-color: rgba(59, 130, 246, 0.3);
        }
        
        .stat-card:hover::before {
            opacity: 1;
        }
        
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .stat-icon.blue { background: rgba(59, 130, 246, 0.15); color: var(--accent-blue); }
        .stat-icon.green { background: rgba(16, 185, 129, 0.15); color: var(--accent-green); }
        .stat-icon.purple { background: rgba(139, 92, 246, 0.15); color: var(--accent-purple); }
        .stat-icon.orange { background: rgba(245, 158, 11, 0.15); color: var(--accent-orange); }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
            letter-spacing: -0.025em;
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-bottom: 0.625rem;
            font-weight: 500;
        }
        
        .stat-change {
            font-size: 0.75rem;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-weight: 600;
        }
        
        .stat-change.positive {
            background: rgba(16, 185, 129, 0.15);
            color: var(--accent-green);
        }
        
        /* Content Grid */
        .content-grid {
            display: grid;
            grid-template-columns: 1.6fr 1fr;
            gap: 1.25rem;
            margin-bottom: 2rem;
        }
        
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: var(--shadow-sm);
        }
        
        .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.25rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .chart-container {
            height: 300px;
        }
        
        /* Recent Files */
        .file-item {
            display: flex;
            align-items: center;
            gap: 0.875rem;
            padding: 0.875rem;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            margin-bottom: 0.625rem;
            transition: all 0.2s;
            cursor: pointer;
        }
        
        .file-item:last-child {
            margin-bottom: 0;
        }
        
        .file-item:hover {
            border-color: var(--accent-blue);
            background: rgba(59, 130, 246, 0.05);
            transform: translateX(2px);
        }
        
        .file-icon-wrapper {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            flex-shrink: 0;
        }
        
        .file-icon-wrapper.blue { background: rgba(59, 130, 246, 0.15); color: var(--accent-blue); }
        .file-icon-wrapper.green { background: rgba(16, 185, 129, 0.15); color: var(--accent-green); }
        .file-icon-wrapper.purple { background: rgba(139, 92, 246, 0.15); color: var(--accent-purple); }
        .file-icon-wrapper.orange { background: rgba(245, 158, 11, 0.15); color: var(--accent-orange); }
        
        .file-info {
            flex: 1;
            min-width: 0;
        }
        
        .file-name {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.875rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 0.25rem;
        }
        
        .file-meta {
            font-size: 0.75rem;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .file-actions {
            display: flex;
            gap: 0.375rem;
            opacity: 0;
            transition: opacity 0.2s;
        }
        
        .file-item:hover .file-actions {
            opacity: 1;
        }
        
        .file-action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            border: none;
            background: rgba(59, 130, 246, 0.15);
            color: var(--accent-blue);
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            font-size: 0.875rem;
        }
        
        .file-action-btn:hover {
            background: var(--accent-blue);
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 2.5rem 1rem;
            color: var(--text-muted);
        }
        
        .empty-state i {
            font-size: 3rem;
            opacity: 0.3;
            margin-bottom: 0.75rem;
        }
        
        .empty-state p {
            margin: 0;
            font-size: 0.875rem;
        }
        
        .view-all-link {
            display: block;
            text-align: center;
            padding: 0.875rem;
            color: var(--accent-blue);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.875rem;
            border-top: 1px solid var(--border-color);
            margin-top: 1rem;
            transition: all 0.2s;
        }
        
        .view-all-link:hover {
            background: rgba(59, 130, 246, 0.05);
        }
        
        /* Modal Styles */
        .modal-content {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow-lg);
        }
        
        .modal-header {
            border-bottom: 1px solid var(--border-color);
            padding: 1.25rem 1.5rem;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-title {
            color: var(--text-primary);
            font-weight: 600;
            font-size: 1.125rem;
        }
        
        .btn-close {
            filter: invert(1);
            opacity: 0.5;
        }
        
        .btn-close:hover {
            opacity: 1;
        }
        
        .form-control {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 0.625rem 0.875rem;
            font-size: 0.875rem;
        }
        
        .form-control:focus {
            background: var(--bg-primary);
            border-color: var(--accent-blue);
            color: var(--text-primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .form-check-input {
            background: var(--bg-primary);
            border-color: var(--border-color);
        }
        
        .form-check-input:checked {
            background-color: var(--accent-blue);
            border-color: var(--accent-blue);
        }
        
        .form-label {
            color: var(--text-secondary);
            font-weight: 500;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }
        
        .modal-footer {
            border-top: 1px solid var(--border-color);
            padding: 1.25rem 1.5rem;
        }
        
        .dropdown-menu {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }
        
        .dropdown-item {
            color: var(--text-primary);
            transition: all 0.2s;
            border-radius: 6px;
            padding: 0.5rem 0.75rem;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            gap: 0.625rem;
        }
        
        .dropdown-item:hover {
            background: rgba(59, 130, 246, 0.1);
            color: var(--accent-blue);
        }
        
        .dropdown-divider {
            border-color: var(--border-color);
            margin: 0.5rem 0;
        }
        
        /* Responsive */
        @media (max-width: 1400px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 1200px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 992px) {
            .navbar-menu {
                display: none;
            }
            
            .search-box input {
                width: 180px;
            }
            
            .search-box input:focus {
                width: 220px;
            }
            
            .storage-indicator {
                display: none;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .top-navbar {
                padding: 0 1rem;
            }
            
            .navbar-brand h4 {
                display: none;
            }
            
            .search-box {
                display: none;
            }
            
            .user-info {
                display: none;
            }
            
            .main-content {
                padding: 1.25rem;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .stat-card {
                padding: 1.25rem;
            }
        }
        
        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .stat-card {
            animation: fadeIn 0.4s ease-out backwards;
        }
        
        .stat-card:nth-child(1) { animation-delay: 0.05s; }
        .stat-card:nth-child(2) { animation-delay: 0.1s; }
        .stat-card:nth-child(3) { animation-delay: 0.15s; }
        .stat-card:nth-child(4) { animation-delay: 0.2s; }
        
        .card {
            animation: fadeIn 0.4s ease-out backwards;
            animation-delay: 0.25s;
        }
    </style>
</head>
<body>
    <!-- Top Navbar -->
    <nav class="top-navbar">
        <a href="dashboard.php" class="navbar-brand">
            <i class="bi bi-cloud-arrow-up-fill"></i>
            <h4>FlowNet</h4>
        </a>
        
        <div class="navbar-menu">
            <a href="dashboard.php" class="nav-link active">
                <i class="bi bi-house-door-fill"></i>
                <span>Dashboard</span>
            </a>
            <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#filesModal">
                <i class="bi bi-folder-fill"></i>
                <span>My Files</span>
                <span class="nav-badge"><?= $totalFiles ?></span>
            </a>
            <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#sharedModal">
                <i class="bi bi-people-fill"></i>
                <span>Shared</span>
                <?php if (count($sharedFiles) > 0): ?>
                    <span class="nav-badge"><?= count($sharedFiles) ?></span>
                <?php endif; ?>
            </a>
            <?php if ($userRole === 'admin'): ?>
<a href="admin/index.php" class="nav-link">
                <i class="bi bi-speedometer2"></i>
                <span>Admin</span>
            </a>
            <?php endif; ?>
        </div>
        
        <div class="navbar-actions">
            <div class="search-box">
                <i class="bi bi-search"></i>
                <input type="text" id="searchInput" placeholder="Search files...">
            </div>
            
            <div class="storage-indicator" data-bs-toggle="modal" data-bs-target="#storageModal">
                <div class="storage-circle">
                    <svg width="36" height="36">
                        <circle cx="18" cy="18" r="16" fill="none" stroke="rgba(148, 163, 184, 0.15)" stroke-width="2.5"/>
                        <circle cx="18" cy="18" r="16" fill="none" stroke="url(#gradient)" stroke-width="2.5" 
                                stroke-dasharray="<?= min($storagePercent, 100) * 1.005 ?> 100.5" 
                                stroke-linecap="round" transform="rotate(-90 18 18)"/>
                        <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#3b82f6"/>
                                <stop offset="100%" style="stop-color:#8b5cf6"/>
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="storage-info">
                    <div class="storage-label">Storage</div>
                    <div class="storage-value"><?= formatFileSize($totalStorage) ?> / 10 GB</div>
                </div>
            </div>
            
            <button class="btn-upload" data-bs-toggle="modal" data-bs-target="#uploadModal">
                <i class="bi bi-cloud-upload-fill"></i>
                <span>Upload</span>
            </button>
            
            <div class="dropdown">
                <div class="user-menu" data-bs-toggle="dropdown">
                    <div class="user-avatar">
                        <?= strtoupper(substr($fullName, 0, 1)) ?>
                    </div>
                    <div class="user-info">
                        <div class="user-name"><?= htmlspecialchars($username) ?></div>
                        <div class="user-role"><?= htmlspecialchars($userRole) ?></div>
                    </div>
                    <i class="bi bi-chevron-down" style="font-size: 0.75rem; color: var(--text-muted);"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person-fill"></i> Profile</a></li>
                    <li><a class="dropdown-item" href="#"><i class="bi bi-gear-fill"></i> Settings</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php" style="color: var(--accent-red);"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Welcome back, <?= htmlspecialchars($fullName) ?>! 👋</h1>
            <p class="page-subtitle">Here's what's happening with your storage today</p>
        </div>

        <!-- Alerts -->
        <?php if ($successMsg): ?>
            <div class="alert-custom alert-success">
                <i class="bi bi-check-circle-fill"></i>
                <span><?= htmlspecialchars($successMsg) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
            <div class="alert-custom alert-danger">
                <i class="bi bi-exclamation-circle-fill"></i>
                <span><?= htmlspecialchars($errorMsg) ?></span>
            </div>
        <?php endif; ?>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?= $totalFiles ?></div>
                        <div class="stat-label">Total Files</div>
                        <span class="stat-change positive">
                            <i class="bi bi-arrow-up"></i> 12% this month
                        </span>
                    </div>
                    <div class="stat-icon blue">
                        <i class="bi bi-files"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?= formatFileSize($totalStorage) ?></div>
                        <div class="stat-label">Storage Used</div>
                        <span class="stat-change positive">
                            <i class="bi bi-arrow-up"></i> <?= number_format($storagePercent, 1) ?>% used
                        </span>
                    </div>
                    <div class="stat-icon green">
                        <i class="bi bi-hdd-fill"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?= count($sharedFiles) ?></div>
                        <div class="stat-label">Shared Files</div>
                        <span class="stat-change positive">
                            <i class="bi bi-arrow-up"></i> Active shares
                        </span>
                    </div>
                    <div class="stat-icon purple">
                        <i class="bi bi-share-fill"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-value"><?= count(array_filter($myFiles, function($f) { return $f['encrypted']; })) ?></div>
                        <div class="stat-label">Encrypted Files</div>
                        <span class="stat-change positive">
                            <i class="bi bi-shield-check"></i> Secure
                        </span>
                    </div>
                    <div class="stat-icon orange">
                        <i class="bi bi-lock-fill"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content Grid -->
        <div class="content-grid">
            <!-- Storage Chart -->
            <div class="card">
                <h2 class="card-title">
                    <i class="bi bi-pie-chart-fill"></i> Storage Distribution
                </h2>
                <div id="storageChart" class="chart-container"></div>
            </div>
            
            <!-- Recent Files -->
            <div class="card">
                <h2 class="card-title">
                    <i class="bi bi-clock-history"></i> Recent Files
                </h2>
                <?php if (empty($recentFiles)): ?>
                    <div class="empty-state">
                        <i class="bi bi-inbox"></i>
                        <p>No recent files</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($recentFiles as $file): 
                        $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
                        $iconClass = 'blue';
                        $icon = 'bi-file-earmark';
                        
                        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])) {
                            $iconClass = 'green';
                            $icon = 'bi-file-image-fill';
                        } elseif (in_array($ext, ['mp4', 'webm', 'ogg', 'mov', 'avi'])) {
                            $iconClass = 'purple';
                            $icon = 'bi-file-play-fill';
                        } elseif (in_array($ext, ['pdf', 'doc', 'docx'])) {
                            $iconClass = 'orange';
                            $icon = 'bi-file-text-fill';
                        } elseif (in_array($ext, ['zip', 'rar', '7z'])) {
                            $iconClass = 'blue';
                            $icon = 'bi-file-zip-fill';
                        }
                    ?>
                        <div class="file-item">
                            <div class="file-icon-wrapper <?= $iconClass ?>">
                                <i class="bi <?= $icon ?>"></i>
                            </div>
                            <div class="file-info">
                                <div class="file-name"><?= htmlspecialchars($file['original_name']) ?></div>
                                <div class="file-meta">
                                    <span><?= formatFileSize($file['file_size']) ?></span>
                                    <span>•</span>
                                    <span><?= date('d M Y', strtotime($file['uploaded_at'])) ?></span>
                                    <?php if ($file['encrypted']): ?>
                                        <i class="bi bi-lock-fill" style="color: var(--accent-orange);"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="file-actions">
                                <a href="preview.php?id=<?= $file['id'] ?>" class="file-action-btn" title="Preview">
                                    <i class="bi bi-eye-fill"></i>
                                </a>
                                <a href="download.php?id=<?= $file['id'] ?>" class="file-action-btn" style="background: rgba(16, 185, 129, 0.15); color: var(--accent-green);" title="Download">
                                    <i class="bi bi-download"></i>
                                </a>
                                <button class="file-action-btn" style="background: rgba(139, 92, 246, 0.15); color: var(--accent-purple);" title="Share" onclick="openShareModal(<?= $file['id'] ?>, '<?= htmlspecialchars($file['original_name'], ENT_QUOTES) ?>')">
                                    <i class="bi bi-share-fill"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <a href="#" data-bs-toggle="modal" data-bs-target="#filesModal" class="view-all-link">
                        View All Files <i class="bi bi-arrow-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Upload Modal -->
    <div class="modal fade" id="uploadModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-cloud-upload-fill"></i> Upload File</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="upload.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="fileInput" class="form-label">Choose File</label>
                            <input type="file" class="form-control" id="fileInput" name="file" required>
                            <div class="form-text" style="color: var(--text-muted); margin-top: 0.5rem; font-size: 0.75rem;">
                                Maximum file size: 100MB
                            </div>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="encrypt" id="encryptCheck">
                            <label class="form-check-label" for="encryptCheck" style="font-size: 0.875rem;">
                                <i class="bi bi-lock-fill"></i> Encrypt this file for extra security
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn" data-bs-dismiss="modal" style="background: var(--bg-hover); border: 1px solid var(--border-color); color: var(--text-primary); padding: 0.5rem 1rem; border-radius: 6px; font-size: 0.875rem;">Cancel</button>
                        <button type="submit" class="btn-upload">
                            <i class="bi bi-upload"></i> Upload File
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- My Files Modal -->
    <div class="modal fade" id="filesModal" tabindex="-1">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-folder-fill"></i> My Files (<?= $totalFiles ?>)</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php if (empty($myFiles)): ?>
                        <div class="empty-state">
                            <i class="bi bi-inbox"></i>
                            <p>No files yet. Upload your first file!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($myFiles as $file): 
                            $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
                            $iconClass = 'blue';
                            $icon = 'bi-file-earmark';
                            
                            if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])) {
                                $iconClass = 'green';
                                $icon = 'bi-file-image-fill';
                            } elseif (in_array($ext, ['mp4', 'webm', 'ogg', 'mov', 'avi'])) {
                                $iconClass = 'purple';
                                $icon = 'bi-file-play-fill';
                            } elseif (in_array($ext, ['pdf', 'doc', 'docx'])) {
                                $iconClass = 'orange';
                                $icon = 'bi-file-text-fill';
                            } elseif (in_array($ext, ['zip', 'rar', '7z'])) {
                                $iconClass = 'blue';
                                $icon = 'bi-file-zip-fill';
                            }
                        ?>
                            <div class="file-item">
                                <div class="file-icon-wrapper <?= $iconClass ?>">
                                    <i class="bi <?= $icon ?>"></i>
                                </div>
                                <div class="file-info">
                                    <div class="file-name"><?= htmlspecialchars($file['original_name']) ?></div>
                                    <div class="file-meta">
                                        <span><?= formatFileSize($file['file_size']) ?></span>
                                        <span>•</span>
                                        <span><?= date('d M Y H:i', strtotime($file['uploaded_at'])) ?></span>
                                        <?php if ($file['encrypted']): ?>
                                            <i class="bi bi-lock-fill" style="color: var(--accent-orange);"></i>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div style="display: flex; gap: 0.375rem;">
                                    <a href="preview.php?id=<?= $file['id'] ?>" class="file-action-btn" title="Preview">
                                        <i class="bi bi-eye-fill"></i>
                                    </a>
                                    <a href="download.php?id=<?= $file['id'] ?>" class="file-action-btn" style="background: rgba(16, 185, 129, 0.15); color: var(--accent-green);" title="Download">
                                        <i class="bi bi-download"></i>
                                    </a>
                                    <button class="file-action-btn" style="background: rgba(139, 92, 246, 0.15); color: var(--accent-purple);" title="Share" onclick="openShareModal(<?= $file['id'] ?>, '<?= htmlspecialchars($file['original_name'], ENT_QUOTES) ?>')">
                                        <i class="bi bi-share-fill"></i>
                                    </button>
                                    <a href="delete.php?id=<?= $file['id'] ?>" class="file-action-btn" style="background: rgba(239, 68, 68, 0.15); color: var(--accent-red);" onclick="return confirm('Delete this file?')" title="Delete">
                                        <i class="bi bi-trash-fill"></i>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Shared Files Modal -->
    <div class="modal fade" id="sharedModal" tabindex="-1">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-people-fill"></i> Shared With Me (<?= count($sharedFiles) ?>)</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php if (empty($sharedFiles)): ?>
                        <div class="empty-state">
                            <i class="bi bi-inbox"></i>
                            <p>No files shared with you yet</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($sharedFiles as $file): ?>
                            <div class="file-item">
                                <div class="file-icon-wrapper purple">
                                    <i class="bi bi-file-earmark-arrow-down-fill"></i>
                                </div>
                                <div class="file-info">
                                    <div class="file-name"><?= htmlspecialchars($file['original_name']) ?></div>
                                    <div class="file-meta">
                                        <span><?= formatFileSize($file['file_size']) ?></span>
                                        <span>•</span>
                                        <span>From: <?= htmlspecialchars($file['owner_username']) ?></span>
                                        <span>•</span>
                                        <span><?= date('d M Y', strtotime($file['shared_at'])) ?></span>
                                    </div>
                                </div>
                                <div style="display: flex; gap: 0.375rem;">
                                    <a href="preview.php?id=<?= $file['id'] ?>&shared=1" class="file-action-btn">
                                        <i class="bi bi-eye-fill"></i>
                                    </a>
                                    <?php if ($file['can_download']): ?>
                                        <a href="download.php?id=<?= $file['id'] ?>&shared=1" class="file-action-btn" style="background: rgba(16, 185, 129, 0.15); color: var(--accent-green);">
                                            <i class="bi bi-download"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Storage Modal -->
    <div class="modal fade" id="storageModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-hdd-fill"></i> Storage Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div style="text-align: center; margin-bottom: 2rem;">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem; letter-spacing: -0.025em;">
                            <?= formatFileSize($totalStorage) ?>
                        </div>
                        <div style="color: var(--text-muted); margin-bottom: 1rem; font-size: 0.875rem;">
                            of 10 GB used (<?= number_format($storagePercent, 1) ?>%)
                        </div>
                        <div style="height: 10px; background: var(--bg-primary); border-radius: 5px; overflow: hidden;">
                            <div style="height: 100%; width: <?= min($storagePercent, 100) ?>%; background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple)); border-radius: 5px; transition: width 0.3s;"></div>
                        </div>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                        <?php foreach ($storageByType as $type => $size): ?>
                            <?php if ($size > 0): ?>
                                <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.875rem; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px;">
                                    <span style="color: var(--text-primary); font-weight: 500; font-size: 0.875rem;"><?= $type ?></span>
                                    <span style="color: var(--accent-blue); font-weight: 600; font-size: 0.875rem;"><?= formatFileSize($size) ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <button class="btn-upload" style="width: 100%; margin-top: 1.5rem; justify-content: center;">
                        <i class="bi bi-arrow-up-circle-fill"></i> Upgrade Storage
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Share Modal -->
    <div class="modal fade" id="shareModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-share-fill"></i> Share File</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="share_file.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="file_id" id="shareFileId">
                        
                        <div class="mb-3">
                            <label class="form-label">File Name</label>
                            <input type="text" class="form-control" id="shareFileName" readonly style="background: var(--bg-primary); cursor: not-allowed;">
                        </div>
                        
                        <div class="mb-3">
                            <label for="shareUsername" class="form-label">Share with Username</label>
                            <input type="text" class="form-control" id="shareUsername" name="share_username" placeholder="Enter username" required>
                            <div class="form-text" style="color: var(--text-muted); margin-top: 0.5rem; font-size: 0.75rem;">
                                Enter the username of the person you want to share this file with
                            </div>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="can_download" id="canDownload" checked>
                            <label class="form-check-label" for="canDownload" style="font-size: 0.875rem;">
                                <i class="bi bi-download"></i> Allow download
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn" data-bs-dismiss="modal" style="background: var(--bg-hover); border: 1px solid var(--border-color); color: var(--text-primary); padding: 0.5rem 1rem; border-radius: 6px; font-size: 0.875rem;">Cancel</button>
                        <button type="submit" class="btn-upload">
                            <i class="bi bi-share-fill"></i> Share File
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Search Functionality
        const searchInput = document.getElementById('searchInput');
        
        if (searchInput) {
            searchInput.addEventListener('input', function(e) {
                const searchTerm = e.target.value.toLowerCase();
                const fileItems = document.querySelectorAll('.file-item');
                
                fileItems.forEach(item => {
                    const fileName = item.querySelector('.file-name');
                    if (fileName) {
                        const text = fileName.textContent.toLowerCase();
                        if (text.includes(searchTerm)) {
                            item.classList.remove('hidden');
                        } else {
                            item.classList.add('hidden');
                        }
                    }
                });
                
                // Show "no results" message if all items are hidden
                const containers = document.querySelectorAll('.card, .modal-body');
                containers.forEach(container => {
                    const items = container.querySelectorAll('.file-item');
                    const visibleItems = container.querySelectorAll('.file-item:not(.hidden)');
                    
                    let noResultsMsg = container.querySelector('.no-results-message');
                    
                    if (items.length > 0 && visibleItems.length === 0 && searchTerm) {
                        if (!noResultsMsg) {
                            noResultsMsg = document.createElement('div');
                            noResultsMsg.className = 'no-results-message empty-state';
                            noResultsMsg.innerHTML = '<i class="bi bi-search"></i><p>No files found matching "' + searchTerm + '"</p>';
                            container.appendChild(noResultsMsg);
                        }
                    } else if (noResultsMsg) {
                        noResultsMsg.remove();
                    }
                });
            });
        }
        
        // Share Modal Function
        function openShareModal(fileId, fileName) {
            document.getElementById('shareFileId').value = fileId;
            document.getElementById('shareFileName').value = fileName;
            const shareModal = new bootstrap.Modal(document.getElementById('shareModal'));
            shareModal.show();
        }
        
        // Highcharts Dark Theme
        Highcharts.setOptions({
            colors: ['#3b82f6', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b', '#6366f1'],
            chart: {
                backgroundColor: 'transparent',
                style: { fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }
            },
            title: { style: { color: '#f8fafc', fontSize: '14px', fontWeight: '600' } },
            tooltip: {
                backgroundColor: 'rgba(30, 41, 59, 0.98)',
                borderColor: 'rgba(148, 163, 184, 0.2)',
                borderRadius: 8,
                style: { color: '#f8fafc', fontSize: '12px' },
                shadow: false
            },
            legend: {
                itemStyle: { color: '#cbd5e1', fontSize: '12px', fontWeight: '500' },
                itemHoverStyle: { color: '#3b82f6' }
            },
            credits: { enabled: false }
        });

        // Storage Distribution Chart
        Highcharts.chart('storageChart', {
            chart: { 
                type: 'pie',
                height: 300
            },
            title: { text: null },
            tooltip: {
                pointFormat: '<b>{point.y:.2f} MB</b> ({point.percentage:.1f}%)'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b><br>{point.percentage:.1f}%',
                        style: { 
                            color: '#cbd5e1', 
                            textOutline: 'none', 
                            fontSize: '11px',
                            fontWeight: '500'
                        },
                        distance: 20
                    },
                    borderWidth: 0,
                    innerSize: '50%',
                    size: '85%'
                }
            },
            series: [{
                name: 'Storage',
                colorByPoint: true,
                data: [
                    <?php foreach ($storageByType as $type => $size): ?>
                        <?php if ($size > 0): ?>
                            { name: '<?= $type ?>', y: <?= round($size / 1048576, 2) ?> },
                        <?php endif; ?>
                    <?php endforeach; ?>
                ]
            }]
        });

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert-custom');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.animation = 'fadeOut 0.3s ease-out';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });
        });

        // Add fadeOut animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeOut {
                from {
                    opacity: 1;
                    transform: translateY(0);
                }
                to {
                    opacity: 0;
                    transform: translateY(-10px);
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>