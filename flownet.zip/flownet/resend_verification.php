<?php
require_once 'config.php';
require_once 'mailer.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    
    // Validasi email
    if (empty($email)) {
        $error = 'Email harus diisi!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid!';
    } else {
        try {
            // Cari user dengan email yang belum diverifikasi
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND email_verified = 0");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user) {
                // Generate token verifikasi baru
                $newToken = generateToken(32);
                
                // Update token di database
                $stmt = $conn->prepare("UPDATE users SET verification_token = ? WHERE id = ?");
                $stmt->execute([$newToken, $user['id']]);
                
                // Kirim email verifikasi
                if (sendVerificationEmail($email, $user['username'], $newToken)) {
                    $success = 'Email verifikasi telah dikirim ulang! Silakan cek inbox atau folder spam Anda.';
                    
                    // Log aktivitas
                    logActivity($conn, $user['id'], 'resend_verification', "Verification email resent");
                } else {
                    $error = 'Gagal mengirim email. Silakan coba lagi nanti atau hubungi admin.';
                }
            } else {
                // Cek apakah email sudah terverifikasi
                $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND email_verified = 1");
                $stmt->execute([$email]);
                $verifiedUser = $stmt->fetch();
                
                if ($verifiedUser) {
                    $error = 'Email ini sudah diverifikasi. Silakan login.';
                } else {
                    // Jangan beritahu user bahwa email tidak terdaftar (security)
                    $success = 'Jika email terdaftar, link verifikasi telah dikirim.';
                }
            }
        } catch(PDOException $e) {
            $error = 'Terjadi kesalahan sistem. Silakan coba lagi nanti.';
            error_log("Resend verification error: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resend Verification - FlowNet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background: linear-gradient(135deg, #1e3a5f 0%, #2d4a6f 50%, #1e3a5f 100%);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            color: #e0e6ed;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 20% 50%, rgba(56, 189, 248, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(59, 130, 246, 0.05) 0%, transparent 50%);
            pointer-events: none;
        }
        
        .resend-container {
            width: 100%;
            max-width: 450px;
            position: relative;
            z-index: 1;
        }
        
        .brand-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            color: #fff;
            text-decoration: none;
            margin-bottom: 2rem;
        }
        
        .brand-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .resend-card {
            background: rgba(30, 41, 59, 0.8);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 16px;
            padding: 2.5rem;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
        }
        
        .resend-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .resend-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 1rem;
            background: rgba(59, 130, 246, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: #3b82f6;
        }
        
        .resend-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #fff;
            margin-bottom: 0.5rem;
        }
        
        .resend-subtitle {
            color: #94a3b8;
            font-size: 0.875rem;
        }
        
        .alert-modern {
            padding: 0.875rem 1rem;
            border-radius: 8px;
            border: 1px solid;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 0.875rem;
        }
        
        .alert-danger-modern {
            background-color: rgba(248, 81, 73, 0.1);
            border-color: rgba(248, 81, 73, 0.3);
            color: #fca5a5;
        }
        
        .alert-success-modern {
            background-color: rgba(34, 197, 94, 0.1);
            border-color: rgba(34, 197, 94, 0.3);
            color: #86efac;
        }
        
        .alert-info-modern {
            background-color: rgba(59, 130, 246, 0.1);
            border-color: rgba(59, 130, 246, 0.3);
            color: #93c5fd;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label-modern {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: #cbd5e1;
            margin-bottom: 0.5rem;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .form-control-modern {
            width: 100%;
            padding: 0.75rem 1rem;
            padding-right: 2.5rem;
            font-size: 0.875rem;
            background: rgba(15, 23, 42, 0.5);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 8px;
            color: #e0e6ed;
            transition: all 0.2s;
        }
        
        .form-control-modern:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            background: rgba(15, 23, 42, 0.7);
        }
        
        .form-control-modern::placeholder {
            color: #64748b;
        }
        
        .input-icon {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 1rem;
            pointer-events: none;
        }
        
        .btn-modern {
            width: 100%;
            padding: 0.875rem 1rem;
            font-size: 0.875rem;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            text-decoration: none;
        }
        
        .btn-primary-modern {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: #fff;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
            margin-bottom: 0.75rem;
        }
        
        .btn-primary-modern:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        
        .btn-secondary-modern {
            background: rgba(51, 65, 85, 0.6);
            color: #e0e6ed;
            border: 1px solid rgba(71, 85, 105, 0.6);
        }
        
        .btn-secondary-modern:hover {
            background: rgba(71, 85, 105, 0.8);
            color: #fff;
        }
        
        .resend-footer {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid rgba(51, 65, 85, 0.6);
            font-size: 0.875rem;
            color: #94a3b8;
        }
        
        .resend-footer a {
            color: #60a5fa;
            text-decoration: none;
            font-weight: 500;
        }
        
        .resend-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="resend-container">
        <a href="login.php" class="brand-logo">
            <div class="brand-icon">
                <i class="bi bi-cloud-arrow-down-fill"></i>
            </div>
            FlowNet
        </a>
        
        <div class="resend-card">
            <div class="resend-header">
                <div class="resend-icon">
                    <i class="bi bi-envelope-paper"></i>
                </div>
                <h1 class="resend-title">Resend Verification Email</h1>
                <p class="resend-subtitle">Enter your email to receive a new verification link</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert-modern alert-danger-modern">
                    <i class="bi bi-exclamation-circle-fill"></i>
                    <span><?= htmlspecialchars($error) ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert-modern alert-success-modern">
                    <i class="bi bi-check-circle-fill"></i>
                    <span><?= htmlspecialchars($success) ?></span>
                </div>
            <?php else: ?>
                <div class="alert-modern alert-info-modern">
                    <i class="bi bi-info-circle"></i>
                    <span>Didn't receive the email? Check your spam folder first.</span>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label class="form-label-modern">EMAIL ADDRESS</label>
                    <div class="input-wrapper">
                        <input type="email" class="form-control-modern" name="email" 
                               placeholder="your-email@example.com" required 
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                        <i class="bi bi-envelope input-icon"></i>
                    </div>
                </div>
                
                <button type="submit" class="btn-modern btn-primary-modern">
                    <i class="bi bi-send"></i>
                    Send Verification Email
                </button>
                
                <a href="login.php" class="btn-modern btn-secondary-modern">
                    <i class="bi bi-arrow-left"></i>
                    Back to Login
                </a>
            </form>
            
            <div class="resend-footer">
                <p>
                    Remember your password? <a href="login.php">Sign In</a>
                </p>
            </div>
        </div>
    </div>
</body>
</html>