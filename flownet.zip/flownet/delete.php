<?php
require_once 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit;
}

$fileId = $_GET['id'];
$userId = $_SESSION['user_id'];

try {
    // Cek apakah file milik user
    $stmt = $conn->prepare("SELECT * FROM files WHERE id = ? AND user_id = ?");
    $stmt->execute([$fileId, $userId]);
    $file = $stmt->fetch();
    
    if (!$file) {
        $_SESSION['error'] = 'File tidak ditemukan!';
        header('Location: dashboard.php');
        exit;
    }
    
    // Check if file exists with full path
    $filePath = __DIR__ . '/' . $file['file_path'];
    
    if (!file_exists($filePath)) {
        error_log("File not found: " . $filePath);
        $_SESSION['error'] = 'File fisik tidak ditemukan di: ' . $filePath;
        header('Location: dashboard.php');
        exit;
    }
    
    // Move to trash instead of permanent delete
    $stmt = $conn->prepare("
        INSERT INTO trash (file_id, user_id, original_name, stored_name, file_path, file_size, file_type, encrypted, encryption_key, uploaded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $file['id'],
        $file['user_id'],
        $file['original_name'],
        $file['stored_name'],
        $file['file_path'],
        $file['file_size'],
        $file['file_type'],
        $file['encrypted'],
        $file['encryption_key'],
        $file['uploaded_at']
    ]);
    
    // Remove from files table (shared_files akan terhapus otomatis karena ON DELETE CASCADE)
    $stmt = $conn->prepare("DELETE FROM files WHERE id = ?");
    $stmt->execute([$fileId]);
    
    // Log aktivitas
    logActivity($conn, $userId, 'delete', "Moved to trash: " . $file['original_name']);
    
    $_SESSION['success'] = 'File berhasil dipindahkan ke trash!';
    
} catch (Exception $e) {
    $_SESSION['error'] = 'Error: ' . $e->getMessage();
}

header('Location: dashboard.php');
exit;
?>