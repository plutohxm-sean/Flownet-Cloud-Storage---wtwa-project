<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit;
}

$fileId = $_GET['id'];
$userId = $_SESSION['user_id'];
$isShared = isset($_GET['shared']);

try {
    if ($isShared) {
        // Cek apakah file dibagikan ke user dan user boleh download
        $stmt = $conn->prepare("
            SELECT f.*, sf.can_download 
            FROM files f 
            JOIN shared_files sf ON f.id = sf.file_id 
            WHERE f.id = ? AND sf.shared_with = ?
        ");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if (!$file || !$file['can_download']) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk download file ini!';
            header('Location: dashboard.php');
            exit;
        }
    } else {
        // Cek apakah file milik user
        $stmt = $conn->prepare("SELECT * FROM files WHERE id = ? AND user_id = ?");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if (!$file) {
            $_SESSION['error'] = 'File tidak ditemukan!';
            header('Location: dashboard.php');
            exit;
        }
    }
    
    // Build full file path - PENTING: pakai absolute path
    $baseDir = __DIR__;
    $filePath = $baseDir . '/' . $file['file_path'];
    
    // Debug: Log the path being checked
    error_log("Base Dir: " . $baseDir);
    error_log("File Path from DB: " . $file['file_path']);
    error_log("Full Path: " . $filePath);
    
    if (!file_exists($filePath)) {
        $_SESSION['error'] = 'File tidak ditemukan di server!<br>';
        $_SESSION['error'] .= 'Path dicari: ' . htmlspecialchars($filePath) . '<br>';
        $_SESSION['error'] .= 'Path di DB: ' . htmlspecialchars($file['file_path']) . '<br>';
        
        // Check if file exists with different path
        $alternativePath = $file['file_path'];
        if (file_exists($alternativePath)) {
            $_SESSION['error'] .= '<strong>File ditemukan di: ' . htmlspecialchars($alternativePath) . '</strong>';
        } else {
            $_SESSION['error'] .= 'File juga tidak ada di: ' . htmlspecialchars($alternativePath);
        }
        
        header('Location: dashboard.php');
        exit;
    }
    
    // Check if file is readable
    if (!is_readable($filePath)) {
        $_SESSION['error'] = 'File tidak bisa dibaca! Check permissions.<br>';
        $_SESSION['error'] .= 'Path: ' . htmlspecialchars($filePath) . '<br>';
        $_SESSION['error'] .= 'Permissions: ' . substr(sprintf('%o', fileperms($filePath)), -4);
        header('Location: dashboard.php');
        exit;
    }
    
    // Jika file terenkripsi, dekripsi dulu
    if ($file['encrypted']) {
        $tempFile = sys_get_temp_dir() . '/' . uniqid() . '_' . basename($file['original_name']);
        
        try {
            decryptFile($filePath, $tempFile, $file['encryption_key']);
            
            if (!file_exists($tempFile)) {
                throw new Exception('Failed to create decrypted file');
            }
            
            $downloadPath = $tempFile;
        } catch (Exception $e) {
            $_SESSION['error'] = 'Gagal mendekripsi file: ' . $e->getMessage();
            header('Location: dashboard.php');
            exit;
        }
    } else {
        $downloadPath = $filePath;
    }
    
    // Set headers untuk download
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file['original_name']) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($downloadPath));
    
    // Clear output buffer
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    // Baca dan output file
    readfile($downloadPath);
    
    // Hapus file temporary jika ada
    if ($file['encrypted'] && file_exists($tempFile)) {
        unlink($tempFile);
    }
    
    // Log aktivitas
    logActivity($conn, $userId, 'download', "Downloaded file: " . $file['original_name']);
    
    exit;
    
} catch (Exception $e) {
    $_SESSION['error'] = 'Error: ' . $e->getMessage();
    header('Location: dashboard.php');
    exit;
}
?>