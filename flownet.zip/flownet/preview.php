<?php
require_once 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit;
}

$fileId = $_GET['id'];
$userId = $_SESSION['user_id'];
$isShared = isset($_GET['shared']);

try {
    if ($isShared) {
        // Cek apakah file dibagikan ke user
        $stmt = $conn->prepare("
            SELECT f.*, u.username as owner_username, sf.can_download 
            FROM files f 
            JOIN shared_files sf ON f.id = sf.file_id 
            JOIN users u ON f.user_id = u.id
            WHERE f.id = ? AND sf.shared_with = ?
        ");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if (!$file) {
            $_SESSION['error'] = 'File tidak ditemukan!';
            header('Location: dashboard.php');
            exit;
        }
    } else {
        // Cek apakah file milik user
        $stmt = $conn->prepare("SELECT * FROM files WHERE id = ? AND user_id = ?");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if (!$file) {
            $_SESSION['error'] = 'File tidak ditemukan!';
            header('Location: dashboard.php');
            exit;
        }
    }
    
    // Deteksi tipe file
    $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
    $fileType = 'other';
    
    $imageExts = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'];
    $videoExts = ['mp4', 'webm', 'ogg', 'mov', 'avi'];
    $audioExts = ['mp3', 'wav', 'ogg', 'flac', 'm4a'];
    $textExts = ['txt', 'md', 'json', 'xml', 'csv', 'log'];
    $codeExts = ['php', 'js', 'html', 'css', 'py', 'java', 'cpp', 'c', 'sql', 'sh'];
    $pdfExts = ['pdf'];
    
    if (in_array($ext, $imageExts)) $fileType = 'image';
    elseif (in_array($ext, $videoExts)) $fileType = 'video';
    elseif (in_array($ext, $audioExts)) $fileType = 'audio';
    elseif (in_array($ext, $textExts)) $fileType = 'text';
    elseif (in_array($ext, $codeExts)) $fileType = 'code';
    elseif (in_array($ext, $pdfExts)) $fileType = 'pdf';
    
    // Jika file encrypted, dekripsi dulu untuk preview
    $previewPath = $file['file_path'];
    if ($file['encrypted']) {
        $tempFile = sys_get_temp_dir() . '/' . uniqid() . '_' . $file['original_name'];
        decryptFile($file['file_path'], $tempFile, $file['encryption_key']);
        $previewPath = $tempFile;
    }
    
    // Convert file untuk preview
    if (in_array($fileType, ['image', 'video', 'audio'])) {
        $previewData = base64_encode(file_get_contents($previewPath));
    } elseif (in_array($fileType, ['text', 'code'])) {
        $previewContent = file_get_contents($previewPath);
    } elseif ($fileType == 'pdf') {
        $previewData = base64_encode(file_get_contents($previewPath));
    }
    
    // Cleanup temp file
    if ($file['encrypted'] && file_exists($tempFile)) {
        unlink($tempFile);
    }
    
    // Log aktivitas
    logActivity($conn, $userId, 'preview', "Previewed file: " . $file['original_name']);
    
} catch (Exception $e) {
    $_SESSION['error'] = 'Error: ' . $e->getMessage();
    header('Location: dashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview: <?= htmlspecialchars($file['original_name']) ?> - FlowNet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background: #0f172a;
            color: #e2e8f0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            overflow: hidden;
        }
        
        /* Header */
        .preview-header {
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(51, 65, 85, 0.6);
            padding: 1rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 70px;
        }
        
        .preview-title {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex: 1;
        }
        
        .file-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }
        
        .file-info h5 {
            margin: 0;
            font-size: 1rem;
            font-weight: 600;
            color: #e2e8f0;
        }
        
        .file-meta {
            font-size: 0.875rem;
            color: #94a3b8;
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .badge-encrypted {
            background: rgba(245, 158, 11, 0.2);
            color: #fbbf24;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
        }
        
        .header-actions {
            display: flex;
            gap: 0.75rem;
        }
        
        .btn-header {
            padding: 0.5rem 1rem;
            border-radius: 6px;
            border: 1px solid rgba(51, 65, 85, 0.6);
            background: rgba(30, 41, 59, 0.8);
            color: #e2e8f0;
            font-weight: 500;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
            font-size: 0.875rem;
        }
        
        .btn-header:hover {
            background: rgba(51, 65, 85, 0.8);
            border-color: #3b82f6;
            color: #fff;
        }
        
        .btn-download {
            background: linear-gradient(135deg, #22c55e, #16a34a);
            border-color: transparent;
        }
        
        .btn-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(34, 197, 94, 0.4);
        }
        
        /* Preview Container */
        .preview-container {
            position: fixed;
            top: 70px;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0f172a;
            overflow: auto;
            padding: 2rem;
        }
        
        .preview-content {
            max-width: 100%;
            max-height: 100%;
            width: auto;
            height: auto;
        }
        
        /* Image Preview */
        .image-preview {
            max-width: 90vw;
            max-height: calc(100vh - 150px);
            object-fit: contain;
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        /* Video Preview */
        .video-preview {
            max-width: 90vw;
            max-height: calc(100vh - 150px);
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        /* Audio Preview */
        .audio-preview {
            width: 500px;
            max-width: 90vw;
        }
        
        /* PDF Preview */
        .pdf-preview {
            width: 90vw;
            height: calc(100vh - 150px);
            border: none;
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        /* Text/Code Preview */
        .text-preview {
            width: 90vw;
            max-width: 1200px;
            height: calc(100vh - 150px);
            background: rgba(30, 41, 59, 0.8);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 8px;
            padding: 2rem;
            overflow: auto;
            font-family: 'Courier New', monospace;
            white-space: pre-wrap;
            word-wrap: break-word;
            line-height: 1.6;
        }
        
        .code-preview {
            width: 90vw;
            max-width: 1200px;
            height: calc(100vh - 150px);
            background: #1e293b;
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .code-preview pre {
            margin: 0;
            height: 100%;
            overflow: auto;
        }
        
        .code-preview code {
            font-size: 0.875rem;
            line-height: 1.6;
        }
        
        /* No Preview */
        .no-preview {
            text-align: center;
            color: #64748b;
        }
        
        .no-preview i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .no-preview h4 {
            margin-bottom: 0.5rem;
        }
        
        /* Zoom Controls (untuk image) */
        .zoom-controls {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            display: flex;
            gap: 0.5rem;
            background: rgba(15, 23, 42, 0.95);
            padding: 0.5rem;
            border-radius: 8px;
            border: 1px solid rgba(51, 65, 85, 0.6);
        }
        
        .zoom-btn {
            width: 40px;
            height: 40px;
            border: none;
            background: rgba(30, 41, 59, 0.8);
            color: #e2e8f0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .zoom-btn:hover {
            background: #3b82f6;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="preview-header">
        <div class="preview-title">
            <div class="file-icon">
                <i class="bi bi-<?= $fileType == 'image' ? 'image' : ($fileType == 'video' ? 'play-circle' : ($fileType == 'audio' ? 'music-note' : ($fileType == 'pdf' ? 'file-pdf' : 'file-text'))) ?>"></i>
            </div>
            <div class="file-info">
                <h5><?= htmlspecialchars($file['original_name']) ?></h5>
                <div class="file-meta">
                    <span><?= formatFileSize($file['file_size']) ?></span>
                    <span>•</span>
                    <span><?= date('d M Y H:i', strtotime($file['uploaded_at'])) ?></span>
                    <?php if ($file['encrypted']): ?>
                        <span class="badge-encrypted"><i class="bi bi-lock-fill"></i> Encrypted</span>
                    <?php endif; ?>
                    <?php if ($isShared): ?>
                        <span>•</span>
                        <span>Owner: @<?= htmlspecialchars($file['owner_username']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="header-actions">
            <?php if (!$isShared || $file['can_download']): ?>
                <a href="download.php?id=<?= $file['id'] ?><?= $isShared ? '&shared=1' : '' ?>" class="btn-header btn-download">
                    <i class="bi bi-download"></i> Download
                </a>
            <?php endif; ?>
            <a href="dashboard.php" class="btn-header">
                <i class="bi bi-x-lg"></i> Close
            </a>
        </div>
    </div>

    <!-- Preview Container -->
    <div class="preview-container">
        <?php if ($fileType == 'image'): ?>
            <!-- Image Preview -->
            <img src="data:<?= $file['file_type'] ?>;base64,<?= $previewData ?>" 
                 alt="<?= htmlspecialchars($file['original_name']) ?>" 
                 class="image-preview" 
                 id="imagePreview">
            
            <!-- Zoom Controls -->
            <div class="zoom-controls">
                <button class="zoom-btn" onclick="zoomIn()"><i class="bi bi-zoom-in"></i></button>
                <button class="zoom-btn" onclick="zoomOut()"><i class="bi bi-zoom-out"></i></button>
                <button class="zoom-btn" onclick="resetZoom()"><i class="bi bi-arrows-fullscreen"></i></button>
            </div>
            
        <?php elseif ($fileType == 'video'): ?>
            <!-- Video Preview -->
            <video controls class="video-preview">
                <source src="data:<?= $file['file_type'] ?>;base64,<?= $previewData ?>" type="<?= $file['file_type'] ?>">
                Your browser does not support video playback.
            </video>
            
        <?php elseif ($fileType == 'audio'): ?>
            <!-- Audio Preview -->
            <div>
                <div style="text-align: center; margin-bottom: 2rem;">
                    <i class="bi bi-music-note-beamed" style="font-size: 5rem; color: #3b82f6;"></i>
                </div>
                <audio controls class="audio-preview" style="width: 100%;">
                    <source src="data:<?= $file['file_type'] ?>;base64,<?= $previewData ?>" type="<?= $file['file_type'] ?>">
                    Your browser does not support audio playback.
                </audio>
            </div>
            
        <?php elseif ($fileType == 'pdf'): ?>
            <!-- PDF Preview -->
            <iframe src="data:application/pdf;base64,<?= $previewData ?>" class="pdf-preview"></iframe>
            
        <?php elseif ($fileType == 'text'): ?>
            <!-- Text Preview -->
            <div class="text-preview"><?= htmlspecialchars($previewContent) ?></div>
            
        <?php elseif ($fileType == 'code'): ?>
            <!-- Code Preview with Syntax Highlighting -->
            <div class="code-preview">
                <pre><code class="language-<?= $ext ?>"><?= htmlspecialchars($previewContent) ?></code></pre>
            </div>
            
        <?php else: ?>
            <!-- No Preview Available -->
            <div class="no-preview">
                <i class="bi bi-file-earmark-x"></i>
                <h4>Preview not available</h4>
                <p>This file type cannot be previewed in browser.</p>
                <p>Please download the file to view it.</p>
                <br>
                <a href="download.php?id=<?= $file['id'] ?><?= $isShared ? '&shared=1' : '' ?>" class="btn-header btn-download">
                    <i class="bi bi-download"></i> Download File
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
    <script>
        // Syntax highlighting untuk code
        <?php if ($fileType == 'code'): ?>
            hljs.highlightAll();
        <?php endif; ?>
        
        // Image zoom functionality
        <?php if ($fileType == 'image'): ?>
            let scale = 1;
            const img = document.getElementById('imagePreview');
            
            function zoomIn() {
                scale += 0.2;
                img.style.transform = `scale(${scale})`;
            }
            
            function zoomOut() {
                if (scale > 0.4) {
                    scale -= 0.2;
                    img.style.transform = `scale(${scale})`;
                }
            }
            
            function resetZoom() {
                scale = 1;
                img.style.transform = `scale(1)`;
            }
        <?php endif; ?>
    </script>
</body>
</html>