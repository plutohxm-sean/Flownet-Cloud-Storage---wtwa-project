<?php
// config.php - Konfigurasi Database dan Aplikasi

// Konfigurasi Database
define('DB_HOST', '127.0.0.1'); // bukan 'ubuntu' atau IP publik
define('DB_USER', 'flownet'); // jangan pakai root di produksi
define('DB_PASS', 'password_kamu');
define('DB_NAME', 'flownet_db');
// Konfigurasi Email (gunakan Gmail SMTP)
// PENTING: Gunakan App Password Gmail, bukan password biasa!
// Cara mendapatkan App Password:
// 1. Buka: https://myaccount.google.com/security
// 2. Aktifkan "2-Step Verification"
// 3. Buka "App passwords" dan generate password untuk "Mail"
// 4. Copy password 16 digit dan paste ke SMTP_PASS
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'flownetdrive@gmail.com'); // Ganti dengan email Gmail Anda
define('SMTP_PASS', 'isi_app_password'); // Ganti dengan 16 digit App Password
define('SMTP_FROM', 'flownetdrive@gmail.com'); // Email pengirim (sama dengan SMTP_USER)
define('SMTP_FROM_NAME', 'FlowNetDrive'); // Nama pengirim

// Konfigurasi Aplikasi
define('BASE_URL', 'https://flownet.my.id/'); // Sesuaikan dengan URL lokal Anda
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50MB

// Encryption Key (gunakan key yang aman untuk produksi)
define('ENCRYPTION_METHOD', 'AES-256-CBC');
define('ENCRYPTION_KEY', 'FlowNet2024SecureKey!@#'); // Ganti dengan key yang lebih aman

// Koneksi Database
try {
    $conn = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", 
        DB_USER, 
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Fungsi untuk enkripsi data
function encryptData($data) {
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(ENCRYPTION_METHOD));
    $encrypted = openssl_encrypt($data, ENCRYPTION_METHOD, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

// Fungsi untuk dekripsi data
function decryptData($data) {
    list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encrypted_data, ENCRYPTION_METHOD, ENCRYPTION_KEY, 0, $iv);
}

// Fungsi untuk enkripsi file
function encryptFile($source, $destination) {
    $key = ENCRYPTION_KEY;
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(ENCRYPTION_METHOD));
    
    $fileContent = file_get_contents($source);
    $encrypted = openssl_encrypt($fileContent, ENCRYPTION_METHOD, $key, 0, $iv);
    
    file_put_contents($destination, $iv . $encrypted);
    return base64_encode($iv);
}

// Fungsi untuk dekripsi file
function decryptFile($source, $destination, $ivBase64) {
    $key = ENCRYPTION_KEY;
    $iv = base64_decode($ivBase64);
    
    $fileContent = file_get_contents($source);
    $ivLength = openssl_cipher_iv_length(ENCRYPTION_METHOD);
    $iv = substr($fileContent, 0, $ivLength);
    $encrypted = substr($fileContent, $ivLength);
    
    $decrypted = openssl_decrypt($encrypted, ENCRYPTION_METHOD, $key, 0, $iv);
    file_put_contents($destination, $decrypted);
}

// Fungsi untuk generate token
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

// Fungsi untuk hash password
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// Fungsi untuk verify password
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Fungsi untuk log aktivitas
function logActivity($conn, $userId, $action, $details = '') {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $stmt = $conn->prepare("INSERT INTO activity_log (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $action, $details, $ip]);
    } catch(PDOException $e) {
        // Silent fail untuk log aktivitas
        error_log("Failed to log activity: " . $e->getMessage());
    }
}

// Fungsi untuk format ukuran file
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

// Fungsi untuk cek apakah user sudah login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Fungsi untuk cek apakah user adalah admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Fungsi untuk require login
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = 'Silakan login terlebih dahulu!';
        header('Location: login.php');
        exit;
    }
}

// Fungsi untuk require admin access
function requireAdmin() {
    requireLogin(); // Pastikan sudah login dulu
    if (!isAdmin()) {
        $_SESSION['error'] = 'Akses ditolak! Hanya admin yang bisa mengakses halaman ini.';
        header('Location: dashboard.php');
        exit;
    }
}

// Fungsi untuk sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// Fungsi untuk validasi email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Fungsi untuk generate random filename
function generateRandomFilename($originalName) {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    return uniqid() . '_' . time() . '.' . $extension;
}

// Fungsi untuk cek tipe file yang diperbolehkan
function isAllowedFileType($filename) {
    $allowed_types = [
        'jpg', 'jpeg', 'png', 'gif', 'pdf', 
        'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
        'txt', 'zip', 'rar', '7z', 'mp3', 'mp4', 'avi'
    ];
    
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($extension, $allowed_types);
}

// Start session
session_start();
?>