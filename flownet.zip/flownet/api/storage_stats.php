<?php
require_once '../config.php';

// Set header JSON
header('Content-Type: application/json');

// Cek login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$userId = $_SESSION['user_id'];

try {
    // 1. Storage by File Type (untuk Pie Chart)
    $fileTypeStats = [];
    $stmt = $conn->prepare("SELECT * FROM files WHERE user_id = ?");
    $stmt->execute([$userId]);
    $files = $stmt->fetchAll();
    
    $typeCategories = [
        'Images' => ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'],
        'Videos' => ['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv', 'flv'],
        'Audio' => ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac'],
        'Documents' => ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'],
        'Archives' => ['zip', 'rar', '7z', 'tar', 'gz'],
        'Code' => ['php', 'js', 'html', 'css', 'py', 'java', 'cpp', 'c', 'sql'],
        'Others' => []
    ];
    
    $typeSizes = array_fill_keys(array_keys($typeCategories), 0);
    
    foreach ($files as $file) {
        $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
        $categorized = false;
        
        foreach ($typeCategories as $category => $extensions) {
            if (in_array($ext, $extensions)) {
                $typeSizes[$category] += $file['file_size'];
                $categorized = true;
                break;
            }
        }
        
        if (!$categorized) {
            $typeSizes['Others'] += $file['file_size'];
        }
    }
    
    // Format untuk Highcharts
    foreach ($typeSizes as $type => $size) {
        if ($size > 0) {
            $fileTypeStats[] = [
                'name' => $type,
                'y' => round($size / (1024 * 1024), 2) // Convert to MB
            ];
        }
    }
    
    // 2. Upload Trend (7 hari terakhir - untuk Line Chart)
    $uploadTrend = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $stmt = $conn->prepare("
            SELECT COUNT(*) as count, COALESCE(SUM(file_size), 0) as size 
            FROM files 
            WHERE user_id = ? AND DATE(uploaded_at) = ?
        ");
        $stmt->execute([$userId, $date]);
        $data = $stmt->fetch();
        
        $uploadTrend[] = [
            'date' => date('d M', strtotime($date)),
            'files' => (int)$data['count'],
            'size' => round($data['size'] / (1024 * 1024), 2) // MB
        ];
    }
    
    // 3. Largest Files (Top 5 - untuk Bar Chart)
    $stmt = $conn->prepare("
        SELECT original_name, file_size 
        FROM files 
        WHERE user_id = ? 
        ORDER BY file_size DESC 
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $largestFiles = [];
    
    while ($row = $stmt->fetch()) {
        // Truncate nama file jika terlalu panjang
        $name = strlen($row['original_name']) > 30 
            ? substr($row['original_name'], 0, 27) . '...' 
            : $row['original_name'];
            
        $largestFiles[] = [
            'name' => $name,
            'size' => round($row['file_size'] / (1024 * 1024), 2) // MB
        ];
    }
    
    // 4. Additional Stats
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM files WHERE user_id = ? AND encrypted = 1");
    $stmt->execute([$userId]);
    $encryptedCount = $stmt->fetch()['count'];
    
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM shared_files WHERE shared_by = ?");
    $stmt->execute([$userId]);
    $sharedByMeCount = $stmt->fetch()['count'];
    
    // Response
    $response = [
        'success' => true,
        'fileTypeStats' => $fileTypeStats,
        'uploadTrend' => $uploadTrend,
        'largestFiles' => $largestFiles,
        'additionalStats' => [
            'encryptedFiles' => $encryptedCount,
            'sharedByMe' => $sharedByMeCount
        ]
    ];
    
    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>