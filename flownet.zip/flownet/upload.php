<?php
require_once 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $userId = $_SESSION['user_id'];
    $file = $_FILES['file'];
    $encrypt = isset($_POST['encrypt']);
    
    // Validasi file
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['error'] = 'Error saat upload file!';
        header('Location: dashboard.php');
        exit;
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        $_SESSION['error'] = 'Ukuran file terlalu besar! Maksimal ' . formatFileSize(MAX_FILE_SIZE);
        header('Location: dashboard.php');
        exit;
    }
    
    // Buat direktori upload jika belum ada
    $userDir = UPLOAD_DIR . $userId . '/';
    if (!file_exists($userDir)) {
        mkdir($userDir, 0777, true);
    }
    
    // Generate nama file unik
    $originalName = $file['name'];
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $storedName = uniqid() . '_' . time() . '.' . $extension;
    $filePath = $userDir . $storedName;
    
    try {
        $encryptionKey = null;
        
        if ($encrypt) {
            // Enkripsi file
            $tempPath = $file['tmp_name'];
            $encryptionKey = encryptFile($tempPath, $filePath);
            
            if (!$encryptionKey) {
                throw new Exception('Gagal mengenkripsi file!');
            }
        } else {
            // Upload file tanpa enkripsi
            if (!move_uploaded_file($file['tmp_name'], $filePath)) {
                throw new Exception('Gagal memindahkan file!');
            }
        }
        
        // Simpan info file ke database
        $stmt = $conn->prepare("INSERT INTO files (user_id, original_name, stored_name, file_path, file_size, file_type, encrypted, encryption_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $userId,
            $originalName,
            $storedName,
            $filePath,
            $file['size'],
            $file['type'],
            $encrypt ? 1 : 0,
            $encryptionKey
        ]);
        
        // Log aktivitas
        logActivity($conn, $userId, 'upload', "Uploaded file: $originalName");
        
        $_SESSION['success'] = 'File berhasil diupload!';
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        
        // Hapus file jika ada error
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }
}

header('Location: dashboard.php');
exit;
?>