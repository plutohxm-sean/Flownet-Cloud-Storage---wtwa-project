<?php
require __DIR__ . '/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'seannoname07@gmail.com'; // ganti dengan email kamu
    $mail->Password   = 'wbfbamgstxkccbxb'; // gunakan App Password, bukan password biasa
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom('seannoname07@gmail.com', 'FlowNet');
    $mail->addAddress('test@domain.com', 'User Test');

    $mail->isHTML(true);
    $mail->Subject = 'Tes Email dari VPS';
    $mail->Body    = '<b>Berhasil!</b> PHP dan OpenSSL di VPS sudah jalan 🎉';

    $mail->send();
    echo "Email berhasil dikirim!";
} catch (Exception $e) {
    echo "Gagal: {$mail->ErrorInfo}";
}
