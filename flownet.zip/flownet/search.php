<?php
require_once 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];
$fullName = $_SESSION['full_name'];
$userRole = $_SESSION['role'] ?? 'user';

// Get search parameters
$searchQuery = $_GET['q'] ?? '';
$fileType = $_GET['type'] ?? 'all';
$encrypted = $_GET['encrypted'] ?? 'all';
$sortBy = $_GET['sort'] ?? 'date';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

// Build SQL query
$sql = "SELECT * FROM files WHERE user_id = ?";
$params = [$userId];

// Search by filename
if (!empty($searchQuery)) {
    $sql .= " AND original_name LIKE ?";
    $params[] = "%$searchQuery%";
}

// Filter by file type
if ($fileType != 'all') {
    $extensions = [];
    switch ($fileType) {
        case 'image':
            $extensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'];
            break;
        case 'video':
            $extensions = ['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv'];
            break;
        case 'audio':
            $extensions = ['mp3', 'wav', 'ogg', 'flac', 'm4a'];
            break;
        case 'document':
            $extensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'];
            break;
        case 'archive':
            $extensions = ['zip', 'rar', '7z', 'tar', 'gz'];
            break;
    }
    
    if (!empty($extensions)) {
        $placeholders = str_repeat('?,', count($extensions) - 1) . '?';
        $sql .= " AND (";
        foreach ($extensions as $i => $ext) {
            if ($i > 0) $sql .= " OR ";
            $sql .= "original_name LIKE ?";
            $params[] = "%.$ext";
        }
        $sql .= ")";
    }
}

// Filter by encryption status
if ($encrypted != 'all') {
    $sql .= " AND encrypted = ?";
    $params[] = ($encrypted == 'yes') ? 1 : 0;
}

// Filter by date range
if (!empty($dateFrom)) {
    $sql .= " AND uploaded_at >= ?";
    $params[] = $dateFrom . ' 00:00:00';
}

if (!empty($dateTo)) {
    $sql .= " AND uploaded_at <= ?";
    $params[] = $dateTo . ' 23:59:59';
}

// Sorting
switch ($sortBy) {
    case 'name':
        $sql .= " ORDER BY original_name ASC";
        break;
    case 'size':
        $sql .= " ORDER BY file_size DESC";
        break;
    case 'date':
    default:
        $sql .= " ORDER BY uploaded_at DESC";
        break;
}

// Execute query
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$files = $stmt->fetchAll();

// Calculate stats
$totalFiles = count($files);
$totalSize = array_sum(array_column($files, 'file_size'));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Files - FlowNet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background: #1e293b;
            color: #e0e6ed;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            font-size: 14px;
        }
        
        /* Navbar */
        .navbar-modern {
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(51, 65, 85, 0.6);
            padding: 1rem 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }
        
        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 600;
            color: #fff !important;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .navbar-brand i { color: #60a5fa; font-size: 1.5rem; }
        
        .nav-link {
            color: #94a3b8 !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .nav-link:hover {
            color: #e0e6ed !important;
            background: rgba(51, 65, 85, 0.6);
        }
        
        /* Main Container */
        .main-container {
            padding: 2rem 0;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        /* Search Header */
        .search-header {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .search-title {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #e0e6ed;
        }
        
        /* Search Form */
        .search-form {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
        }
        
        .search-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-label-modern {
            font-size: 0.875rem;
            font-weight: 600;
            color: #cbd5e1;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .form-control-modern, .form-select-modern {
            background: rgba(30, 41, 59, 0.8);
            border: 1px solid rgba(51, 65, 85, 0.6);
            color: #e0e6ed;
            padding: 0.625rem 0.875rem;
            border-radius: 6px;
            font-size: 0.875rem;
            transition: all 0.2s;
        }
        
        .form-control-modern:focus, .form-select-modern:focus {
            background: rgba(30, 41, 59, 0.9);
            border-color: #3b82f6;
            color: #e0e6ed;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }
        
        .form-select-modern option {
            background: #1e293b;
            color: #e0e6ed;
        }
        
        .btn-search {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: #fff;
            border: none;
            padding: 0.625rem 1.5rem;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.875rem;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        
        .btn-reset {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #f87171;
            padding: 0.625rem 1.5rem;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.875rem;
            transition: all 0.2s;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-reset:hover {
            background: #ef4444;
            border-color: #ef4444;
            color: #fff;
        }
        
        /* Results Stats */
        .results-stats {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .stats-info {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .stat-item i {
            color: #3b82f6;
            font-size: 1.25rem;
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: #94a3b8;
        }
        
        .stat-value {
            font-size: 1.25rem;
            font-weight: 700;
            color: #e0e6ed;
        }
        
        /* Files Grid */
        .files-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .file-card {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 12px;
            padding: 1.5rem;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .file-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
            border-color: #3b82f6;
        }
        
        .file-card-header {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .file-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            flex-shrink: 0;
        }
        
        .file-icon.image { background: linear-gradient(135deg, #ec4899, #f472b6); }
        .file-icon.video { background: linear-gradient(135deg, #8b5cf6, #a78bfa); }
        .file-icon.audio { background: linear-gradient(135deg, #14b8a6, #5eead4); }
        .file-icon.document { background: linear-gradient(135deg, #f59e0b, #fbbf24); }
        .file-icon.archive { background: linear-gradient(135deg, #6366f1, #818cf8); }
        .file-icon.other { background: linear-gradient(135deg, #64748b, #94a3b8); }
        
        .file-details {
            flex: 1;
            min-width: 0;
        }
        
        .file-name {
            font-weight: 600;
            color: #e0e6ed;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .file-meta {
            font-size: 0.75rem;
            color: #94a3b8;
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .badge-encrypted {
            background: rgba(245, 158, 11, 0.2);
            color: #fbbf24;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .file-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        .btn-action {
            flex: 1;
            padding: 0.5rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            border: 1px solid;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.375rem;
            text-decoration: none;
        }
        
        .btn-primary {
            background: rgba(59, 130, 246, 0.15);
            border-color: rgba(59, 130, 246, 0.3);
            color: #60a5fa;
        }
        
        .btn-primary:hover {
            background: #3b82f6;
            color: #fff;
            border-color: #3b82f6;
        }
        
        .btn-success {
            background: rgba(34, 197, 94, 0.15);
            border-color: rgba(34, 197, 94, 0.3);
            color: #4ade80;
        }
        
        .btn-success:hover {
            background: #22c55e;
            color: #fff;
            border-color: #22c55e;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: #64748b;
        }
        
        .empty-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .search-row {
                grid-template-columns: 1fr;
            }
            
            .files-grid {
                grid-template-columns: 1fr;
            }
            
            .results-stats {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-modern">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cloud-arrow-down-fill"></i> FlowNet
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    <?php if ($userRole === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin/index.php">
                            <i class="bi bi-speedometer2"></i> Admin
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-container px-4">
        <!-- Search Header -->
        <div class="search-header">
            <h2 class="search-title"><i class="bi bi-search"></i> Advanced Search</h2>
            
            <form method="GET" action="search.php" class="search-form">
                <!-- Main Search -->
                <div class="form-group">
                    <label class="form-label-modern">Search Query</label>
                    <input type="text" name="q" class="form-control-modern" 
                           placeholder="Enter filename..." 
                           value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                
                <!-- Filters Row -->
                <div class="search-row">
                    <div class="form-group">
                        <label class="form-label-modern">File Type</label>
                        <select name="type" class="form-select-modern">
                            <option value="all" <?= $fileType == 'all' ? 'selected' : '' ?>>All Types</option>
                            <option value="image" <?= $fileType == 'image' ? 'selected' : '' ?>>Images</option>
                            <option value="video" <?= $fileType == 'video' ? 'selected' : '' ?>>Videos</option>
                            <option value="audio" <?= $fileType == 'audio' ? 'selected' : '' ?>>Audio</option>
                            <option value="document" <?= $fileType == 'document' ? 'selected' : '' ?>>Documents</option>
                            <option value="archive" <?= $fileType == 'archive' ? 'selected' : '' ?>>Archives</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label-modern">Encryption</label>
                        <select name="encrypted" class="form-select-modern">
                            <option value="all" <?= $encrypted == 'all' ? 'selected' : '' ?>>All Files</option>
                            <option value="yes" <?= $encrypted == 'yes' ? 'selected' : '' ?>>Encrypted Only</option>
                            <option value="no" <?= $encrypted == 'no' ? 'selected' : '' ?>>Not Encrypted</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label-modern">Sort By</label>
                        <select name="sort" class="form-select-modern">
                            <option value="date" <?= $sortBy == 'date' ? 'selected' : '' ?>>Upload Date (Newest)</option>
                            <option value="name" <?= $sortBy == 'name' ? 'selected' : '' ?>>Name (A-Z)</option>
                            <option value="size" <?= $sortBy == 'size' ? 'selected' : '' ?>>Size (Largest)</option>
                        </select>
                    </div>
                </div>
                
                <!-- Date Range -->
                <div class="search-row">
                    <div class="form-group">
                        <label class="form-label-modern">Date From</label>
                        <input type="date" name="date_from" class="form-control-modern" 
                               value="<?= htmlspecialchars($dateFrom) ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label-modern">Date To</label>
                        <input type="date" name="date_to" class="form-control-modern" 
                               value="<?= htmlspecialchars($dateTo) ?>">
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="search-row">
                    <button type="submit" class="btn-search">
                        <i class="bi bi-search"></i> Search
                    </button>
                    <a href="search.php" class="btn-reset">
                        <i class="bi bi-arrow-counterclockwise"></i> Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Results Stats -->
        <div class="results-stats">
            <div class="stats-info">
                <div class="stat-item">
                    <i class="bi bi-files"></i>
                    <div>
                        <div class="stat-label">Files Found</div>
                        <div class="stat-value"><?= $totalFiles ?></div>
                    </div>
                </div>
                <div class="stat-item">
                    <i class="bi bi-hdd"></i>
                    <div>
                        <div class="stat-label">Total Size</div>
                        <div class="stat-value"><?= formatFileSize($totalSize) ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Files Grid -->
        <?php if (empty($files)): ?>
            <div class="empty-state">
                <i class="bi bi-inbox empty-icon"></i>
                <h4>No files found</h4>
                <p>Try adjusting your search filters</p>
            </div>
        <?php else: ?>
            <div class="files-grid">
                <?php foreach ($files as $file): 
                    $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
                    $iconClass = 'other';
                    $iconName = 'file-earmark';
                    
                    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'])) {
                        $iconClass = 'image';
                        $iconName = 'image';
                    } elseif (in_array($ext, ['mp4', 'webm', 'ogg', 'mov', 'avi'])) {
                        $iconClass = 'video';
                        $iconName = 'play-circle';
                    } elseif (in_array($ext, ['mp3', 'wav', 'ogg', 'flac'])) {
                        $iconClass = 'audio';
                        $iconName = 'music-note';
                    } elseif (in_array($ext, ['pdf', 'doc', 'docx', 'txt'])) {
                        $iconClass = 'document';
                        $iconName = 'file-text';
                    } elseif (in_array($ext, ['zip', 'rar', '7z', 'tar'])) {
                        $iconClass = 'archive';
                        $iconName = 'file-zip';
                    }
                ?>
                    <div class="file-card">
                        <div class="file-card-header">
                            <div class="file-icon <?= $iconClass ?>">
                                <i class="bi bi-<?= $iconName ?>"></i>
                            </div>
                            <div class="file-details">
                                <div class="file-name" title="<?= htmlspecialchars($file['original_name']) ?>">
                                    <?= htmlspecialchars($file['original_name']) ?>
                                </div>
                                <div class="file-meta">
                                    <span><?= formatFileSize($file['file_size']) ?></span>
                                    <span>•</span>
                                    <span><?= date('d M Y', strtotime($file['uploaded_at'])) ?></span>
                                    <?php if ($file['encrypted']): ?>
                                        <span class="badge-encrypted">
                                            <i class="bi bi-lock-fill"></i> Encrypted
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="file-actions">
                            <a href="preview.php?id=<?= $file['id'] ?>" class="btn-action btn-primary">
                                <i class="bi bi-eye"></i> Preview
                            </a>
                            <a href="download.php?id=<?= $file['id'] ?>" class="btn-action btn-success">
                                <i class="bi bi-download"></i> Download
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>