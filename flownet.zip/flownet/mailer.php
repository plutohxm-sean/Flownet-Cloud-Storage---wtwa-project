<?php
// mailer.php - Fungsi untuk mengirim email verifikasi menggunakan PHPMailer + SMTP
// Pastikan file ini berada di folder yang sama dengan config.php dan vendor/autoload.php

require_once __DIR__ . '/config.php';        // ⬅️ Wajib! Pastikan config.php sudah berisi SMTP_USER & SMTP_PASS dari Gmail
require_once __DIR__ . '/vendor/autoload.php'; // ⬅️ Wajib! Ini dari Composer setelah install phpmailer/phpmailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Kirim email verifikasi ke user.
 *
 * @param string $email    Alamat email penerima
 * @param string $username Nama pengguna (untuk sapaan di email)
 * @param string $token    Token verifikasi (disimpan di database users)
 * @return bool True jika email berhasil dikirim, false jika gagal
 */
function sendVerificationEmail($email, $username, $token) {
    // Validasi email agar tidak error
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        error_log("sendVerificationEmail: invalid email '{$email}'");
        return false;
    }

    // ⬇️ Ini URL halaman verifikasi (ubah jika nama file verify.php kamu beda)
    $verificationLink = rtrim(BASE_URL, '/') . '/verify.php?token=' . urlencode($token) . '&email=' . urlencode($email);

    // ⬇️ HTML tampilan email - DARK THEME MATCHING FLOWNET
    $htmlMessage = "
    <!DOCTYPE html>
    <html lang='id'>
    <head>
      <meta charset='UTF-8'>
      <meta name='viewport' content='width=device-width, initial-scale=1.0'>
      <title>Verifikasi Email - FlowNet</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
          padding: 40px 20px;
        }
        .email-container {
          max-width: 600px;
          margin: 0 auto;
          background: #1e293b;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }
        .header {
          background: linear-gradient(135deg, #3b82f6, #2563eb);
          padding: 40px 30px;
          text-align: center;
        }
        .logo {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          color: white;
          font-size: 32px;
          font-weight: 700;
          text-decoration: none;
        }
        .logo-icon {
          font-size: 40px;
        }
        .content {
          padding: 40px 30px;
          color: #e0e6ed;
        }
        h2 {
          color: #60a5fa;
          font-size: 24px;
          margin-bottom: 20px;
        }
        p {
          line-height: 1.6;
          color: #94a3b8;
          margin-bottom: 20px;
          font-size: 16px;
        }
        .highlight {
          color: #e0e6ed;
          font-weight: 600;
        }
        .button-container {
          text-align: center;
          margin: 40px 0;
        }
        .button {
          display: inline-block;
          padding: 16px 40px;
          background: linear-gradient(135deg, #3b82f6, #2563eb);
          color: white;
          text-decoration: none;
          border-radius: 12px;
          font-weight: 600;
          font-size: 16px;
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        .link-box {
          background: rgba(30, 41, 59, 0.8);
          border: 1px solid rgba(51, 65, 85, 0.6);
          border-radius: 8px;
          padding: 15px;
          margin: 20px 0;
          word-break: break-all;
        }
        .link-box a {
          color: #60a5fa;
          text-decoration: none;
          font-size: 14px;
        }
        .info-box {
          background: rgba(245, 158, 11, 0.1);
          border-left: 4px solid #f59e0b;
          padding: 15px;
          margin: 20px 0;
          border-radius: 4px;
        }
        .info-box p {
          color: #fbbf24;
          margin: 0;
          font-size: 14px;
        }
        .footer {
          padding: 30px;
          text-align: center;
          color: #64748b;
          font-size: 14px;
          border-top: 1px solid rgba(51, 65, 85, 0.6);
        }
        .footer a {
          color: #60a5fa;
          text-decoration: none;
        }
        .divider {
          height: 1px;
          background: rgba(51, 65, 85, 0.6);
          margin: 30px 0;
        }
        @media only screen and (max-width: 600px) {
          .email-container { border-radius: 0; }
          .content { padding: 30px 20px; }
          .header { padding: 30px 20px; }
          .logo { font-size: 24px; }
          .logo-icon { font-size: 32px; }
          h2 { font-size: 20px; }
          .button { padding: 14px 30px; font-size: 14px; }
        }
      </style>
    </head>
    <body>
      <div class='email-container'>
        <div class='header'>
          <div class='logo'>
            <span class='logo-icon'>☁️</span>
            <span>FlowNet</span>
          </div>
        </div>
        
        <div class='content'>
          <h2>👋 Halo, " . htmlspecialchars($username) . "!</h2>
          
          <p>Terima kasih telah mendaftar di <span class='highlight'>FlowNet Storage</span>. Kami sangat senang Anda bergabung!</p>
          
          <p>Untuk mulai menggunakan layanan kami, silakan verifikasi alamat email Anda dengan mengklik tombol di bawah ini:</p>
          
          <div class='button-container'>
            <a href='" . $verificationLink . "' class='button'>
              ✓ Verifikasi Email Saya
            </a>
          </div>
          
          <div class='divider'></div>
          
          <p>Atau copy dan paste link berikut ke browser Anda:</p>
          
          <div class='link-box'>
            <a href='" . $verificationLink . "'>" . htmlspecialchars($verificationLink) . "</a>
          </div>
          
          <div class='info-box'>
            <p>⏰ Token verifikasi ini akan kedaluwarsa dalam 24 jam.</p>
          </div>
          
          <p>Jika Anda tidak mendaftar di FlowNet, abaikan email ini.</p>
        </div>
        
        <div class='footer'>
          <p>© 2024 FlowNet Storage. All rights reserved.</p>
          <p>Butuh bantuan? <a href='" . rtrim(BASE_URL, '/') . "'>Kunjungi website kami</a></p>
        </div>
      </div>
    </body>
    </html>
    ";

    // ⬇️ Versi plain text (backup jika penerima tidak mendukung HTML)
    $plainMessage = "Halo {$username},\n\nSilakan verifikasi email Anda dengan membuka link berikut:\n\n{$verificationLink}\n\nJika bukan Anda, abaikan pesan ini.";

    // 🔧 KONFIGURASI PHPMailer
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();                                  // Gunakan SMTP
        $mail->Host       = SMTP_HOST;                    // ⬅️ Biasanya 'smtp.gmail.com'
        $mail->SMTPAuth   = true;                         // Aktifkan autentikasi
        $mail->Username   = SMTP_USER;                    // ⬅️ Email Gmail kamu (mis. yourname@gmail.com)
        $mail->Password   = SMTP_PASS;                    // ⬅️ App Password dari Gmail (16 digit)
        
        // Gunakan STARTTLS (port 587) atau SSL (port 465)
        if (defined('SMTP_PORT') && SMTP_PORT == 465) {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }
        $mail->Port       = defined('SMTP_PORT') ? SMTP_PORT : 587;
        $mail->CharSet    = 'UTF-8';

        // 📤 SENDER & RECIPIENT
        $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);         // ⬅️ Nama & email pengirim (mis. FlowNet <yourmail@gmail.com>)
        $mail->addAddress($email, $username);              // Tujuan email

        // 📝 KONTEN EMAIL
        $mail->isHTML(true);
        $mail->Subject = '✨ Verifikasi Email - FlowNet Storage';
        $mail->Body    = $htmlMessage;
        $mail->AltBody = $plainMessage;

        // Opsional: tambahkan reply-to
        $mail->addReplyTo(SMTP_FROM, SMTP_FROM_NAME);

        // ✅ KIRIM EMAIL
        $mail->send();
        return true;
    } catch (Exception $e) {
        // ❌ Jika gagal, tulis ke log error
        $err = "PHPMailer Error: " . $mail->ErrorInfo . " | Exception: " . $e->getMessage();
        error_log($err);
        return false;
    }
}

/**
 * Kirim email reset password (BONUS - jika Anda punya fitur forgot password)
 */
function sendPasswordResetEmail($email, $username, $token) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        error_log("sendPasswordResetEmail: invalid email '{$email}'");
        return false;
    }

    $resetLink = rtrim(BASE_URL, '/') . '/reset_password.php?token=' . urlencode($token);

    $htmlMessage = "
    <!DOCTYPE html>
    <html lang='id'>
    <head>
      <meta charset='UTF-8'>
      <meta name='viewport' content='width=device-width, initial-scale=1.0'>
      <title>Reset Password - FlowNet</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
          padding: 40px 20px;
        }
        .email-container {
          max-width: 600px;
          margin: 0 auto;
          background: #1e293b;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }
        .header {
          background: linear-gradient(135deg, #8b5cf6, #7c3aed);
          padding: 40px 30px;
          text-align: center;
        }
        .logo {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          color: white;
          font-size: 32px;
          font-weight: 700;
        }
        .logo-icon { font-size: 40px; }
        .content {
          padding: 40px 30px;
          color: #e0e6ed;
        }
        h2 {
          color: #a78bfa;
          font-size: 24px;
          margin-bottom: 20px;
        }
        p {
          line-height: 1.6;
          color: #94a3b8;
          margin-bottom: 20px;
          font-size: 16px;
        }
        .highlight { color: #e0e6ed; font-weight: 600; }
        .button-container { text-align: center; margin: 40px 0; }
        .button {
          display: inline-block;
          padding: 16px 40px;
          background: linear-gradient(135deg, #8b5cf6, #7c3aed);
          color: white;
          text-decoration: none;
          border-radius: 12px;
          font-weight: 600;
          font-size: 16px;
          box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
        }
        .link-box {
          background: rgba(30, 41, 59, 0.8);
          border: 1px solid rgba(51, 65, 85, 0.6);
          border-radius: 8px;
          padding: 15px;
          margin: 20px 0;
          word-break: break-all;
        }
        .link-box a { color: #a78bfa; text-decoration: none; font-size: 14px; }
        .warning-box {
          background: rgba(239, 68, 68, 0.1);
          border-left: 4px solid #ef4444;
          padding: 15px;
          margin: 20px 0;
          border-radius: 4px;
        }
        .warning-box p { color: #f87171; margin: 0; font-size: 14px; }
        .info-box {
          background: rgba(245, 158, 11, 0.1);
          border-left: 4px solid #f59e0b;
          padding: 15px;
          margin: 20px 0;
          border-radius: 4px;
        }
        .info-box p { color: #fbbf24; margin: 0; font-size: 14px; }
        .footer {
          padding: 30px;
          text-align: center;
          color: #64748b;
          font-size: 14px;
          border-top: 1px solid rgba(51, 65, 85, 0.6);
        }
        .footer a { color: #a78bfa; text-decoration: none; }
        .divider {
          height: 1px;
          background: rgba(51, 65, 85, 0.6);
          margin: 30px 0;
        }
      </style>
    </head>
    <body>
      <div class='email-container'>
        <div class='header'>
          <div class='logo'>
            <span class='logo-icon'>🔐</span>
            <span>FlowNet</span>
          </div>
        </div>
        
        <div class='content'>
          <h2>Reset Password</h2>
          
          <p>Halo, <span class='highlight'>" . htmlspecialchars($username) . "</span>!</p>
          
          <p>Kami menerima permintaan untuk reset password akun FlowNet Anda. Klik tombol di bawah untuk membuat password baru:</p>
          
          <div class='button-container'>
            <a href='" . $resetLink . "' class='button'>
              🔑 Reset Password Saya
            </a>
          </div>
          
          <div class='divider'></div>
          
          <p>Atau copy dan paste link berikut ke browser Anda:</p>
          
          <div class='link-box'>
            <a href='" . $resetLink . "'>" . htmlspecialchars($resetLink) . "</a>
          </div>
          
          <div class='info-box'>
            <p>⏰ Token reset password ini akan kedaluwarsa dalam 1 jam.</p>
          </div>
          
          <div class='warning-box'>
            <p>⚠️ Jika Anda TIDAK meminta reset password, abaikan email ini dan password Anda tidak akan berubah.</p>
          </div>
          
          <p>Untuk keamanan akun Anda, pastikan menggunakan password yang kuat dan unik.</p>
        </div>
        
        <div class='footer'>
          <p>© 2024 FlowNet Storage. All rights reserved.</p>
          <p>Butuh bantuan? <a href='" . rtrim(BASE_URL, '/') . "'>Kunjungi website kami</a></p>
        </div>
      </div>
    </body>
    </html>
    ";

    $plainMessage = "Halo {$username},\n\nKlik link berikut untuk reset password:\n\n{$resetLink}\n\nToken akan kedaluwarsa dalam 1 jam.\n\nJika bukan Anda, abaikan email ini.";

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        
        if (defined('SMTP_PORT') && SMTP_PORT == 465) {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }
        $mail->Port       = defined('SMTP_PORT') ? SMTP_PORT : 587;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
        $mail->addAddress($email, $username);

        $mail->isHTML(true);
        $mail->Subject = '🔐 Reset Password - FlowNet Storage';
        $mail->Body    = $htmlMessage;
        $mail->AltBody = $plainMessage;

        $mail->addReplyTo(SMTP_FROM, SMTP_FROM_NAME);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo . " | Exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Kirim notifikasi file shared (BONUS)
 */
function sendFileSharedNotification($email, $username, $sharedBy, $fileName) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        error_log("sendFileSharedNotification: invalid email '{$email}'");
        return false;
    }

    $loginLink = rtrim(BASE_URL, '/') . '/login.php';

    $htmlMessage = "
    <!DOCTYPE html>
    <html lang='id'>
    <head>
      <meta charset='UTF-8'>
      <meta name='viewport' content='width=device-width, initial-scale=1.0'>
      <title>File Dibagikan - FlowNet</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
          padding: 40px 20px;
        }
        .email-container {
          max-width: 600px;
          margin: 0 auto;
          background: #1e293b;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }
        .header {
          background: linear-gradient(135deg, #ec4899, #d946ef);
          padding: 40px 30px;
          text-align: center;
        }
        .logo {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          color: white;
          font-size: 32px;
          font-weight: 700;
        }
        .logo-icon { font-size: 40px; }
        .content {
          padding: 40px 30px;
          color: #e0e6ed;
        }
        h2 {
          color: #f472b6;
          font-size: 24px;
          margin-bottom: 20px;
        }
        p {
          line-height: 1.6;
          color: #94a3b8;
          margin-bottom: 20px;
          font-size: 16px;
        }
        .highlight { color: #e0e6ed; font-weight: 600; }
        .file-card {
          background: rgba(30, 41, 59, 0.8);
          border: 1px solid rgba(51, 65, 85, 0.6);
          border-radius: 12px;
          padding: 20px;
          margin: 30px 0;
        }
        .file-icon {
          font-size: 48px;
          text-align: center;
          margin-bottom: 15px;
        }
        .file-name {
          color: #e0e6ed;
          font-size: 18px;
          font-weight: 600;
          text-align: center;
          word-break: break-word;
        }
        .shared-by {
          background: rgba(236, 72, 153, 0.1);
          border-left: 4px solid #ec4899;
          padding: 15px;
          margin: 20px 0;
          border-radius: 4px;
        }
        .shared-by p { color: #f472b6; margin: 0; font-size: 14px; }
        .button-container { text-align: center; margin: 40px 0; }
        .button {
          display: inline-block;
          padding: 16px 40px;
          background: linear-gradient(135deg, #ec4899, #d946ef);
          color: white;
          text-decoration: none;
          border-radius: 12px;
          font-weight: 600;
          font-size: 16px;
          box-shadow: 0 4px 12px rgba(236, 72, 153, 0.4);
        }
        .footer {
          padding: 30px;
          text-align: center;
          color: #64748b;
          font-size: 14px;
          border-top: 1px solid rgba(51, 65, 85, 0.6);
        }
        .footer a { color: #f472b6; text-decoration: none; }
        .divider {
          height: 1px;
          background: rgba(51, 65, 85, 0.6);
          margin: 30px 0;
        }
      </style>
    </head>
    <body>
      <div class='email-container'>
        <div class='header'>
          <div class='logo'>
            <span class='logo-icon'>📤</span>
            <span>FlowNet</span>
          </div>
        </div>
        
        <div class='content'>
          <h2>File Baru Dibagikan!</h2>
          
          <p>Halo, <span class='highlight'>" . htmlspecialchars($username) . "</span>!</p>
          
          <p>Ada yang spesial untuk Anda! <span class='highlight'>" . htmlspecialchars($sharedBy) . "</span> baru saja membagikan file:</p>
          
          <div class='file-card'>
            <div class='file-icon'>📄</div>
            <div class='file-name'>" . htmlspecialchars($fileName) . "</div>
          </div>
          
          <div class='shared-by'>
            <p>👤 Dibagikan oleh: <strong>" . htmlspecialchars($sharedBy) . "</strong></p>
          </div>
          
          <p>Login ke akun FlowNet Anda untuk mengakses file ini.</p>
          
          <div class='button-container'>
            <a href='" . $loginLink . "' class='button'>
              📁 Lihat File Sekarang
            </a>
          </div>
          
          <div class='divider'></div>
          
          <p>File tersedia di dashboard Anda di tab <span class='highlight'>'Shared With Me'</span>.</p>
        </div>
        
        <div class='footer'>
          <p>© 2025 FlowNet Storage. All rights reserved.</p>
          <p>Butuh bantuan? <a href='" . rtrim(BASE_URL, '/') . "'>Kunjungi website kami</a></p>
        </div>
      </div>
    </body>
    </html>
    ";

    $plainMessage = "Halo {$username},\n\n{$sharedBy} membagikan file: {$fileName}\n\nLogin untuk melihat: {$loginLink}";

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        
        if (defined('SMTP_PORT') && SMTP_PORT == 465) {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }
        $mail->Port       = defined('SMTP_PORT') ? SMTP_PORT : 587;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
        $mail->addAddress($email, $username);

        $mail->isHTML(true);
        $mail->Subject = '📁 File Dibagikan - FlowNet Storage';
        $mail->Body    = $htmlMessage;
        $mail->AltBody = $plainMessage;

        $mail->addReplyTo(SMTP_FROM, SMTP_FROM_NAME);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo . " | Exception: " . $e->getMessage());
        return false;
    }
}
?>