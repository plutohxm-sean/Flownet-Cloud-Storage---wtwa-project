<?php
require_once 'config.php';
require_once 'mailer.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fileId = $_POST['file_id'];
    $shareUsername = trim($_POST['share_username']);
    $canDownload = isset($_POST['can_download']) ? 1 : 0;
    $userId = $_SESSION['user_id'];
    
    try {
        // Cek apakah file milik user
        $stmt = $conn->prepare("SELECT * FROM files WHERE id = ? AND user_id = ?");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if (!$file) {
            $_SESSION['error'] = 'File tidak ditemukan!';
            header('Location: dashboard.php');
            exit;
        }
        
        // Cek apakah user tujuan ada
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$shareUsername]);
        $targetUser = $stmt->fetch();
        
        if (!$targetUser) {
            $_SESSION['error'] = 'User tidak ditemukan!';
            header('Location: dashboard.php');
            exit;
        }
        
        // Tidak bisa share ke diri sendiri
        if ($targetUser['id'] == $userId) {
            $_SESSION['error'] = 'Tidak bisa membagikan file ke diri sendiri!';
            header('Location: dashboard.php');
            exit;
        }
        
        // Cek apakah sudah pernah dibagikan
        $stmt = $conn->prepare("SELECT * FROM shared_files WHERE file_id = ? AND shared_with = ?");
        $stmt->execute([$fileId, $targetUser['id']]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['error'] = 'File sudah dibagikan ke user ini!';
            header('Location: dashboard.php');
            exit;
        }
        
        // Insert share record
        $stmt = $conn->prepare("INSERT INTO shared_files (file_id, shared_by, shared_with, can_download) VALUES (?, ?, ?, ?)");
        $stmt->execute([$fileId, $userId, $targetUser['id'], $canDownload]);
        
        // Kirim notifikasi email
        sendFileSharedNotification($targetUser['email'], $targetUser['username'], $_SESSION['username'], $file['original_name']);
        
        // Log aktivitas
        logActivity($conn, $userId, 'share', "Shared file '{$file['original_name']}' with {$targetUser['username']}");
        
        $_SESSION['success'] = 'File berhasil dibagikan!';
        
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
    }
}

header('Location: dashboard.php');
exit;
?>