-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2025 at 08:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opm_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `id` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_transaksi`
--

INSERT INTO `detail_transaksi` (`id`, `id_transaksi`, `id_produk`, `nama_produk`, `harga`, `jumlah`, `subtotal`) VALUES
(1, 1, 3, 'Pulpen Standard', 3000.00, 5, 15000.00),
(2, 2, 3, 'Pulpen Standard', 3000.00, 1, 3000.00),
(3, 3, 3, 'Pulpen Standard', 3000.00, 1, 3000.00),
(4, 4, 2, 'Buku Bahasa Indonesia Kelas 3 SD', 50000.00, 1, 50000.00),
(5, 5, 2, 'Buku Bahasa Indonesia Kelas 3 SD', 50000.00, 1, 50000.00),
(6, 6, 7, 'Penghapus', 2000.00, 1, 2000.00),
(7, 7, 7, 'Penghapus', 2000.00, 1, 2000.00),
(8, 8, 1, 'Buku Matematika Kelas 1 SD', 45000.00, 2, 90000.00),
(9, 9, 1, 'Buku Matematika Kelas 1 SD', 45000.00, 1, 45000.00),
(10, 10, 1, 'Buku Matematika Kelas 1 SD', 45000.00, 1, 45000.00),
(11, 11, 1, 'Buku Matematika Kelas 1 SD', 45000.00, 2, 90000.00),
(12, 12, 1, 'Buku Matematika Kelas 1 SD', 45000.00, 1, 45000.00);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama_kategori`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'Buku Sekolah', 'Buku pelajaran untuk tingkat SD, SMP, SMA', '2025-11-12 14:21:14', '2025-11-12 14:21:14'),
(2, 'Alat Tulis Kantor', 'Perlengkapan tulis menulis', '2025-11-12 14:21:14', '2025-11-14 04:00:38'),
(3, 'Alat Kesehatan', 'Peralatan kesehatan standar', '2025-11-12 14:21:14', '2025-11-14 13:10:54');

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id`, `id_user`, `id_produk`, `jumlah`, `created_at`) VALUES
(17, 6, 2, 3, '2025-11-14 15:14:08');

-- --------------------------------------------------------

--
-- Table structure for table `log_aktivitas`
--

CREATE TABLE `log_aktivitas` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `aktivitas` text NOT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_aktivitas`
--

INSERT INTO `log_aktivitas` (`id`, `id_user`, `aktivitas`, `ip_address`, `created_at`) VALUES
(1, NULL, 'Registrasi akun baru - Username: erlan', '::1', '2025-11-13 07:54:24'),
(2, NULL, 'Registrasi akun baru - Username: cici', '::1', '2025-11-13 08:01:19'),
(3, 4, 'Registrasi akun baru - Username: erlan', '::1', '2025-11-13 08:07:04'),
(4, 4, 'Login berhasil', '::1', '2025-11-13 08:07:30'),
(5, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-13 08:09:50'),
(6, 1, 'Login berhasil', '::1', '2025-11-13 08:10:36'),
(7, 1, 'Logout dari sistem - Username: admin', '::1', '2025-11-13 08:12:03'),
(8, 4, 'Login berhasil', '::1', '2025-11-13 08:12:17'),
(9, 4, 'Menambah ke keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '::1', '2025-11-13 08:19:49'),
(10, 4, 'Mengosongkan keranjang belanja', '::1', '2025-11-13 08:21:35'),
(11, 4, 'Menambah ke keranjang: Pulpen Standard - Jumlah: 1', '::1', '2025-11-13 08:21:38'),
(12, 4, 'Menambah ke keranjang: Hekter Joyko - Jumlah: 1', '::1', '2025-11-13 08:21:42'),
(13, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-13 08:24:36'),
(14, 1, 'Login berhasil', '::1', '2025-11-13 08:25:01'),
(15, 1, 'Logout dari sistem - Username: admin', '::1', '2025-11-13 08:28:05'),
(16, 4, 'Login berhasil', '::1', '2025-11-13 08:28:23'),
(17, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-13 08:31:33'),
(18, 1, 'Login berhasil', '::1', '2025-11-13 08:31:47'),
(19, 1, 'Login berhasil', '::1', '2025-11-13 09:07:54'),
(20, 1, 'Logout dari sistem - Username: admin', '::1', '2025-11-13 11:27:35'),
(21, 4, 'Login berhasil', '::1', '2025-11-13 11:27:52'),
(22, 4, 'Menghapus dari keranjang: Pulpen Standard', '::1', '2025-11-13 11:28:35'),
(23, 4, 'Update jumlah keranjang: Hekter Joyko - Jumlah: 2', '::1', '2025-11-13 11:29:10'),
(24, 4, 'Update jumlah keranjang: Hekter Joyko - Jumlah: 1', '::1', '2025-11-13 11:29:12'),
(25, 4, 'Update jumlah keranjang: Hekter Joyko - Jumlah: 2', '::1', '2025-11-13 11:29:15'),
(26, 4, 'Menghapus dari keranjang: Hekter Joyko', '::1', '2025-11-13 11:29:17'),
(27, 4, 'Menambah ke keranjang: Pulpen Standard - Jumlah: 2', '::1', '2025-11-13 11:29:52'),
(28, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-13 12:45:48'),
(29, 4, 'Login berhasil', '::1', '2025-11-13 12:46:03'),
(30, 4, 'Update keranjang: Pulpen Standard - Jumlah: 4', '::1', '2025-11-13 12:46:06'),
(31, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-13 15:21:39'),
(32, 1, 'Login berhasil', '::1', '2025-11-13 15:22:02'),
(33, 1, 'Logout dari sistem - Username: admin', '::1', '2025-11-13 15:24:56'),
(34, 4, 'Login berhasil', '::1', '2025-11-13 15:25:12'),
(35, 4, 'Update keranjang: Pulpen Standard - Jumlah: 5', '::1', '2025-11-13 15:26:06'),
(36, 4, 'Membuat transaksi baru ID: 1 - Total: Rp 15.000', '::1', '2025-11-13 18:26:12'),
(37, 4, 'Menambah ke keranjang: Pulpen Standard - Jumlah: 1', '::1', '2025-11-13 18:26:42'),
(38, 4, 'Membuat transaksi baru ID: 2 - Total: Rp 3.000', '::1', '2025-11-13 18:26:52'),
(39, 4, 'Menambah ke keranjang: Pulpen Standard - Jumlah: 1', '::1', '2025-11-13 18:28:04'),
(40, 4, 'Membuat transaksi baru ID: 3 - Total: Rp 3.000', '::1', '2025-11-13 18:29:31'),
(41, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-13 18:33:31'),
(42, 4, 'Login berhasil', '::1', '2025-11-13 18:33:45'),
(43, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-13 19:22:51'),
(44, 1, 'Login berhasil', '::1', '2025-11-13 19:23:18'),
(45, 4, 'Login berhasil', '::1', '2025-11-14 03:00:10'),
(46, 4, 'Menambah ke keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '::1', '2025-11-14 03:00:24'),
(47, 4, 'Membuat transaksi baru ID: 4 - Total: Rp 50.000', '::1', '2025-11-14 03:00:56'),
(48, 4, 'Upload bukti bayar transaksi ID: 4', '::1', '2025-11-14 03:01:30'),
(49, 4, 'Upload bukti bayar transaksi ID: 4', '::1', '2025-11-14 03:03:11'),
(50, 4, 'Upload bukti bayar transaksi ID: 4', '::1', '2025-11-14 03:05:33'),
(51, 4, 'Memberikan review produk ID: 3 - Rating: 5', '::1', '2025-11-14 03:08:37'),
(52, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 03:13:08'),
(53, 1, 'Login berhasil', '::1', '2025-11-14 03:13:25'),
(54, 5, 'Registrasi akun baru - Username: biawak', '10.252.128.14', '2025-11-14 03:33:55'),
(55, 5, 'Login berhasil', '10.252.128.14', '2025-11-14 03:34:18'),
(56, 5, 'Menambah ke keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '10.252.128.14', '2025-11-14 03:34:34'),
(57, 5, 'Membuat transaksi baru ID: 5 - Total: Rp 50.000', '10.252.128.14', '2025-11-14 03:34:41'),
(58, 5, 'Memberikan review produk ID: 2 - Rating: 5', '10.252.128.14', '2025-11-14 03:35:15'),
(59, 5, 'Logout dari sistem - Username: biawak', '10.252.128.14', '2025-11-14 03:35:38'),
(60, 1, 'Login berhasil', '10.252.128.14', '2025-11-14 03:35:55'),
(61, 1, 'Menambah produk baru: Penghapus (ID: 7)', '10.252.128.14', '2025-11-14 03:38:03'),
(62, 1, 'Login berhasil', '::1', '2025-11-14 03:39:27'),
(63, 1, 'Update status transaksi ID: 1 dari \'menunggu pembayaran\' ke \'pembayaran berhasil\'', '::1', '2025-11-14 03:57:24'),
(64, 1, 'Menambah kategori: Makanan dan Minuman', '::1', '2025-11-14 04:00:23'),
(65, 1, 'Update kategori ID: 2', '::1', '2025-11-14 04:00:38'),
(66, 1, 'Menghapus produk: Masker 3 Ply (ID: 6)', '::1', '2025-11-14 04:09:53'),
(67, 4, 'Login berhasil', '::1', '2025-11-14 05:37:39'),
(68, 4, 'Menambah ke keranjang: Penghapus - Jumlah: 1', '::1', '2025-11-14 05:37:51'),
(69, 4, 'Membuat transaksi baru ID: 6 - Total: Rp 2.000', '::1', '2025-11-14 05:38:07'),
(70, 4, 'Upload bukti bayar transaksi ID: 6', '::1', '2025-11-14 05:38:16'),
(71, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 05:39:03'),
(72, 1, 'Login berhasil', '::1', '2025-11-14 05:39:28'),
(73, 1, 'Update status transaksi ID: 6 dari \'menunggu pembayaran\' ke \'pesanan selesai\'', '::1', '2025-11-14 05:39:59'),
(74, 1, 'Update status transaksi ID: 4 dari \'menunggu pembayaran\' ke \'pesanan selesai\'', '::1', '2025-11-14 05:40:05'),
(75, 1, 'Login berhasil', '127.0.0.1', '2025-11-14 05:52:52'),
(76, 1, 'Update status transaksi ID: 5 dari \'pesanan selesai\' ke \'barang diterima\'', '127.0.0.1', '2025-11-14 05:53:29'),
(77, 1, 'Update status transaksi ID: 5 dari \'barang diterima\' ke \'pembayaran berhasil\'', '127.0.0.1', '2025-11-14 05:53:43'),
(78, 1, 'Update status transaksi ID: 3 dari \'menunggu pembayaran\' ke \'pesanan selesai\'', '127.0.0.1', '2025-11-14 05:53:51'),
(79, 1, 'Update status transaksi ID: 5 dari \'pembayaran berhasil\' ke \'pesanan selesai\'', '127.0.0.1', '2025-11-14 05:53:56'),
(80, 1, 'Update status transaksi ID: 1 dari \'pembayaran berhasil\' ke \'pesanan selesai\'', '127.0.0.1', '2025-11-14 05:54:02'),
(81, 1, 'Logout dari sistem - Username: admin', '127.0.0.1', '2025-11-14 06:02:11'),
(82, 4, 'Login berhasil', '127.0.0.1', '2025-11-14 06:05:22'),
(83, 4, 'Menambah ke keranjang: Penghapus - Jumlah: 1', '127.0.0.1', '2025-11-14 06:05:29'),
(84, 4, 'Membuat transaksi baru ID: 7 - Total: Rp 2.000', '127.0.0.1', '2025-11-14 06:05:47'),
(85, 4, 'Upload bukti bayar transaksi ID: 7', '127.0.0.1', '2025-11-14 06:06:10'),
(86, 4, 'Logout dari sistem - Username: erlan', '127.0.0.1', '2025-11-14 06:06:30'),
(87, 1, 'Login berhasil', '127.0.0.1', '2025-11-14 06:06:56'),
(88, 1, 'Menambah kategori: Sate', '127.0.0.1', '2025-11-14 06:11:39'),
(89, 1, 'Update status transaksi ID: 7 dari \'menunggu pembayaran\' ke \'pesanan selesai\'', '127.0.0.1', '2025-11-14 06:26:07'),
(90, 1, 'Update kategori ID: 3', '127.0.0.1', '2025-11-14 06:26:39'),
(91, 1, 'Menghapus kategori ID: 5', '127.0.0.1', '2025-11-14 06:26:47'),
(92, 1, 'Menambah kategori: kjm', '127.0.0.1', '2025-11-14 06:26:59'),
(93, 1, 'Menghapus kategori ID: 6', '127.0.0.1', '2025-11-14 06:27:03'),
(94, 1, 'Menghapus produk: Penghapus Steadtler (ID: 5)', '127.0.0.1', '2025-11-14 06:27:33'),
(95, 1, 'Menambah produk baru: kmkm (ID: 8)', '127.0.0.1', '2025-11-14 06:27:53'),
(96, 1, 'Menghapus produk: kmkm (ID: 8)', '127.0.0.1', '2025-11-14 06:27:57'),
(97, 1, 'Logout dari sistem - Username: admin', '127.0.0.1', '2025-11-14 06:28:48'),
(98, 4, 'Login berhasil', '127.0.0.1', '2025-11-14 06:29:12'),
(99, 4, 'Menambah ke keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '127.0.0.1', '2025-11-14 06:29:45'),
(100, 4, 'Update keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '127.0.0.1', '2025-11-14 06:29:58'),
(101, 4, 'Membuat transaksi baru ID: 8 - Total: Rp 90.000', '127.0.0.1', '2025-11-14 06:30:06'),
(102, 4, 'Menambah ke keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '127.0.0.1', '2025-11-14 06:30:17'),
(103, 4, 'Membuat transaksi baru ID: 9 - Total: Rp 45.000', '127.0.0.1', '2025-11-14 06:30:26'),
(104, 4, 'Upload bukti bayar transaksi ID: 9', '127.0.0.1', '2025-11-14 06:30:40'),
(105, 4, 'Upload bukti bayar transaksi ID: 9', '127.0.0.1', '2025-11-14 06:32:42'),
(106, 4, 'Memberikan review produk ID: 7 - Rating: 4', '127.0.0.1', '2025-11-14 06:33:16'),
(107, 4, 'Logout dari sistem - Username: erlan', '127.0.0.1', '2025-11-14 06:34:16'),
(108, 1, 'Login berhasil', '127.0.0.1', '2025-11-14 06:34:37'),
(109, 1, 'Update status transaksi ID: 9 dari \'menunggu pembayaran\' ke \'pesanan selesai\'', '127.0.0.1', '2025-11-14 06:34:49'),
(110, 1, 'Update status transaksi ID: 8 dari \'menunggu pembayaran\' ke \'pesanan selesai\'', '127.0.0.1', '2025-11-14 06:34:53'),
(111, 1, 'Menghapus kategori ID: 4', '127.0.0.1', '2025-11-14 07:06:17'),
(112, 1, 'Menghapus produk: Hekter Joyko (ID: 4)', '127.0.0.1', '2025-11-14 07:16:26'),
(113, 1, 'Mengupdate produk: Penghapus (ID: 7)', '127.0.0.1', '2025-11-14 07:31:29'),
(114, 1, 'Mengupdate rekening bank ID: 2 (Bank BCA)', '127.0.0.1', '2025-11-14 07:37:05'),
(115, 1, 'Menambah rekening bank baru: jdijwnc (ID: 4)', '127.0.0.1', '2025-11-14 07:37:24'),
(116, 1, 'Logout dari sistem - Username: admin', '127.0.0.1', '2025-11-14 07:38:08'),
(117, 4, 'Login berhasil', '127.0.0.1', '2025-11-14 07:38:24'),
(118, 4, 'Menambah ke keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '127.0.0.1', '2025-11-14 07:38:28'),
(119, 4, 'Membuat transaksi baru ID: 10 - Total: Rp 45.000', '127.0.0.1', '2025-11-14 07:38:34'),
(120, 4, 'Logout dari sistem - Username: erlan', '127.0.0.1', '2025-11-14 07:39:11'),
(121, 1, 'Login berhasil', '127.0.0.1', '2025-11-14 07:39:25'),
(122, 1, 'Update status transaksi ID: 10 dari \'menunggu pembayaran\' ke \'barang dalam pengiriman\'', '127.0.0.1', '2025-11-14 07:39:35'),
(123, 1, 'Menghapus rekening bank: jdijwnc (ID: 4)', '127.0.0.1', '2025-11-14 07:40:21'),
(124, 1, 'Login berhasil', '::1', '2025-11-14 13:10:25'),
(125, 1, 'Update kategori ID: 3', '::1', '2025-11-14 13:10:54'),
(126, 1, 'Mengupdate produk: Buku Matematika Kelas 1 SD (ID: 1)', '::1', '2025-11-14 13:12:14'),
(127, 1, 'Mengupdate produk: Buku Bahasa Indonesia Kelas 3 SD (ID: 2)', '::1', '2025-11-14 13:12:21'),
(128, 1, 'Mengupdate produk: Pulpen Standard (ID: 3)', '::1', '2025-11-14 13:12:31'),
(129, 1, 'Update status transaksi ID: 10 dari \'barang dalam pengiriman\' ke \'pesanan selesai\'', '::1', '2025-11-14 13:12:42'),
(130, 1, 'Logout dari sistem - Username: admin', '::1', '2025-11-14 13:19:06'),
(131, 4, 'Login berhasil', '::1', '2025-11-14 13:19:20'),
(132, 4, 'Menambah ke keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 13:25:48'),
(133, 4, 'Membuat transaksi baru ID: 11 - Total: Rp 90.000', '::1', '2025-11-14 13:26:25'),
(134, 4, 'Upload bukti bayar transaksi ID: 11', '::1', '2025-11-14 13:27:02'),
(135, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 13:27:19'),
(136, 1, 'Login berhasil', '::1', '2025-11-14 13:27:36'),
(137, 1, 'Update status transaksi ID: 11 dari \'menunggu pembayaran\' ke \'pesanan selesai\'', '::1', '2025-11-14 13:27:46'),
(138, 1, 'Logout dari sistem - Username: admin', '::1', '2025-11-14 13:29:12'),
(139, 4, 'Login berhasil', '::1', '2025-11-14 13:29:33'),
(140, 4, 'Memberikan review produk ID: 1 - Rating: 5', '::1', '2025-11-14 13:29:44'),
(141, 4, 'Memberikan review produk ID: 1 - Rating: 5', '::1', '2025-11-14 13:29:54'),
(142, 4, 'Memberikan review produk ID: 1 - Rating: 4', '::1', '2025-11-14 13:30:05'),
(143, 4, 'Memberikan review produk ID: 1 - Rating: 5', '::1', '2025-11-14 13:30:14'),
(144, 4, 'Memberikan review produk ID: 7 - Rating: 5', '::1', '2025-11-14 13:30:33'),
(145, 4, 'Memberikan review produk ID: 2 - Rating: 5', '::1', '2025-11-14 13:30:43'),
(146, 4, 'Memberikan review produk ID: 3 - Rating: 4', '::1', '2025-11-14 13:30:55'),
(147, 4, 'Memberikan review produk ID: 3 - Rating: 5', '::1', '2025-11-14 13:31:09'),
(148, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 13:38:00'),
(149, 4, 'Login berhasil', '::1', '2025-11-14 13:39:54'),
(150, 4, 'Menambah ke keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 13:40:03'),
(151, 4, 'Membuat transaksi baru ID: 12 - Total: Rp 45.000', '::1', '2025-11-14 13:40:23'),
(152, 4, 'Upload bukti bayar transaksi ID: 12', '::1', '2025-11-14 13:40:34'),
(153, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 13:40:47'),
(154, 1, 'Login berhasil', '::1', '2025-11-14 13:41:00'),
(155, 1, 'Update status transaksi ID: 12 dari \'menunggu pembayaran\' ke \'pembayaran berhasil\'', '::1', '2025-11-14 13:42:13'),
(156, 1, 'Update status transaksi ID: 12 dari \'pembayaran berhasil\' ke \'barang dalam pengiriman\'', '::1', '2025-11-14 13:42:15'),
(157, 1, 'Update status transaksi ID: 12 dari \'barang dalam pengiriman\' ke \'pesanan selesai\'', '::1', '2025-11-14 13:42:19'),
(158, 1, 'Logout dari sistem - Username: admin', '::1', '2025-11-14 13:42:27'),
(159, 4, 'Login berhasil', '::1', '2025-11-14 13:42:40'),
(160, 4, 'Memberikan review produk ID: 1 - Rating: 5', '::1', '2025-11-14 13:42:54'),
(161, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 13:43:10'),
(162, 1, 'Login berhasil', '::1', '2025-11-14 13:43:23'),
(163, 4, 'Login berhasil', '::1', '2025-11-14 15:07:41'),
(164, 4, 'Menambah ke keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '::1', '2025-11-14 15:07:46'),
(165, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 15:09:21'),
(166, 4, 'Login berhasil', '::1', '2025-11-14 15:11:15'),
(167, 4, 'Update keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 3', '::1', '2025-11-14 15:11:21'),
(168, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 2', '::1', '2025-11-14 15:11:28'),
(169, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 3', '::1', '2025-11-14 15:11:29'),
(170, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 4', '::1', '2025-11-14 15:11:30'),
(171, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 5', '::1', '2025-11-14 15:11:31'),
(172, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 4', '::1', '2025-11-14 15:11:32'),
(173, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 3', '::1', '2025-11-14 15:11:33'),
(174, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 2', '::1', '2025-11-14 15:11:34'),
(175, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '::1', '2025-11-14 15:11:34'),
(176, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 2', '::1', '2025-11-14 15:11:37'),
(177, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 3', '::1', '2025-11-14 15:11:38'),
(178, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 2', '::1', '2025-11-14 15:11:38'),
(179, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '::1', '2025-11-14 15:11:39'),
(180, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 2', '::1', '2025-11-14 15:11:43'),
(181, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 3', '::1', '2025-11-14 15:11:44'),
(182, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 4', '::1', '2025-11-14 15:11:45'),
(183, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 3', '::1', '2025-11-14 15:11:47'),
(184, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 2', '::1', '2025-11-14 15:11:47'),
(185, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '::1', '2025-11-14 15:11:47'),
(186, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 2', '::1', '2025-11-14 15:11:52'),
(187, 4, 'Update jumlah keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 1', '::1', '2025-11-14 15:11:54'),
(188, 4, 'Menghapus dari keranjang: Buku Bahasa Indonesia Kelas 3 SD', '::1', '2025-11-14 15:12:15'),
(189, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 15:12:36'),
(190, 6, 'Registrasi akun baru - Username: sean', '::1', '2025-11-14 15:13:21'),
(191, 6, 'Login berhasil', '::1', '2025-11-14 15:13:43'),
(192, 6, 'Menambah ke keranjang: Buku Bahasa Indonesia Kelas 3 SD - Jumlah: 3', '::1', '2025-11-14 15:14:08'),
(193, 6, 'Logout dari sistem - Username: sean', '::1', '2025-11-14 15:14:16'),
(194, 1, 'Login berhasil', '127.0.0.1', '2025-11-14 15:15:57'),
(195, 4, 'Login berhasil', '::1', '2025-11-14 15:22:54'),
(196, 4, 'Menambah ke keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:22:58'),
(197, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:22:59'),
(198, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:23:00'),
(199, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:23:02'),
(200, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 3', '::1', '2025-11-14 15:23:02'),
(201, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:23:03'),
(202, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:25:48'),
(203, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:25:50'),
(204, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:25:51'),
(205, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:09'),
(206, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 3', '::1', '2025-11-14 15:29:12'),
(207, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 4', '::1', '2025-11-14 15:29:12'),
(208, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 5', '::1', '2025-11-14 15:29:13'),
(209, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 6', '::1', '2025-11-14 15:29:14'),
(210, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 5', '::1', '2025-11-14 15:29:15'),
(211, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 4', '::1', '2025-11-14 15:29:15'),
(212, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 3', '::1', '2025-11-14 15:29:15'),
(213, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:16'),
(214, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:29:16'),
(215, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:19'),
(216, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 3', '::1', '2025-11-14 15:29:20'),
(217, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:21'),
(218, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 3', '::1', '2025-11-14 15:29:21'),
(219, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:32'),
(220, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:29:32'),
(221, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:34'),
(222, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:29:35'),
(223, 4, 'Update keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:45'),
(224, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 3', '::1', '2025-11-14 15:29:47'),
(225, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:48'),
(226, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 1', '::1', '2025-11-14 15:29:48'),
(227, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 2', '::1', '2025-11-14 15:29:50'),
(228, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 3', '::1', '2025-11-14 15:29:51'),
(229, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 4', '::1', '2025-11-14 15:29:51'),
(230, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 5', '::1', '2025-11-14 15:29:52'),
(231, 4, 'Menambah ke keranjang: Pulpen Standard - Jumlah: 1', '::1', '2025-11-14 15:29:56'),
(232, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 6', '::1', '2025-11-14 15:29:57'),
(233, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 7', '::1', '2025-11-14 15:29:58'),
(234, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 8', '::1', '2025-11-14 15:29:58'),
(235, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 9', '::1', '2025-11-14 15:29:59'),
(236, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 8', '::1', '2025-11-14 15:30:00'),
(237, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 7', '::1', '2025-11-14 15:30:01'),
(238, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 6', '::1', '2025-11-14 15:30:01'),
(239, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 5', '::1', '2025-11-14 15:30:01'),
(240, 4, 'Update jumlah keranjang: Buku Matematika Kelas 1 SD - Jumlah: 4', '::1', '2025-11-14 15:30:02'),
(241, 4, 'Menghapus dari keranjang: Pulpen Standard', '::1', '2025-11-14 15:30:04'),
(242, 4, 'Menghapus dari keranjang: Buku Matematika Kelas 1 SD', '::1', '2025-11-14 15:30:06'),
(243, 4, 'Logout dari sistem - Username: erlan', '::1', '2025-11-14 15:30:09'),
(244, 1, 'Login berhasil', '::1', '2025-11-14 15:30:21');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id` int(11) NOT NULL,
  `id_pengirim` int(11) NOT NULL,
  `id_penerima` int(11) NOT NULL,
  `pesan` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id`, `id_pengirim`, `id_penerima`, `pesan`, `is_read`, `created_at`) VALUES
(1, 4, 1, 'halo', 1, '2025-11-14 03:12:36'),
(2, 5, 1, 'cuy', 1, '2025-11-14 03:34:24'),
(3, 1, 5, 'kenapa?', 0, '2025-11-14 03:40:55'),
(4, 1, 4, 'ou', 1, '2025-11-14 03:41:01'),
(5, 1, 5, 'ok', 0, '2025-11-14 06:38:12'),
(6, 1, 5, 'ok', 0, '2025-11-14 06:38:42'),
(7, 1, 5, 'ok', 0, '2025-11-14 06:39:13'),
(8, 1, 5, 'ok', 0, '2025-11-14 06:39:44'),
(9, 1, 5, 'ok', 0, '2025-11-14 06:40:15'),
(10, 1, 5, 'ok', 0, '2025-11-14 06:40:46'),
(11, 1, 5, 'ok', 0, '2025-11-14 06:41:17'),
(12, 1, 5, 'ok', 0, '2025-11-14 06:41:48'),
(13, 1, 5, 'ok', 0, '2025-11-14 06:42:19'),
(14, 1, 5, 'ok', 0, '2025-11-14 06:42:50'),
(15, 1, 5, 'ok', 0, '2025-11-14 06:43:21'),
(16, 1, 5, 'ok', 0, '2025-11-14 06:43:54'),
(17, 1, 5, 'ok', 0, '2025-11-14 06:44:24'),
(18, 1, 5, 'ok', 0, '2025-11-14 06:44:55'),
(19, 1, 5, 'ok', 0, '2025-11-14 06:45:26'),
(20, 1, 5, 'ok', 0, '2025-11-14 06:45:57'),
(21, 1, 5, 'ok', 0, '2025-11-14 06:46:28'),
(22, 1, 5, 'ok', 0, '2025-11-14 06:46:59'),
(23, 1, 5, 'ok', 0, '2025-11-14 06:47:30'),
(24, 1, 5, 'ok', 0, '2025-11-14 06:48:01'),
(25, 1, 5, 'ok', 0, '2025-11-14 06:48:32'),
(26, 1, 5, 'ok', 0, '2025-11-14 06:49:03'),
(27, 1, 5, 'ok', 0, '2025-11-14 06:49:34'),
(28, 1, 5, 'ok', 0, '2025-11-14 06:50:05'),
(29, 1, 5, 'ok', 0, '2025-11-14 06:50:36'),
(30, 1, 5, 'ok', 0, '2025-11-14 06:51:07'),
(31, 1, 5, 'ok', 0, '2025-11-14 06:51:38'),
(32, 1, 5, 'ok', 0, '2025-11-14 06:52:09'),
(33, 1, 5, 'ok', 0, '2025-11-14 06:52:40'),
(34, 1, 5, 'ok', 0, '2025-11-14 06:53:11'),
(35, 1, 5, 'ok', 0, '2025-11-14 06:53:42'),
(36, 1, 5, 'ok', 0, '2025-11-14 06:54:13'),
(37, 1, 5, 'ok', 0, '2025-11-14 06:54:44'),
(38, 1, 5, 'ok', 0, '2025-11-14 06:55:15'),
(39, 1, 5, 'ok', 0, '2025-11-14 06:55:46'),
(40, 1, 5, 'ok', 0, '2025-11-14 06:56:17'),
(41, 1, 5, 'ok', 0, '2025-11-14 06:56:49'),
(42, 1, 5, 'ok', 0, '2025-11-14 06:57:19'),
(43, 1, 5, 'ok', 0, '2025-11-14 06:57:50'),
(44, 1, 5, 'ok', 0, '2025-11-14 06:58:21'),
(45, 1, 5, 'ok', 0, '2025-11-14 06:58:52'),
(46, 1, 5, 'ok', 0, '2025-11-14 06:59:23'),
(47, 1, 5, 'ok', 0, '2025-11-14 06:59:54'),
(48, 1, 5, 'ok', 0, '2025-11-14 07:00:25'),
(49, 1, 5, 'ok', 0, '2025-11-14 07:00:57'),
(50, 1, 5, 'ok', 0, '2025-11-14 07:01:27'),
(51, 1, 5, 'ok', 0, '2025-11-14 07:01:58'),
(52, 1, 5, 'ok', 0, '2025-11-14 07:02:29'),
(53, 1, 5, 'ok', 0, '2025-11-14 07:03:00'),
(54, 1, 5, 'ok', 0, '2025-11-14 07:03:31'),
(55, 1, 5, 'ok', 0, '2025-11-14 07:04:02'),
(56, 1, 5, 'ok', 0, '2025-11-14 07:04:33'),
(57, 1, 5, 'ok', 0, '2025-11-14 07:05:04'),
(58, 1, 5, 'ok', 0, '2025-11-14 07:05:36'),
(59, 1, 5, 'ok', 0, '2025-11-14 07:06:07'),
(60, 1, 5, 'ok', 0, '2025-11-14 07:06:37'),
(61, 1, 5, 'ok', 0, '2025-11-14 07:07:08'),
(62, 1, 5, 'ok', 0, '2025-11-14 07:07:39'),
(63, 1, 5, 'ok', 0, '2025-11-14 07:08:10'),
(64, 1, 5, 'ok', 0, '2025-11-14 07:08:41'),
(65, 1, 5, 'ok', 0, '2025-11-14 07:09:13'),
(66, 1, 5, 'ok', 0, '2025-11-14 07:09:43'),
(67, 1, 5, 'ok', 0, '2025-11-14 07:10:14'),
(68, 1, 5, 'ok', 0, '2025-11-14 07:10:45'),
(69, 1, 5, 'ok', 0, '2025-11-14 07:11:16'),
(70, 1, 5, 'ok', 0, '2025-11-14 07:11:47'),
(71, 1, 5, 'ok', 0, '2025-11-14 07:12:19'),
(72, 1, 5, 'ok', 0, '2025-11-14 07:12:49'),
(73, 1, 5, 'ok', 0, '2025-11-14 07:13:20'),
(74, 1, 5, 'ok', 0, '2025-11-14 07:13:52'),
(75, 1, 5, 'ok', 0, '2025-11-14 07:14:23'),
(76, 1, 5, 'ok', 0, '2025-11-14 07:14:54'),
(77, 1, 5, 'ok', 0, '2025-11-14 07:15:25'),
(78, 1, 5, 'ok', 0, '2025-11-14 07:15:56'),
(79, 1, 5, 'ok', 0, '2025-11-14 07:16:26'),
(80, 1, 5, 'ok', 0, '2025-11-14 07:16:58'),
(81, 1, 5, 'ok', 0, '2025-11-14 07:17:28'),
(82, 1, 5, 'ok', 0, '2025-11-14 07:18:00'),
(83, 1, 5, 'ok', 0, '2025-11-14 07:18:30'),
(84, 1, 5, 'ok', 0, '2025-11-14 07:19:01'),
(85, 1, 5, 'ok', 0, '2025-11-14 07:19:33'),
(86, 1, 5, 'ok', 0, '2025-11-14 07:20:03'),
(87, 1, 5, 'ok', 0, '2025-11-14 07:20:34'),
(88, 1, 5, 'ok', 0, '2025-11-14 07:21:05'),
(89, 1, 5, 'ok', 0, '2025-11-14 07:21:36'),
(90, 1, 5, 'ok', 0, '2025-11-14 07:22:07'),
(91, 1, 5, 'ok', 0, '2025-11-14 07:22:38'),
(92, 1, 5, 'ok', 0, '2025-11-14 07:23:09'),
(93, 1, 5, 'ok', 0, '2025-11-14 07:23:40'),
(94, 1, 5, 'ok', 0, '2025-11-14 07:24:12'),
(95, 1, 5, 'ok', 0, '2025-11-14 07:24:42'),
(96, 1, 5, 'ok', 0, '2025-11-14 07:25:13'),
(97, 1, 5, 'ok', 0, '2025-11-14 07:25:44'),
(98, 1, 5, 'ok', 0, '2025-11-14 07:26:15'),
(99, 1, 5, 'ok', 0, '2025-11-14 07:26:46'),
(100, 1, 5, 'ok', 0, '2025-11-14 07:27:17'),
(101, 1, 5, 'ok', 0, '2025-11-14 07:27:49'),
(102, 1, 5, 'ok', 0, '2025-11-14 07:28:19'),
(103, 1, 5, 'ok', 0, '2025-11-14 07:28:50'),
(104, 1, 5, 'ok', 0, '2025-11-14 07:29:22'),
(105, 1, 5, 'ok', 0, '2025-11-14 07:29:52'),
(106, 1, 5, 'ok', 0, '2025-11-14 07:30:24'),
(107, 1, 5, 'ok', 0, '2025-11-14 07:30:54'),
(108, 1, 5, 'ok', 0, '2025-11-14 07:31:26'),
(109, 1, 5, 'ok', 0, '2025-11-14 07:31:57'),
(110, 1, 5, 'ok', 0, '2025-11-14 07:32:27'),
(111, 1, 5, 'ok', 0, '2025-11-14 07:32:58'),
(112, 1, 5, 'ok', 0, '2025-11-14 07:33:29'),
(113, 1, 5, 'ok', 0, '2025-11-14 07:34:00'),
(114, 1, 5, 'ok', 0, '2025-11-14 07:34:31'),
(115, 1, 5, 'ok', 0, '2025-11-14 07:35:02'),
(116, 1, 5, 'ok', 0, '2025-11-14 07:35:33'),
(117, 1, 5, 'ok', 0, '2025-11-14 07:36:05'),
(118, 1, 5, 'ok', 0, '2025-11-14 07:36:35'),
(119, 1, 5, 'ok', 0, '2025-11-14 07:37:06'),
(120, 1, 5, 'ok', 0, '2025-11-14 07:37:37'),
(121, 1, 5, 'ok', 0, '2025-11-14 07:38:08'),
(122, 1, 5, 'ok', 0, '2025-11-14 07:38:39'),
(123, 4, 1, 'kkk', 1, '2025-11-14 07:39:04'),
(124, 1, 5, 'ok', 0, '2025-11-14 07:39:11'),
(125, 1, 5, 'ok', 0, '2025-11-14 07:39:41'),
(126, 1, 5, 'ok', 0, '2025-11-14 07:40:12'),
(127, 1, 5, 'ok', 0, '2025-11-14 07:40:44'),
(128, 1, 5, 'ok', 0, '2025-11-14 07:41:15'),
(129, 1, 5, 'ok', 0, '2025-11-14 07:41:46'),
(130, 1, 5, 'ok', 0, '2025-11-14 07:42:16'),
(131, 4, 1, 'cilokkkkk', 1, '2025-11-14 13:43:08'),
(132, 1, 4, 'okkkk', 1, '2025-11-14 13:43:32');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `harga` decimal(12,2) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `gambar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `id_kategori`, `nama_produk`, `deskripsi`, `harga`, `stok`, `gambar`, `created_at`, `updated_at`) VALUES
(1, 1, 'Buku Matematika Kelas 1 SD', 'Buku pelajaran matematika untuk siswa kelas 1 SD', 45000.00, 93, '69172aae899b3_1763125934.jpg', '2025-11-12 14:21:14', '2025-11-14 13:42:19'),
(2, 1, 'Buku Bahasa Indonesia Kelas 3 SD', 'Buku pelajaran Bahasa Indonesia kelas 3 SD', 50000.00, 79, '69172ab53f1af_1763125941.png', '2025-11-12 14:21:14', '2025-11-14 13:12:21'),
(3, 2, 'Pulpen Standard', 'Pulpen tinta biru/hitam berkualitas', 3000.00, 494, '69172abf26d79_1763125951.jpg', '2025-11-12 14:21:14', '2025-11-14 13:12:31'),
(7, 2, 'Penghapus', '', 2000.00, 88, '6916a41b8b46c_1763091483.jpeg', '2025-11-14 03:38:03', '2025-11-14 07:31:29');

-- --------------------------------------------------------

--
-- Table structure for table `rekening_penjual`
--

CREATE TABLE `rekening_penjual` (
  `id` int(11) NOT NULL,
  `nama_bank` varchar(100) NOT NULL,
  `nomor_rekening` varchar(50) NOT NULL,
  `nama_penerima` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rekening_penjual`
--

INSERT INTO `rekening_penjual` (`id`, `nama_bank`, `nomor_rekening`, `nama_penerima`, `created_at`) VALUES
(1, 'Bank Mandiri', '1234567890', 'PT OTRINDO PERSADA MANDIRI', '2025-11-12 14:21:14'),
(2, 'Bank BCA', '098765432198', 'PT OTRINDO PERSADA MANDIRI', '2025-11-12 14:21:14'),
(3, 'Bank BNI', '1122334455', 'PT OTRINDO PERSADA MANDIRI', '2025-11-12 14:21:14');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `komentar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `id_transaksi`, `id_produk`, `id_user`, `rating`, `komentar`, `created_at`) VALUES
(1, 2, 3, 4, 5, 'nice', '2025-11-14 03:08:37'),
(2, 5, 2, 5, 5, 'nice', '2025-11-14 03:35:15'),
(3, 7, 7, 4, 4, 'good', '2025-11-14 06:33:16'),
(4, 11, 1, 4, 5, 'gelo gelo', '2025-11-14 13:29:44'),
(5, 10, 1, 4, 5, 'mantabbbb', '2025-11-14 13:29:54'),
(6, 9, 1, 4, 4, 'niceeeee', '2025-11-14 13:30:05'),
(7, 8, 1, 4, 5, 'rekomen brooooo\r\n', '2025-11-14 13:30:14'),
(8, 6, 7, 4, 5, 'anti kecewa.....', '2025-11-14 13:30:33'),
(9, 4, 2, 4, 5, 'rekomen bos', '2025-11-14 13:30:43'),
(10, 3, 3, 4, 4, 'goooopd', '2025-11-14 13:30:55'),
(11, 1, 3, 4, 5, '......', '2025-11-14 13:31:09'),
(12, 12, 1, 4, 5, 'niceeeee', '2025-11-14 13:42:54');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tanggal` datetime DEFAULT current_timestamp(),
  `total_bayar` decimal(12,2) NOT NULL,
  `status_pesanan` enum('menunggu pembayaran','pembayaran berhasil','barang dalam pengiriman','barang diterima','pesanan selesai') DEFAULT 'menunggu pembayaran',
  `metode_pembayaran` enum('transfer','cod') NOT NULL,
  `id_rekening` int(11) DEFAULT NULL,
  `bukti_bayar` varchar(255) DEFAULT NULL,
  `nama_penerima` varchar(255) NOT NULL,
  `no_hp_penerima` varchar(20) NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `id_user`, `tanggal`, `total_bayar`, `status_pesanan`, `metode_pembayaran`, `id_rekening`, `bukti_bayar`, `nama_penerima`, `no_hp_penerima`, `alamat_pengiriman`, `catatan`, `created_at`, `updated_at`) VALUES
(1, 4, '2025-11-14 01:26:12', 15000.00, 'pesanan selesai', 'transfer', 1, NULL, 'erlan', '083193800456', 'medan', 'ww', '2025-11-13 18:26:12', '2025-11-14 05:54:02'),
(2, 4, '2025-11-14 01:26:52', 3000.00, 'pesanan selesai', 'transfer', 2, NULL, 'erlan', '083193800456', 'medan', '', '2025-11-13 18:26:52', '2025-11-14 03:06:53'),
(3, 4, '2025-11-14 01:29:31', 3000.00, 'pesanan selesai', 'cod', NULL, NULL, 'erlan', '083193800456', 'medan', '', '2025-11-13 18:29:31', '2025-11-14 05:53:51'),
(4, 4, '2025-11-14 10:00:56', 50000.00, 'pesanan selesai', 'transfer', 3, '69169c7da9acd_1763089533.png', 'erlan', '08319380045', 'medan', '', '2025-11-14 03:00:56', '2025-11-14 05:40:05'),
(5, 5, '2025-11-14 10:34:41', 50000.00, 'pesanan selesai', 'cod', NULL, NULL, 'biawak', '0899123345', 'sby', '', '2025-11-14 03:34:41', '2025-11-14 05:53:56'),
(6, 4, '2025-11-14 12:38:07', 2000.00, 'pesanan selesai', 'transfer', 2, '6916c048cadb2_1763098696.png', 'erlan', '08319380045', 'medan', '', '2025-11-14 05:38:07', '2025-11-14 05:39:59'),
(7, 4, '2025-11-14 13:05:47', 2000.00, 'pesanan selesai', 'transfer', 2, '6916c6d22a5e6_1763100370.png', 'erlan', '08319380045', 'medan', '', '2025-11-14 06:05:47', '2025-11-14 06:26:07'),
(8, 4, '2025-11-14 13:30:06', 90000.00, 'pesanan selesai', 'cod', NULL, NULL, 'erlan', '08319380045', 'medan', '', '2025-11-14 06:30:06', '2025-11-14 06:34:53'),
(9, 4, '2025-11-14 13:30:26', 45000.00, 'pesanan selesai', 'transfer', 3, '6916cd0a1b1dc_1763101962.png', 'erlan', '08319380045', 'medan', '', '2025-11-14 06:30:26', '2025-11-14 06:34:49'),
(10, 4, '2025-11-14 14:38:34', 45000.00, 'pesanan selesai', 'cod', NULL, NULL, 'erlan', '08319380045', 'meda', '', '2025-11-14 07:38:34', '2025-11-14 13:12:42'),
(11, 4, '2025-11-14 20:26:25', 90000.00, 'pesanan selesai', 'transfer', 3, '69172e26bb5c3_1763126822.png', 'erlan', '08319380045', 'meda', '', '2025-11-14 13:26:25', '2025-11-14 13:27:46'),
(12, 4, '2025-11-14 20:40:23', 45000.00, 'pesanan selesai', 'transfer', 3, '69173152410f1_1763127634.png', 'erlan', '08319380045', 'medan', '', '2025-11-14 13:40:23', '2025-11-14 13:42:19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `alamat` text DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `role` enum('admin','pembeli') DEFAULT 'pembeli',
  `email_verified` tinyint(1) DEFAULT 0,
  `email_verified_at` datetime DEFAULT NULL,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama_lengkap`, `username`, `email`, `password`, `alamat`, `no_hp`, `role`, `email_verified`, `email_verified_at`, `verification_code`, `verification_token`, `token_expiry`, `remember_token`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin', 'admin@ptopm.com', '0192023a7bbd73250516f069df18b500', NULL, NULL, 'admin', 1, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-12 14:21:14', '2025-11-12 14:21:14'),
(4, 'erlan', 'erlan', 'hutasoitsthyven@gmail.com', '24fd2bd60b3bdf49a235d0f1cf5a22b6', 'medan', '08319380045', 'pembeli', 1, NULL, '170239', NULL, NULL, NULL, NULL, '2025-11-13 08:07:04', '2025-11-14 13:33:22'),
(5, 'biawak', 'biawak', 'biawak@gmail.com', '5d20ba1a0da1ffe931b534edc52aaa14', 'sby', '0899123345', 'pembeli', 1, NULL, '632408', NULL, NULL, NULL, NULL, '2025-11-14 03:33:55', '2025-11-14 03:33:55'),
(6, 'sean', 'sean', 'sean@gmail.com', '3fab8b0071504634dc121d72df523834', 'medn', '081179823073847', 'pembeli', 1, NULL, '340265', NULL, NULL, NULL, NULL, '2025-11-14 15:13:21', '2025-11-14 15:13:21');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_rating_produk`
-- (See below for the actual view)
--
CREATE TABLE `view_rating_produk` (
`id` int(11)
,`nama_produk` varchar(255)
,`jumlah_review` bigint(21)
,`rata_rata_rating` decimal(14,4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_stok_produk`
-- (See below for the actual view)
--
CREATE TABLE `view_stok_produk` (
`id` int(11)
,`nama_produk` varchar(255)
,`nama_kategori` varchar(255)
,`stok` int(11)
,`harga` decimal(12,2)
,`total_terjual` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_transaksi_bulanan`
-- (See below for the actual view)
--
CREATE TABLE `view_transaksi_bulanan` (
`tahun` int(4)
,`bulan` int(2)
,`jumlah_transaksi` bigint(21)
,`total_pendapatan` decimal(34,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_transaksi_harian`
-- (See below for the actual view)
--
CREATE TABLE `view_transaksi_harian` (
`tanggal` date
,`jumlah_transaksi` bigint(21)
,`total_pendapatan` decimal(34,2)
,`rata_rata_transaksi` decimal(16,6)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_transaksi_tahunan`
-- (See below for the actual view)
--
CREATE TABLE `view_transaksi_tahunan` (
`tahun` int(4)
,`jumlah_transaksi` bigint(21)
,`total_pendapatan` decimal(34,2)
);

-- --------------------------------------------------------

--
-- Structure for view `view_rating_produk`
--
DROP TABLE IF EXISTS `view_rating_produk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_rating_produk`  AS SELECT `p`.`id` AS `id`, `p`.`nama_produk` AS `nama_produk`, count(`r`.`id`) AS `jumlah_review`, coalesce(avg(`r`.`rating`),0) AS `rata_rata_rating` FROM (`produk` `p` left join `review` `r` on(`p`.`id` = `r`.`id_produk`)) GROUP BY `p`.`id`, `p`.`nama_produk` ;

-- --------------------------------------------------------

--
-- Structure for view `view_stok_produk`
--
DROP TABLE IF EXISTS `view_stok_produk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_stok_produk`  AS SELECT `p`.`id` AS `id`, `p`.`nama_produk` AS `nama_produk`, `k`.`nama_kategori` AS `nama_kategori`, `p`.`stok` AS `stok`, `p`.`harga` AS `harga`, coalesce(sum(`dt`.`jumlah`),0) AS `total_terjual` FROM (((`produk` `p` left join `kategori` `k` on(`p`.`id_kategori` = `k`.`id`)) left join `detail_transaksi` `dt` on(`p`.`id` = `dt`.`id_produk`)) left join `transaksi` `t` on(`dt`.`id_transaksi` = `t`.`id` and `t`.`status_pesanan` = 'pesanan selesai')) GROUP BY `p`.`id`, `p`.`nama_produk`, `k`.`nama_kategori`, `p`.`stok`, `p`.`harga` ORDER BY `p`.`stok` ASC ;

-- --------------------------------------------------------

--
-- Structure for view `view_transaksi_bulanan`
--
DROP TABLE IF EXISTS `view_transaksi_bulanan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_transaksi_bulanan`  AS SELECT year(`transaksi`.`tanggal`) AS `tahun`, month(`transaksi`.`tanggal`) AS `bulan`, count(0) AS `jumlah_transaksi`, sum(`transaksi`.`total_bayar`) AS `total_pendapatan` FROM `transaksi` WHERE `transaksi`.`status_pesanan` = 'pesanan selesai' GROUP BY year(`transaksi`.`tanggal`), month(`transaksi`.`tanggal`) ORDER BY year(`transaksi`.`tanggal`) DESC, month(`transaksi`.`tanggal`) DESC ;

-- --------------------------------------------------------

--
-- Structure for view `view_transaksi_harian`
--
DROP TABLE IF EXISTS `view_transaksi_harian`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_transaksi_harian`  AS SELECT cast(`transaksi`.`tanggal` as date) AS `tanggal`, count(0) AS `jumlah_transaksi`, sum(`transaksi`.`total_bayar`) AS `total_pendapatan`, avg(`transaksi`.`total_bayar`) AS `rata_rata_transaksi` FROM `transaksi` WHERE `transaksi`.`status_pesanan` = 'pesanan selesai' GROUP BY cast(`transaksi`.`tanggal` as date) ORDER BY cast(`transaksi`.`tanggal` as date) DESC ;

-- --------------------------------------------------------

--
-- Structure for view `view_transaksi_tahunan`
--
DROP TABLE IF EXISTS `view_transaksi_tahunan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_transaksi_tahunan`  AS SELECT year(`transaksi`.`tanggal`) AS `tahun`, count(0) AS `jumlah_transaksi`, sum(`transaksi`.`total_bayar`) AS `total_pendapatan` FROM `transaksi` WHERE `transaksi`.`status_pesanan` = 'pesanan selesai' GROUP BY year(`transaksi`.`tanggal`) ORDER BY year(`transaksi`.`tanggal`) DESC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_transaksi` (`id_transaksi`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_cart` (`id_user`,`id_produk`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indexes for table `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_pengirim` (`id_pengirim`),
  ADD KEY `id_penerima` (`id_penerima`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `rekening_penjual`
--
ALTER TABLE `rekening_penjual`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_transaksi` (`id_transaksi`),
  ADD KEY `id_produk` (`id_produk`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_rekening` (`id_rekening`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_verification_token` (`verification_token`),
  ADD KEY `idx_email_verified` (`email_verified`),
  ADD KEY `idx_remember_token` (`remember_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rekening_penjual`
--
ALTER TABLE `rekening_penjual`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD CONSTRAINT `detail_transaksi_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `detail_transaksi_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD CONSTRAINT `keranjang_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `keranjang_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD CONSTRAINT `log_aktivitas_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `pesan`
--
ALTER TABLE `pesan`
  ADD CONSTRAINT `pesan_ibfk_1` FOREIGN KEY (`id_pengirim`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pesan_ibfk_2` FOREIGN KEY (`id_penerima`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `produk_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `review_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_rekening`) REFERENCES `rekening_penjual` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
