<?php
require_once 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Ambil data user
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Handle update profile
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $fullName = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    
    try {
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?");
        $stmt->execute([$fullName, $email, $userId]);
        
        $_SESSION['full_name'] = $fullName;
        $_SESSION['email'] = $email;
        $_SESSION['success'] = 'Profile updated successfully!';
        
        logActivity($conn, $userId, 'profile_update', 'Updated profile information');
        
        header('Location: profile.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Failed to update profile: ' . $e->getMessage();
    }
}

// Handle change password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    
    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $_SESSION['error'] = 'All password fields are required!';
    } elseif ($newPassword !== $confirmPassword) {
        $_SESSION['error'] = 'New passwords do not match!';
    } elseif (strlen($newPassword) < 6) {
        $_SESSION['error'] = 'Password must be at least 6 characters!';
    } elseif (!verifyPassword($currentPassword, $user['password'])) {
        $_SESSION['error'] = 'Current password is incorrect!';
    } else {
        try {
            $hashedPassword = hashPassword($newPassword);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $userId]);
            
            $_SESSION['success'] = 'Password changed successfully!';
            logActivity($conn, $userId, 'password_change', 'Changed password');
            
            header('Location: profile.php');
            exit;
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Failed to change password!';
        }
    }
}

// Handle avatar upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['avatar'])) {
    $file = $_FILES['avatar'];
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
        
        if (in_array($file['type'], $allowedTypes)) {
            if ($file['size'] <= 2 * 1024 * 1024) {
                $avatarDir = 'uploads/avatars/';
                if (!file_exists($avatarDir)) {
                    mkdir($avatarDir, 0777, true);
                }
                
                $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                $avatarName = 'avatar_' . $userId . '_' . time() . '.' . $extension;
                $avatarPath = $avatarDir . $avatarName;
                
                if (move_uploaded_file($file['tmp_name'], $avatarPath)) {
                    if ($user['avatar'] && file_exists($user['avatar'])) {
                        unlink($user['avatar']);
                    }
                    
                    $stmt = $conn->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                    $stmt->execute([$avatarPath, $userId]);
                    
                    $_SESSION['avatar'] = $avatarPath;
                    $_SESSION['success'] = 'Avatar updated successfully!';
                    
                    logActivity($conn, $userId, 'avatar_update', 'Updated profile avatar');
                    
                    header('Location: profile.php');
                    exit;
                }
            } else {
                $_SESSION['error'] = 'File size must be less than 2MB!';
            }
        } else {
            $_SESSION['error'] = 'File format must be JPG, PNG, or GIF!';
        }
    }
}

// Ambil statistik user
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM files WHERE user_id = ?");
$stmt->execute([$userId]);
$totalFiles = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT SUM(file_size) as total FROM files WHERE user_id = ?");
$stmt->execute([$userId]);
$totalSize = $stmt->fetch()['total'] ?? 0;

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM shared_files WHERE shared_by = ?");
$stmt->execute([$userId]);
$totalShared = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM shared_files WHERE shared_with = ?");
$stmt->execute([$userId]);
$totalReceived = $stmt->fetch()['total'];

// Ambil activity untuk chart (last 7 days)
$stmt = $conn->prepare("
    SELECT DATE(created_at) as date, COUNT(*) as count 
    FROM activity_log 
    WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date ASC
");
$stmt->execute([$userId]);
$activityData = $stmt->fetchAll();

// Ambil file types distribution
$stmt = $conn->prepare("SELECT original_name, file_size FROM files WHERE user_id = ?");
$stmt->execute([$userId]);
$allFiles = $stmt->fetchAll();

$fileTypeCount = [
    'Images' => 0,
    'Documents' => 0,
    'Videos' => 0,
    'Archives' => 0,
    'Others' => 0
];

foreach ($allFiles as $file) {
    $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
    
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])) {
        $fileTypeCount['Images']++;
    } elseif (in_array($ext, ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'])) {
        $fileTypeCount['Documents']++;
    } elseif (in_array($ext, ['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv'])) {
        $fileTypeCount['Videos']++;
    } elseif (in_array($ext, ['zip', 'rar', '7z', 'tar', 'gz'])) {
        $fileTypeCount['Archives']++;
    } else {
        $fileTypeCount['Others']++;
    }
}

// Ambil recent activity
$stmt = $conn->prepare("SELECT * FROM activity_log WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$userId]);
$activities = $stmt->fetchAll();

$successMsg = $_SESSION['success'] ?? '';
$errorMsg = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - FlowNet Cloud Storage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <style>
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        :root {
            --bg-primary: #0f172a;
            --bg-secondary: #1e293b;
            --bg-card: #1e293b;
            --bg-hover: #334155;
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
            --text-muted: #94a3b8;
            --accent-blue: #3b82f6;
            --accent-purple: #8b5cf6;
            --accent-green: #10b981;
            --accent-orange: #f59e0b;
            --accent-red: #ef4444;
            --border-color: rgba(148, 163, 184, 0.12);
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.3);
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
            --shadow-lg: 0 10px 25px -3px rgba(0, 0, 0, 0.5);
        }
        
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1a1f35 100%);
            color: var(--text-primary);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', sans-serif;
            min-height: 100vh;
            font-size: 14px;
            line-height: 1.5;
        }
        
        /* Top Navbar */
        .top-navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 64px;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            padding: 0 1.5rem;
            z-index: 1000;
            box-shadow: var(--shadow);
        }
        
        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 0.625rem;
            text-decoration: none;
            margin-right: 2.5rem;
        }
        
        .navbar-brand i {
            font-size: 1.5rem;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .navbar-brand h4 {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .navbar-menu {
            display: flex;
            align-items: center;
            gap: 0.25rem;
            flex: 1;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.2s;
            font-weight: 500;
            font-size: 0.875rem;
            white-space: nowrap;
        }
        
        .nav-link:hover {
            background: rgba(59, 130, 246, 0.1);
            color: var(--accent-blue);
        }
        
        .nav-link.active {
            background: rgba(59, 130, 246, 0.15);
            color: var(--accent-blue);
        }
        
        .nav-link i {
            font-size: 1rem;
        }
        
        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-left: auto;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 0.625rem;
            padding: 0.375rem 0.75rem;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .user-menu:hover {
            border-color: var(--accent-blue);
            background: rgba(59, 130, 246, 0.05);
        }
        
        .user-avatar-small {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            font-size: 0.875rem;
            object-fit: cover;
        }
        
        /* Main Content */
        .main-content {
            margin-top: 64px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Page Header */
        .page-header {
            margin-bottom: 2rem;
        }
        
        .page-title {
            font-size: 1.875rem;
            font-weight: 700;
            color: var(--text-primary);
            margin: 0 0 0.375rem 0;
            letter-spacing: -0.025em;
        }
        
        .page-subtitle {
            color: var(--text-muted);
            font-size: 0.9375rem;
        }
        
        /* Profile Header Card */
        .profile-header-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 2rem;
            box-shadow: var(--shadow-sm);
        }
        
        .avatar-section {
            position: relative;
        }
        
        .avatar-large {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: 700;
            color: white;
            border: 4px solid var(--bg-primary);
            object-fit: cover;
            box-shadow: var(--shadow);
        }
        
        .avatar-upload-btn {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 40px;
            height: 40px;
            background: var(--accent-blue);
            border: 3px solid var(--bg-card);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .avatar-upload-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .avatar-upload-btn i {
            color: white;
            font-size: 1rem;
        }
        
        .profile-info {
            flex: 1;
        }
        
        .profile-name {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .badge-role {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.375rem;
        }
        
        .profile-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 1.5rem;
            color: var(--text-muted);
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
        }
        
        .profile-meta-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .profile-stats {
            display: flex;
            gap: 2rem;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--accent-blue);
            margin-bottom: 0.25rem;
        }
        
        .stat-label {
            font-size: 0.8125rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.25rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 1.5rem;
            transition: all 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            border-color: rgba(59, 130, 246, 0.3);
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .stat-icon.blue { background: rgba(59, 130, 246, 0.15); color: var(--accent-blue); }
        .stat-icon.green { background: rgba(16, 185, 129, 0.15); color: var(--accent-green); }
        .stat-icon.purple { background: rgba(139, 92, 246, 0.15); color: var(--accent-purple); }
        .stat-icon.orange { background: rgba(245, 158, 11, 0.15); color: var(--accent-orange); }
        
        .stat-card-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
        }
        
        .stat-card-label {
            font-size: 0.875rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        /* Card */
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-sm);
        }
        
        .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 1.25rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .chart-container {
            height: 280px;
        }
        
        /* Form */
        .form-control {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 0.625rem 0.875rem;
            font-size: 0.875rem;
            border-radius: 6px;
        }
        
        .form-control:focus {
            background: var(--bg-primary);
            border-color: var(--accent-blue);
            color: var(--text-primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .form-control:disabled {
            background: var(--bg-hover);
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .form-label {
            color: var(--text-secondary);
            font-weight: 500;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }
        
        .form-text {
            color: var(--text-muted);
            font-size: 0.75rem;
            margin-top: 0.375rem;
        }
        
        /* Button */
        .btn-primary-custom {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            color: white;
            border: none;
            padding: 0.625rem 1.5rem;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }
        
        .btn-primary-custom:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        
        /* Activity Timeline */
        .activity-list {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .activity-item {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            transition: all 0.2s;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-item:hover {
            background: rgba(59, 130, 246, 0.05);
        }
        
        .activity-icon-wrapper {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: rgba(59, 130, 246, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .activity-icon-wrapper i {
            color: var(--accent-blue);
            font-size: 1rem;
        }
        
        .activity-info {
            flex: 1;
        }
        
        .activity-action {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.875rem;
            margin-bottom: 0.25rem;
        }
        
        .activity-details {
            font-size: 0.8125rem;
            color: var(--text-muted);
            margin-bottom: 0.25rem;
        }
        
        .activity-time {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        
        /* Alert */
        .alert-custom {
            padding: 0.875rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border: 1px solid;
            animation: slideDown 0.3s ease-out;
            font-size: 0.875rem;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border-color: rgba(16, 185, 129, 0.3);
            color: var(--accent-green);
        }
        
        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
            color: var(--accent-red);
        }
        
        /* Dropdown */
        .dropdown-menu {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }
        
        .dropdown-item {
            color: var(--text-primary);
            transition: all 0.2s;
            border-radius: 6px;
            padding: 0.5rem 0.75rem;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            gap: 0.625rem;
        }
        
        .dropdown-item:hover {
            background: rgba(59, 130, 246, 0.1);
            color: var(--accent-blue);
        }
        
        .dropdown-divider {
            border-color: var(--border-color);
            margin: 0.5rem 0;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .navbar-menu {
                display: none;
            }
            
            .profile-header-card {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-meta {
                justify-content: center;
            }
            
            .profile-stats {
                justify-content: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .main-content {
                padding: 1.25rem;
            }
        }
        
        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .stat-card, .card {
            animation: fadeIn 0.4s ease-out backwards;
        }
        
        .stat-card:nth-child(1) { animation-delay: 0.05s; }
        .stat-card:nth-child(2) { animation-delay: 0.1s; }
        .stat-card:nth-child(3) { animation-delay: 0.15s; }
        .stat-card:nth-child(4) { animation-delay: 0.2s; }
    </style>
</head>
<body>
    <!-- Top Navbar -->
    <nav class="top-navbar">
        <a href="dashboard.php" class="navbar-brand">
            <i class="bi bi-cloud-arrow-up-fill"></i>
            <h4>FlowNet</h4>
        </a>
        
        <div class="navbar-menu">
            <a href="dashboard.php" class="nav-link">
                <i class="bi bi-house-door-fill"></i>
                <span>Dashboard</span>
            </a>
            <a href="dashboard.php#files" class="nav-link">
                <i class="bi bi-folder-fill"></i>
                <span>My Files</span>
            </a>
            <a href="dashboard.php#shared" class="nav-link">
                <i class="bi bi-people-fill"></i>
                <span>Shared</span>
            </a>
            <a href="profile.php" class="nav-link active">
                <i class="bi bi-person-fill"></i>
                <span>Profile</span>
            </a>
            <?php if ($user['role'] === 'admin'): ?>
            <a href="admin/index.php" class="nav-link">
                <i class="bi bi-speedometer2"></i>
                <span>Admin</span>
            </a>
            <?php endif; ?>
        </div>
        
        <div class="navbar-actions">
            <div class="dropdown">
                <div class="user-menu" data-bs-toggle="dropdown">
                    <?php if ($user['avatar'] && file_exists($user['avatar'])): ?>
                        <img src="<?= $user['avatar'] ?>" alt="Avatar" class="user-avatar-small">
                    <?php else: ?>
                        <div class="user-avatar-small">
                            <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                        </div>
                    <?php endif; ?>
                    <i class="bi bi-chevron-down" style="font-size: 0.75rem; color: var(--text-muted);"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person-fill"></i> Profile</a></li>
                    <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-house-door-fill"></i> Dashboard</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php" style="color: var(--accent-red);"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Profile Settings</h1>
            <p class="page-subtitle">Manage your account settings and preferences</p>
        </div>

        <!-- Alerts -->
        <?php if ($successMsg): ?>
            <div class="alert-custom alert-success">
                <i class="bi bi-check-circle-fill"></i>
                <span><?= htmlspecialchars($successMsg) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
            <div class="alert-custom alert-danger">
                <i class="bi bi-exclamation-circle-fill"></i>
                <span><?= htmlspecialchars($errorMsg) ?></span>
            </div>
        <?php endif; ?>

        <!-- Profile Header Card -->
        <div class="profile-header-card">
            <div class="avatar-section">
                <?php if ($user['avatar'] && file_exists($user['avatar'])): ?>
                    <img src="<?= $user['avatar'] ?>" alt="Avatar" class="avatar-large">
                <?php else: ?>
                    <div class="avatar-large">
                        <?= strtoupper(substr($user['full_name'], 0, 2)) ?>
                    </div>
                <?php endif; ?>
                <form method="POST" enctype="multipart/form-data" id="avatarForm">
                    <label for="avatarInput" class="avatar-upload-btn">
                        <i class="bi bi-camera-fill"></i>
                    </label>
                    <input type="file" id="avatarInput" name="avatar" accept="image/*" style="display: none;" onchange="document.getElementById('avatarForm').submit();">
                </form>
            </div>

            <div class="profile-info">
                <div class="profile-name">
                    <?= htmlspecialchars($user['full_name']) ?>
                    <?php if ($user['role'] === 'admin'): ?>
                        <span class="badge-role">
                            <i class="bi bi-shield-check"></i> Admin
                        </span>
                    <?php endif; ?>
                </div>
                <div class="profile-meta">
                    <div class="profile-meta-item">
                        <i class="bi bi-at"></i>
                        <span>@<?= htmlspecialchars($user['username']) ?></span>
                    </div>
                    <div class="profile-meta-item">
                        <i class="bi bi-envelope-fill"></i>
                        <span><?= htmlspecialchars($user['email']) ?></span>
                    </div>
                    <div class="profile-meta-item">
                        <i class="bi bi-calendar-check-fill"></i>
                        <span>Joined <?= date('d M Y', strtotime($user['created_at'])) ?></span>
                    </div>
                    <?php if ($user['last_login']): ?>
                    <div class="profile-meta-item">
                        <i class="bi bi-clock-fill"></i>
                        <span>Last login: <?= date('d M Y H:i', strtotime($user['last_login'])) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="profile-stats">
                    <div class="stat-item">
                        <div class="stat-value"><?= $totalFiles ?></div>
                        <div class="stat-label">Total Files</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?= formatFileSize($totalSize) ?></div>
                        <div class="stat-label">Storage Used</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?= $totalShared ?></div>
                        <div class="stat-label">Files Shared</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?= $totalReceived ?></div>
                        <div class="stat-label">Received</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <i class="bi bi-files"></i>
                </div>
                <div class="stat-card-value"><?= $totalFiles ?></div>
                <div class="stat-card-label">Total Files Uploaded</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="bi bi-hdd-fill"></i>
                </div>
                <div class="stat-card-value"><?= formatFileSize($totalSize) ?></div>
                <div class="stat-card-label">Storage Used</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon purple">
                    <i class="bi bi-share-fill"></i>
                </div>
                <div class="stat-card-value"><?= $totalShared ?></div>
                <div class="stat-card-label">Files Shared by You</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon orange">
                    <i class="bi bi-arrow-down-circle-fill"></i>
                </div>
                <div class="stat-card-value"><?= $totalReceived ?></div>
                <div class="stat-card-label">Files Shared to You</div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <!-- Charts Row -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <h5 class="card-title">
                                <i class="bi bi-activity"></i> Activity (Last 7 Days)
                            </h5>
                            <div id="activityChart" class="chart-container"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <h5 class="card-title">
                                <i class="bi bi-pie-chart-fill"></i> File Types Distribution
                            </h5>
                            <div id="fileTypeChart" class="chart-container"></div>
                        </div>
                    </div>
                </div>

                <!-- Edit Profile -->
                <div class="card">
                    <h5 class="card-title">
                        <i class="bi bi-person-badge-fill"></i> Edit Profile
                    </h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" disabled>
                            <div class="form-text">Username cannot be changed</div>
                        </div>
                        <button type="submit" name="update_profile" class="btn-primary-custom">
                            <i class="bi bi-save-fill"></i> Save Changes
                        </button>
                    </form>
                </div>

                <!-- Change Password -->
                <div class="card">
                    <h5 class="card-title">
                        <i class="bi bi-shield-lock-fill"></i> Change Password
                    </h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" class="form-control" name="new_password" required>
                            <div class="form-text">Password must be at least 6 characters</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        <button type="submit" name="change_password" class="btn-primary-custom">
                            <i class="bi bi-key-fill"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-lg-4">
                <!-- Recent Activity -->
                <div class="card">
                    <h5 class="card-title">
                        <i class="bi bi-clock-history"></i> Recent Activity
                    </h5>
                    <?php if (empty($activities)): ?>
                        <div style="text-align: center; padding: 2rem 0; color: var(--text-muted);">
                            <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.3;"></i>
                            <p style="margin-top: 0.75rem;">No recent activity</p>
                        </div>
                    <?php else: ?>
                        <div class="activity-list">
                            <?php foreach ($activities as $activity): 
                                $iconMap = [
                                    'upload' => 'bi-cloud-upload-fill',
                                    'download' => 'bi-download',
                                    'share' => 'bi-share-fill',
                                    'delete' => 'bi-trash-fill',
                                    'profile_update' => 'bi-person-fill',
                                    'password_change' => 'bi-key-fill',
                                    'avatar_update' => 'bi-camera-fill',
                                    'login' => 'bi-box-arrow-in-right'
                                ];
                                $icon = $iconMap[$activity['action']] ?? 'bi-circle-fill';
                            ?>
                            <div class="activity-item">
                                <div class="activity-icon-wrapper">
                                    <i class="bi <?= $icon ?>"></i>
                                </div>
                                <div class="activity-info">
                                    <div class="activity-action"><?= ucfirst(str_replace('_', ' ', $activity['action'])) ?></div>
                                    <?php if ($activity['details']): ?>
                                        <div class="activity-details"><?= htmlspecialchars($activity['details']) ?></div>
                                    <?php endif; ?>
                                    <div class="activity-time">
                                        <i class="bi bi-clock"></i> <?= date('d M Y H:i', strtotime($activity['created_at'])) ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Account Info -->
                <div class="card">
                    <h5 class="card-title">
                        <i class="bi bi-info-circle-fill"></i> Account Information
                    </h5>
                    <div style="display: flex; flex-direction: column; gap: 1rem;">
                        <div style="padding: 0.875rem; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px;">
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.25rem;">Account Type</div>
                            <div style="font-weight: 600; color: var(--text-primary);">
                                <?= ucfirst($user['role']) ?> Account
                            </div>
                        </div>
                        <div style="padding: 0.875rem; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px;">
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.25rem;">Member Since</div>
                            <div style="font-weight: 600; color: var(--text-primary);">
                                <?= date('d F Y', strtotime($user['created_at'])) ?>
                            </div>
                        </div>
                        <div style="padding: 0.875rem; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px;">
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.25rem;">Total Activities</div>
                            <div style="font-weight: 600; color: var(--text-primary);">
                                <?= count($activities) ?> recent actions
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Highcharts Dark Theme
        Highcharts.setOptions({
            colors: ['#3b82f6', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b', '#6366f1'],
            chart: {
                backgroundColor: 'transparent',
                style: { fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }
            },
            title: { style: { color: '#f8fafc', fontSize: '14px', fontWeight: '600' } },
            tooltip: {
                backgroundColor: 'rgba(30, 41, 59, 0.98)',
                borderColor: 'rgba(148, 163, 184, 0.2)',
                borderRadius: 8,
                style: { color: '#f8fafc', fontSize: '12px' },
                shadow: false
            },
            legend: {
                itemStyle: { color: '#cbd5e1', fontSize: '12px', fontWeight: '500' },
                itemHoverStyle: { color: '#3b82f6' }
            },
            credits: { enabled: false }
        });

        // Activity Chart (Last 7 Days)
        Highcharts.chart('activityChart', {
            chart: { type: 'areaspline', height: 280 },
            title: { text: null },
            xAxis: {
                categories: [
                    <?php 
                    // Create last 7 days array
                    $dates = [];
                    $counts = [];
                    for ($i = 6; $i >= 0; $i--) {
                        $date = date('Y-m-d', strtotime("-$i days"));
                        $dates[] = date('d M', strtotime($date));
                        $counts[$date] = 0;
                    }
                    
                    // Fill with actual data
                    foreach ($activityData as $data) {
                        if (isset($counts[$data['date']])) {
                            $counts[$data['date']] = $data['count'];
                        }
                    }
                    
                    echo "'" . implode("','", $dates) . "'";
                    ?>
                ],
                gridLineColor: 'rgba(148, 163, 184, 0.1)',
                labels: { style: { color: '#94a3b8', fontSize: '11px' } },
                lineColor: 'rgba(148, 163, 184, 0.2)'
            },
            yAxis: {
                title: { text: null },
                gridLineColor: 'rgba(148, 163, 184, 0.1)',
                labels: { style: { color: '#94a3b8', fontSize: '11px' } },
                allowDecimals: false
            },
            tooltip: {
                shared: true,
                valueSuffix: ' activities'
            },
            plotOptions: {
                areaspline: {
                    fillOpacity: 0.2,
                    lineWidth: 2,
                    marker: {
                        radius: 4,
                        lineWidth: 2,
                        lineColor: '#3b82f6'
                    }
                }
            },
            series: [{
                name: 'Activities',
                data: [<?= implode(',', array_values($counts)) ?>],
                color: '#3b82f6'
            }]
        });

        // File Type Distribution Chart
        Highcharts.chart('fileTypeChart', {
            chart: { type: 'pie', height: 280 },
            title: { text: null },
            tooltip: {
                pointFormat: '<b>{point.y} files</b> ({point.percentage:.1f}%)'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b><br>{point.y} files',
                        style: { 
                            color: '#cbd5e1', 
                            textOutline: 'none', 
                            fontSize: '11px',
                            fontWeight: '500'
                        },
                        distance: 15
                    },
                    borderWidth: 0,
                    innerSize: '50%',
                    size: '85%'
                }
            },
            series: [{
                name: 'Files',
                colorByPoint: true,
                data: [
                    <?php 
                    $colors = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#64748b'];
                    $index = 0;
                    foreach ($fileTypeCount as $type => $count): 
                        if ($count > 0):
                    ?>
                        { 
                            name: '<?= $type ?>', 
                            y: <?= $count ?>,
                            color: '<?= $colors[$index % count($colors)] ?>'
                        },
                    <?php 
                            $index++;
                        endif;
                    endforeach; 
                    ?>
                ]
            }]
        });

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert-custom');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.animation = 'fadeOut 0.3s ease-out';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });
        });

        // Add fadeOut animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeOut {
                from {
                    opacity: 1;
                    transform: translateY(0);
                }
                to {
                    opacity: 0;
                    transform: translateY(-10px);
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>