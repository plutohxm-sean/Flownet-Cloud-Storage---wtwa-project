<?php
require_once '../config.php';
requireAdmin();

// Handle delete file
if (isset($_GET['delete'])) {
    $fileId = $_GET['delete'];
    
    try {
        $stmt = $conn->prepare("SELECT * FROM files WHERE id = ?");
        $stmt->execute([$fileId]);
        $file = $stmt->fetch();
        
        if ($file) {
            // Delete physical file
            if (file_exists('../' . $file['file_path'])) {
                unlink('../' . $file['file_path']);
            }
            
            // Delete from database
            $stmt = $conn->prepare("DELETE FROM files WHERE id = ?");
            $stmt->execute([$fileId]);
            
            $_SESSION['success'] = 'File berhasil dihapus!';
        }
    } catch (Exception $e) {
        $_SESSION['error'] = 'Gagal menghapus file!';
    }
    header('Location: files.php');
    exit;
}

// Search & Filter
$search = $_GET['search'] ?? '';
$userFilter = $_GET['user'] ?? '';
$typeFilter = $_GET['type'] ?? '';
$encryptedFilter = $_GET['encrypted'] ?? '';

$sql = "SELECT f.*, u.username, u.full_name 
        FROM files f 
        JOIN users u ON f.user_id = u.id 
        WHERE 1=1";

$params = [];

if ($search) {
    $sql .= " AND f.original_name LIKE ?";
    $params[] = "%$search%";
}

if ($userFilter) {
    $sql .= " AND f.user_id = ?";
    $params[] = $userFilter;
}

if ($typeFilter) {
    $sql .= " AND f.file_type LIKE ?";
    $params[] = "%$typeFilter%";
}

if ($encryptedFilter === '1') {
    $sql .= " AND f.encrypted = 1";
} elseif ($encryptedFilter === '0') {
    $sql .= " AND f.encrypted = 0";
}

$sql .= " ORDER BY f.uploaded_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$files = $stmt->fetchAll();

// Get all users for filter
$usersStmt = $conn->query("SELECT id, username, full_name FROM users ORDER BY username");
$allUsers = $usersStmt->fetchAll();

// Calculate total storage
$totalSize = array_sum(array_column($files, 'file_size'));

$successMsg = $_SESSION['success'] ?? '';
$errorMsg = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Management - FlowNet Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #18181b;
            color: #e4e4e7;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: #09090b;
            border-right: 1px solid #27272a;
            padding: 1.5rem;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: #ef4444;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: #a1a1aa;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }

        .sidebar-link:hover {
            background: #27272a;
            color: #e4e4e7;
        }

        .sidebar-link.active {
            background: #dc2626;
            color: #fff;
        }

        .sidebar-link i {
            font-size: 1.25rem;
            width: 24px;
        }

        .main-content {
            margin-left: 280px;
            padding: 2rem;
        }

        .header {
            margin-bottom: 2rem;
        }

        .header h2 {
            font-size: 2rem;
            font-weight: 700;
            color: #e4e4e7;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: #09090b;
            border: 1px solid #27272a;
            border-radius: 12px;
            padding: 1.5rem;
        }

        .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: #ef4444;
            margin-bottom: 0.25rem;
        }

        .stat-label {
            color: #71717a;
            font-size: 0.875rem;
        }

        .content-card {
            background: #09090b;
            border: 1px solid #27272a;
            border-radius: 12px;
            padding: 1.5rem;
        }

        .search-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }

        .form-control, .form-select {
            background: #18181b;
            border: 1px solid #27272a;
            color: #e4e4e7;
            padding: 0.75rem 1rem;
            border-radius: 8px;
        }

        .form-control:focus, .form-select:focus {
            background: #18181b;
            border-color: #ef4444;
            color: #e4e4e7;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            outline: none;
        }

        .table-custom {
            width: 100%;
        }

        .table-custom th {
            color: #a1a1aa;
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            padding: 1rem;
            border-bottom: 1px solid #27272a;
        }

        .table-custom td {
            color: #e4e4e7;
            padding: 1rem;
            border-bottom: 1px solid #27272a;
            vertical-align: middle;
        }

        .table-custom tr:hover {
            background: #27272a;
        }

        .file-icon {
            width: 40px;
            height: 40px;
            background: #27272a;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .file-icon i {
            font-size: 1.25rem;
            color: #ef4444;
        }

        .badge-custom {
            padding: 0.375rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-warning {
            background: rgba(251, 146, 60, 0.2);
            color: #fb923c;
        }

        .badge-info {
            background: rgba(59, 130, 246, 0.2);
            color: #60a5fa;
        }

        .btn-primary {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
        }

        .btn-sm {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
        }

        .btn-danger {
            background: #dc2626;
            border: none;
            color: #fff;
        }

        .btn-danger:hover {
            background: #b91c1c;
        }

        .alert {
            border-radius: 8px;
            border: 1px solid;
        }

        .alert-success {
            background: rgba(34, 197, 94, 0.1);
            border-color: rgba(34, 197, 94, 0.3);
            color: #4ade80;
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
            color: #f87171;
        }

        .modal-content {
            background: #09090b;
            border: 1px solid #27272a;
            color: #e4e4e7;
        }

        .modal-header {
            border-bottom: 1px solid #27272a;
        }

        .modal-footer {
            border-top: 1px solid #27272a;
        }

        .btn-close {
            filter: invert(1);
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #09090b;
        }

        ::-webkit-scrollbar-thumb {
            background: #27272a;
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .search-bar {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <i class="bi bi-shield-lock"></i>
            Admin Panel
        </div>

        <ul class="sidebar-nav">
            <li>
                <a href="index.php" class="sidebar-link">
                    <i class="bi bi-speedometer2"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="users.php" class="sidebar-link">
                    <i class="bi bi-people"></i>
                    Users
                </a>
            </li>
            <li>
                <a href="files.php" class="sidebar-link active">
                    <i class="bi bi-files"></i>
                    Files
                </a>
            </li>
            <li>
                <a href="activity.php" class="sidebar-link">
                    <i class="bi bi-clock-history"></i>
                    Activity Log
                </a>
            </li>
            <li>
                <a href="settings.php" class="sidebar-link">
                    <i class="bi bi-gear"></i>
                    Settings
                </a>
            </li>
            <li style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #27272a;">
                <a href="../dashboard.php" class="sidebar-link">
                    <i class="bi bi-arrow-left"></i>
                    Back to Dashboard
                </a>
            </li>
            <li>
                <a href="../logout.php" class="sidebar-link">
                    <i class="bi bi-box-arrow-right"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <?php if ($successMsg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?= $successMsg ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle"></i> <?= $errorMsg ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="header">
            <h2>File Management</h2>
            <p style="color: #71717a;">Manage all files across the system</p>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?= count($files) ?></div>
                <div class="stat-label">Total Files</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= formatFileSize($totalSize) ?></div>
                <div class="stat-label">Total Storage</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">
                    <?= count(array_filter($files, fn($f) => $f['encrypted'])) ?>
                </div>
                <div class="stat-label">Encrypted Files</div>
            </div>
        </div>

        <div class="content-card">
            <!-- Search & Filter -->
            <form method="GET" class="search-bar">
                <input type="text" class="form-control" name="search" placeholder="Search filename..." value="<?= htmlspecialchars($search) ?>" style="flex: 1; min-width: 200px;">
                
                <select class="form-select" name="user" style="width: 200px;">
                    <option value="">All Users</option>
                    <?php foreach ($allUsers as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= $userFilter == $u['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($u['full_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select class="form-select" name="type" style="width: 150px;">
                    <option value="">All Types</option>
                    <option value="pdf" <?= $typeFilter === 'pdf' ? 'selected' : '' ?>>PDF</option>
                    <option value="image" <?= $typeFilter === 'image' ? 'selected' : '' ?>>Images</option>
                    <option value="video" <?= $typeFilter === 'video' ? 'selected' : '' ?>>Videos</option>
                    <option value="zip" <?= $typeFilter === 'zip' ? 'selected' : '' ?>>Archives</option>
                </select>

                <select class="form-select" name="encrypted" style="width: 150px;">
                    <option value="">All Files</option>
                    <option value="1" <?= $encryptedFilter === '1' ? 'selected' : '' ?>>Encrypted</option>
                    <option value="0" <?= $encryptedFilter === '0' ? 'selected' : '' ?>>Not Encrypted</option>
                </select>

                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search"></i> Search
                </button>
                
                <?php if ($search || $userFilter || $typeFilter || $encryptedFilter): ?>
                <a href="files.php" class="btn btn-danger">
                    <i class="bi bi-x-lg"></i> Clear
                </a>
                <?php endif; ?>
            </form>

            <!-- Files Table -->
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>File</th>
                            <th>Owner</th>
                            <th>Size</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Uploaded</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($files)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: #71717a; padding: 3rem;">
                                <i class="bi bi-inbox" style="font-size: 3rem; display: block; margin-bottom: 1rem;"></i>
                                No files found
                            </td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($files as $file): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <div class="file-icon">
                                            <i class="bi bi-file-earmark"></i>
                                        </div>
                                        <div>
                                            <strong><?= htmlspecialchars($file['original_name']) ?></strong>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <strong><?= htmlspecialchars($file['full_name']) ?></strong><br>
                                    <small style="color: #71717a;">@<?= htmlspecialchars($file['username']) ?></small>
                                </td>
                                <td><?= formatFileSize($file['file_size']) ?></td>
                                <td>
                                    <small style="color: #71717a;"><?= htmlspecialchars($file['file_type'] ?? 'unknown') ?></small>
                                </td>
                                <td>
                                    <?php if ($file['encrypted']): ?>
                                        <span class="badge-custom badge-warning">
                                            <i class="bi bi-lock"></i> Encrypted
                                        </span>
                                    <?php else: ?>
                                        <span class="badge-custom badge-info">
                                            Normal
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= date('d M Y', strtotime($file['uploaded_at'])) ?><br>
                                    <small style="color: #71717a;"><?= date('H:i', strtotime($file['uploaded_at'])) ?></small>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?= $file['id'] ?>" title="Delete File">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Delete Modal -->
                            <div class="modal fade" id="deleteModal<?= $file['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete File</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete this file?</p>
                                            <div style="background: #27272a; padding: 1rem; border-radius: 8px; margin: 1rem 0;">
                                                <strong><?= htmlspecialchars($file['original_name']) ?></strong><br>
                                                <small style="color: #71717a;">
                                                    <?= formatFileSize($file['file_size']) ?> • 
                                                    Owner: @<?= htmlspecialchars($file['username']) ?>
                                                </small>
                                            </div>
                                            <p style="color: #f87171;"><strong>This action cannot be undone!</strong></p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
                                            <a href="?delete=<?= $file['id'] ?>" class="btn btn-danger">Delete File</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3" style="color: #71717a;">
                Total: <strong style="color: #e4e4e7;"><?= count($files) ?></strong> files 
                (<?= formatFileSize($totalSize) ?>)
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>