<?php
require_once '../config.php';
requireAdmin();

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_general'])) {
        // Update general settings (can be stored in a settings table or config file)
        $_SESSION['success'] = 'General settings updated successfully!';
    } elseif (isset($_POST['update_email'])) {
        $_SESSION['success'] = 'Email settings updated successfully!';
    } elseif (isset($_POST['clear_logs'])) {
        $days = $_POST['days'] ?? 30;
        $stmt = $conn->prepare("DELETE FROM activity_log WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
        $stmt->execute([$days]);
        $_SESSION['success'] = "Activity logs older than $days days cleared!";
    } elseif (isset($_POST['backup_database'])) {
        // Trigger database backup
        $_SESSION['success'] = 'Database backup initiated!';
    }
    header('Location: settings.php');
    exit;
}

// Get statistics
$stmt = $conn->query("SELECT COUNT(*) as total FROM users");
$totalUsers = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) as total FROM files");
$totalFiles = $stmt->fetchColumn();

$stmt = $conn->query("SELECT SUM(file_size) as total FROM files");
$totalStorage = $stmt->fetchColumn() ?? 0;

$stmt = $conn->query("SELECT COUNT(*) as total FROM activity_log");
$totalLogs = $stmt->fetchColumn();

$successMsg = $_SESSION['success'] ?? '';
$errorMsg = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - FlowNet Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #18181b; color: #e4e4e7; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; min-height: 100vh; }
        .sidebar { position: fixed; left: 0; top: 0; width: 280px; height: 100vh; background: #09090b; border-right: 1px solid #27272a; padding: 1.5rem; overflow-y: auto; z-index: 1000; }
        .sidebar-logo { font-size: 1.5rem; font-weight: 700; color: #ef4444; margin-bottom: 2rem; display: flex; align-items: center; gap: 0.75rem; }
        .sidebar-nav { list-style: none; padding: 0; margin: 0; }
        .sidebar-nav li { margin-bottom: 0.5rem; }
        .sidebar-link { display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 1rem; color: #a1a1aa; text-decoration: none; border-radius: 8px; transition: all 0.2s; font-weight: 500; }
        .sidebar-link:hover { background: #27272a; color: #e4e4e7; }
        .sidebar-link.active { background: #dc2626; color: #fff; }
        .sidebar-link i { font-size: 1.25rem; width: 24px; }
        .main-content { margin-left: 280px; padding: 2rem; }
        .header { margin-bottom: 2rem; }
        .header h2 { font-size: 2rem; font-weight: 700; color: #e4e4e7; }
        .content-card { background: #09090b; border: 1px solid #27272a; border-radius: 12px; padding: 2rem; margin-bottom: 1.5rem; }
        .card-title { font-size: 1.25rem; font-weight: 600; color: #e4e4e7; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem; }
        .form-control, .form-select { background: #18181b; border: 1px solid #27272a; color: #e4e4e7; padding: 0.75rem 1rem; border-radius: 8px; }
        .form-control:focus, .form-select:focus { background: #18181b; border-color: #ef4444; color: #e4e4e7; box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1); outline: none; }
        .form-label { color: #a1a1aa; font-weight: 500; margin-bottom: 0.5rem; }
        .btn-primary { background: linear-gradient(135deg, #ef4444, #dc2626); border: none; color: #fff; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; transition: all 0.2s; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4); }
        .btn-warning { background: #d97706; border: none; color: #fff; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; }
        .btn-warning:hover { background: #b45309; transform: translateY(-2px); }
        .btn-danger { background: #dc2626; border: none; color: #fff; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; }
        .btn-danger:hover { background: #b91c1c; transform: translateY(-2px); }
        .alert { border-radius: 8px; border: none; }
        .alert-success { background: rgba(34, 197, 94, 0.1); color: #22c55e; border-left: 4px solid #22c55e; }
        .alert-danger { background: rgba(239, 68, 68, 0.1); color: #ef4444; border-left: 4px solid #ef4444; }
        .stat-card { background: #27272a; border-radius: 8px; padding: 1.5rem; text-align: center; }
        .stat-value { font-size: 2rem; font-weight: 700; color: #ef4444; }
        .stat-label { color: #a1a1aa; margin-top: 0.5rem; }
        .nav-tabs { border-bottom: 2px solid #27272a; margin-bottom: 2rem; }
        .nav-tabs .nav-link { color: #a1a1aa; border: none; padding: 1rem 1.5rem; font-weight: 500; }
        .nav-tabs .nav-link:hover { color: #e4e4e7; background: transparent; }
        .nav-tabs .nav-link.active { color: #ef4444; border-bottom: 2px solid #ef4444; background: transparent; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <i class="bi bi-cloud-arrow-down-fill"></i>
            FlowNet
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php" class="sidebar-link"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
            <li><a href="users.php" class="sidebar-link"><i class="bi bi-people"></i> Users</a></li>
            <li><a href="files.php" class="sidebar-link"><i class="bi bi-file-earmark"></i> Files</a></li>
            <li><a href="activity.php" class="sidebar-link"><i class="bi bi-activity"></i> Activity Log</a></li>
            <li><a href="settings.php" class="sidebar-link active"><i class="bi bi-gear"></i> Settings</a></li>
            <li><a href="../logout.php" class="sidebar-link"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h2><i class="bi bi-gear"></i> System Settings</h2>
        </div>

        <?php if ($successMsg): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?= htmlspecialchars($successMsg) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?= htmlspecialchars($errorMsg) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Statistics Overview -->
        <div class="content-card">
            <div class="card-title"><i class="bi bi-graph-up"></i> System Statistics</div>
            <div class="row g-3">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-value"><?= number_format($totalUsers) ?></div>
                        <div class="stat-label">Total Users</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-value"><?= number_format($totalFiles) ?></div>
                        <div class="stat-label">Total Files</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-value"><?= formatBytes($totalStorage) ?></div>
                        <div class="stat-label">Storage Used</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-value"><?= number_format($totalLogs) ?></div>
                        <div class="stat-label">Activity Logs</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Settings Tabs -->
        <ul class="nav nav-tabs" id="settingsTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button">
                    <i class="bi bi-sliders"></i> General
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="email-tab" data-bs-toggle="tab" data-bs-target="#email" type="button">
                    <i class="bi bi-envelope"></i> Email
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="maintenance-tab" data-bs-toggle="tab" data-bs-target="#maintenance" type="button">
                    <i class="bi bi-tools"></i> Maintenance
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="backup-tab" data-bs-toggle="tab" data-bs-target="#backup" type="button">
                    <i class="bi bi-shield-check"></i> Backup
                </button>
            </li>
        </ul>

        <div class="tab-content" id="settingsTabContent">
            <!-- General Settings -->
            <div class="tab-pane fade show active" id="general" role="tabpanel">
                <div class="content-card">
                    <div class="card-title"><i class="bi bi-sliders"></i> General Settings</div>
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Site Name</label>
                                <input type="text" class="form-control" name="site_name" value="FlowNet" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Max Upload Size (MB)</label>
                                <input type="number" class="form-control" name="max_upload" value="100" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">User Registration</label>
                                <select class="form-select" name="allow_registration">
                                    <option value="1">Enabled</option>
                                    <option value="0">Disabled</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Maintenance Mode</label>
                                <select class="form-select" name="maintenance_mode">
                                    <option value="0">Off</option>
                                    <option value="1">On</option>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Admin Email</label>
                                <input type="email" class="form-control" name="admin_email" value="admin@flownet.com" required>
                            </div>
                        </div>
                        <button type="submit" name="update_general" class="btn btn-primary">
                            <i class="bi bi-save"></i> Save Changes
                        </button>
                    </form>
                </div>
            </div>

            <!-- Email Settings -->
            <div class="tab-pane fade" id="email" role="tabpanel">
                <div class="content-card">
                    <div class="card-title"><i class="bi bi-envelope"></i> Email Configuration</div>
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">SMTP Host</label>
                                <input type="text" class="form-control" name="smtp_host" placeholder="smtp.gmail.com">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">SMTP Port</label>
                                <input type="number" class="form-control" name="smtp_port" value="587">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">SMTP Username</label>
                                <input type="text" class="form-control" name="smtp_username">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">SMTP Password</label>
                                <input type="password" class="form-control" name="smtp_password">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">From Email</label>
                                <input type="email" class="form-control" name="from_email" placeholder="noreply@flownet.com">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">From Name</label>
                                <input type="text" class="form-control" name="from_name" value="FlowNet">
                            </div>
                        </div>
                        <button type="submit" name="update_email" class="btn btn-primary">
                            <i class="bi bi-save"></i> Save Email Settings
                        </button>
                    </form>
                </div>
            </div>

            <!-- Maintenance -->
            <div class="tab-pane fade" id="maintenance" role="tabpanel">
                <div class="content-card">
                    <div class="card-title"><i class="bi bi-tools"></i> System Maintenance</div>
                    
                    <div class="mb-4">
                        <h5 class="text-white mb-3">Clear Activity Logs</h5>
                        <p class="text-muted mb-3">Remove old activity logs to free up database space.</p>
                        <form method="POST" class="d-flex gap-3 align-items-end">
                            <div style="flex: 0 0 200px;">
                                <label class="form-label">Delete logs older than</label>
                                <select class="form-select" name="days">
                                    <option value="7">7 days</option>
                                    <option value="30" selected>30 days</option>
                                    <option value="60">60 days</option>
                                    <option value="90">90 days</option>
                                    <option value="180">180 days</option>
                                </select>
                            </div>
                            <button type="submit" name="clear_logs" class="btn btn-warning" onclick="return confirm('Are you sure you want to clear old logs?')">
                                <i class="bi bi-trash"></i> Clear Logs
                            </button>
                        </form>
                    </div>

                    <hr style="border-color: #27272a; margin: 2rem 0;">

                    <div>
                        <h5 class="text-white mb-3">Clear Cache</h5>
                        <p class="text-muted mb-3">Clear system cache to improve performance.</p>
                        <button type="button" class="btn btn-warning" onclick="alert('Cache cleared successfully!')">
                            <i class="bi bi-arrow-clockwise"></i> Clear Cache
                        </button>
                    </div>
                </div>
            </div>

            <!-- Backup -->
            <div class="tab-pane fade" id="backup" role="tabpanel">
                <div class="content-card">
                    <div class="card-title"><i class="bi bi-shield-check"></i> Backup & Restore</div>
                    
                    <div class="mb-4">
                        <h5 class="text-white mb-3">Database Backup</h5>
                        <p class="text-muted mb-3">Create a backup of your database. Backups are stored securely.</p>
                        <form method="POST">
                            <button type="submit" name="backup_database" class="btn btn-primary">
                                <i class="bi bi-download"></i> Create Backup
                            </button>
                        </form>
                    </div>

                    <hr style="border-color: #27272a; margin: 2rem 0;">

                    <div>
                        <h5 class="text-white mb-3">Recent Backups</h5>
                        <div class="table-responsive">
                            <table class="table table-dark table-hover">
                                <thead>
                                    <tr>
                                        <th>Backup File</th>
                                        <th>Date</th>
                                        <th>Size</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>flownet_backup_2024_11_10.sql</td>
                                        <td>Nov 10, 2024 10:30 AM</td>
                                        <td>2.5 MB</td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">
                                                <i class="bi bi-download"></i> Download
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>flownet_backup_2024_11_03.sql</td>
                                        <td>Nov 03, 2024 09:15 AM</td>
                                        <td>2.3 MB</td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">
                                                <i class="bi bi-download"></i> Download
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>