<?php
require_once '../config.php';
requireAdmin();

// Handle delete user
if (isset($_GET['delete'])) {
    $deleteId = $_GET['delete'];
    
    // Tidak bisa delete diri sendiri
    if ($deleteId == $_SESSION['user_id']) {
        $_SESSION['error'] = 'Tidak bisa menghapus akun sendiri!';
    } else {
        try {
            // Delete user files first
            $stmt = $conn->prepare("SELECT file_path FROM files WHERE user_id = ?");
            $stmt->execute([$deleteId]);
            $files = $stmt->fetchAll();
            
            foreach ($files as $file) {
                if (file_exists($file['file_path'])) {
                    unlink($file['file_path']);
                }
            }
            
            // Delete user (CASCADE akan hapus files, shared_files, activity_log)
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$deleteId]);
            
            $_SESSION['success'] = 'User berhasil dihapus!';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Gagal menghapus user!';
        }
    }
    header('Location: users.php');
    exit;
}

// Handle update role
if (isset($_POST['update_role'])) {
    $userId = $_POST['user_id'];
    $newRole = $_POST['role'];
    
    try {
        $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->execute([$newRole, $userId]);
        $_SESSION['success'] = 'Role berhasil diupdate!';
    } catch (Exception $e) {
        $_SESSION['error'] = 'Gagal update role!';
    }
    header('Location: users.php');
    exit;
}

// Handle verify email
if (isset($_GET['verify'])) {
    $userId = $_GET['verify'];
    try {
        $stmt = $conn->prepare("UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?");
        $stmt->execute([$userId]);
        $_SESSION['success'] = 'Email berhasil diverifikasi!';
    } catch (Exception $e) {
        $_SESSION['error'] = 'Gagal verifikasi email!';
    }
    header('Location: users.php');
    exit;
}

// Search & Filter
$search = $_GET['search'] ?? '';
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';

$sql = "SELECT u.*, 
        COUNT(DISTINCT f.id) as total_files,
        COALESCE(SUM(f.file_size), 0) as total_storage
        FROM users u
        LEFT JOIN files f ON u.id = f.user_id
        WHERE 1=1";

$params = [];

if ($search) {
    $sql .= " AND (u.username LIKE ? OR u.email LIKE ? OR u.full_name LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if ($roleFilter) {
    $sql .= " AND u.role = ?";
    $params[] = $roleFilter;
}

if ($statusFilter === 'verified') {
    $sql .= " AND u.email_verified = 1";
} elseif ($statusFilter === 'pending') {
    $sql .= " AND u.email_verified = 0";
}

$sql .= " GROUP BY u.id ORDER BY u.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$successMsg = $_SESSION['success'] ?? '';
$errorMsg = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - FlowNet Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #18181b;
            color: #e4e4e7;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: #09090b;
            border-right: 1px solid #27272a;
            padding: 1.5rem;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: #ef4444;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: #a1a1aa;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }

        .sidebar-link:hover {
            background: #27272a;
            color: #e4e4e7;
        }

        .sidebar-link.active {
            background: #dc2626;
            color: #fff;
        }

        .sidebar-link i {
            font-size: 1.25rem;
            width: 24px;
        }

        .main-content {
            margin-left: 280px;
            padding: 2rem;
        }

        .header {
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h2 {
            font-size: 2rem;
            font-weight: 700;
            color: #e4e4e7;
        }

        .content-card {
            background: #09090b;
            border: 1px solid #27272a;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .search-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .form-control, .form-select {
            background: #18181b;
            border: 1px solid #27272a;
            color: #e4e4e7;
            padding: 0.75rem 1rem;
            border-radius: 8px;
        }

        .form-control:focus, .form-select:focus {
            background: #18181b;
            border-color: #ef4444;
            color: #e4e4e7;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            outline: none;
        }

        .table-custom {
            width: 100%;
        }

        .table-custom th {
            color: #a1a1aa;
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            padding: 1rem;
            border-bottom: 1px solid #27272a;
        }

        .table-custom td {
            color: #e4e4e7;
            padding: 1rem;
            border-bottom: 1px solid #27272a;
        }

        .table-custom tr:hover {
            background: #27272a;
        }

        .avatar-small {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #ef4444, #dc2626);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: #fff;
        }

        .badge-custom {
            padding: 0.375rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-success {
            background: rgba(34, 197, 94, 0.2);
            color: #4ade80;
        }

        .badge-danger {
            background: rgba(239, 68, 68, 0.2);
            color: #f87171;
        }

        .badge-warning {
            background: rgba(251, 146, 60, 0.2);
            color: #fb923c;
        }

        .badge-info {
            background: rgba(59, 130, 246, 0.2);
            color: #60a5fa;
        }

        .btn-primary {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
        }

        .btn-sm {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
        }

        .btn-danger {
            background: #dc2626;
            border: none;
            color: #fff;
        }

        .btn-danger:hover {
            background: #b91c1c;
        }

        .btn-success {
            background: #059669;
            border: none;
            color: #fff;
        }

        .btn-success:hover {
            background: #047857;
        }

        .btn-warning {
            background: #d97706;
            border: none;
            color: #fff;
        }

        .btn-warning:hover {
            background: #b45309;
        }

        .alert {
            border-radius: 8px;
            border: 1px solid;
        }

        .alert-success {
            background: rgba(34, 197, 94, 0.1);
            border-color: rgba(34, 197, 94, 0.3);
            color: #4ade80;
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
            color: #f87171;
        }

        .modal-content {
            background: #09090b;
            border: 1px solid #27272a;
            color: #e4e4e7;
        }

        .modal-header {
            border-bottom: 1px solid #27272a;
        }

        .modal-footer {
            border-top: 1px solid #27272a;
        }

        .btn-close {
            filter: invert(1);
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #09090b;
        }

        ::-webkit-scrollbar-thumb {
            background: #27272a;
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .search-bar {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <i class="bi bi-shield-lock"></i>
            Admin Panel
        </div>

        <ul class="sidebar-nav">
            <li>
                <a href="index.php" class="sidebar-link">
                    <i class="bi bi-speedometer2"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="users.php" class="sidebar-link active">
                    <i class="bi bi-people"></i>
                    Users
                </a>
            </li>
            <li>
                <a href="files.php" class="sidebar-link">
                    <i class="bi bi-files"></i>
                    Files
                </a>
            </li>
            <li>
                <a href="activity.php" class="sidebar-link">
                    <i class="bi bi-clock-history"></i>
                    Activity Log
                </a>
            </li>
            <li>
                <a href="settings.php" class="sidebar-link">
                    <i class="bi bi-gear"></i>
                    Settings
                </a>
            </li>
            <li style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #27272a;">
                <a href="../dashboard.php" class="sidebar-link">
                    <i class="bi bi-arrow-left"></i>
                    Back to Dashboard
                </a>
            </li>
            <li>
                <a href="../logout.php" class="sidebar-link">
                    <i class="bi bi-box-arrow-right"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <?php if ($successMsg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?= $successMsg ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle"></i> <?= $errorMsg ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="header">
            <div>
                <h2>User Management</h2>
                <p style="color: #71717a;">Manage all users and their permissions</p>
            </div>
        </div>

        <div class="content-card">
            <!-- Search & Filter -->
            <form method="GET" class="search-bar">
                <input type="text" class="form-control" name="search" placeholder="Search users..." value="<?= htmlspecialchars($search) ?>" style="flex: 1;">
                <select class="form-select" name="role" style="width: 150px;">
                    <option value="">All Roles</option>
                    <option value="user" <?= $roleFilter === 'user' ? 'selected' : '' ?>>User</option>
                    <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>Admin</option>
                </select>
                <select class="form-select" name="status" style="width: 150px;">
                    <option value="">All Status</option>
                    <option value="verified" <?= $statusFilter === 'verified' ? 'selected' : '' ?>>Verified</option>
                    <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>Pending</option>
                </select>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search"></i> Search
                </button>
                <?php if ($search || $roleFilter || $statusFilter): ?>
                <a href="users.php" class="btn btn-danger">
                    <i class="bi bi-x-lg"></i> Clear
                </a>
                <?php endif; ?>
            </form>

            <!-- Users Table -->
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Files</th>
                            <th>Storage</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 0.75rem;">
                                    <?php if ($user['avatar'] && file_exists('../' . $user['avatar'])): ?>
                                        <img src="../<?= $user['avatar'] ?>" alt="Avatar" class="avatar-small">
                                    <?php else: ?>
                                        <div class="avatar-small">
                                            <?= strtoupper(substr($user['full_name'], 0, 2)) ?>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <strong><?= htmlspecialchars($user['full_name']) ?></strong><br>
                                        <small style="color: #71717a;">@<?= htmlspecialchars($user['username']) ?></small>
                                    </div>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td>
                                <button class="badge-custom <?= $user['role'] === 'admin' ? 'badge-danger' : 'badge-info' ?>" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#roleModal<?= $user['id'] ?>"
                                        style="border: none; cursor: pointer;">
                                    <?= ucfirst($user['role']) ?>
                                </button>
                            </td>
                            <td>
                                <?php if ($user['email_verified']): ?>
                                    <span class="badge-custom badge-success">
                                        <i class="bi bi-check-circle"></i> Verified
                                    </span>
                                <?php else: ?>
                                    <span class="badge-custom badge-warning">
                                        <i class="bi bi-clock"></i> Pending
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?= $user['total_files'] ?></td>
                            <td><?= formatFileSize($user['total_storage']) ?></td>
                            <td><?= date('d M Y', strtotime($user['created_at'])) ?></td>
                            <td>
                                <div style="display: flex; gap: 0.5rem;">
                                    <?php if (!$user['email_verified']): ?>
                                    <a href="?verify=<?= $user['id'] ?>" class="btn btn-sm btn-success" title="Verify Email">
                                        <i class="bi bi-check-circle"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?= $user['id'] ?>" title="Delete User">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>

                        <!-- Role Modal -->
                        <div class="modal fade" id="roleModal<?= $user['id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Change Role: <?= htmlspecialchars($user['full_name']) ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST">
                                        <div class="modal-body">
                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                            <div class="mb-3">
                                                <label class="form-label">Select Role</label>
                                                <select class="form-select" name="role" required>
                                                    <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>User</option>
                                                    <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" name="update_role" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- Delete Modal -->
                        <div class="modal fade" id="deleteModal<?= $user['id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Delete User</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Are you sure you want to delete user <strong><?= htmlspecialchars($user['full_name']) ?></strong>?</p>
                                        <p style="color: #f87171;">This will also delete:</p>
                                        <ul style="color: #71717a;">
                                            <li><?= $user['total_files'] ?> files (<?= formatFileSize($user['total_storage']) ?>)</li>
                                            <li>All shared files</li>
                                            <li>All activity logs</li>
                                        </ul>
                                        <p style="color: #f87171;"><strong>This action cannot be undone!</strong></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
                                        <a href="?delete=<?= $user['id'] ?>" class="btn btn-danger">Delete User</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3" style="color: #71717a;">
                Total: <strong style="color: #e4e4e7;"><?= count($users) ?></strong> users found
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>