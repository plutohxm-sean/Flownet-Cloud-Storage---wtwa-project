<?php
require_once '../config.php';
requireAdmin();

// Pagination
$page = $_GET['page'] ?? 1;
$perPage = 50;
$offset = ($page - 1) * $perPage;

// Search & Filter
$search = $_GET['search'] ?? '';
$userFilter = $_GET['user'] ?? '';
$actionFilter = $_GET['action'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

$sql = "SELECT a.*, u.username, u.full_name, u.avatar 
        FROM activity_log a 
        JOIN users u ON a.user_id = u.id 
        WHERE 1=1";

$params = [];

if ($search) {
    $sql .= " AND (a.action LIKE ? OR a.details LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if ($userFilter) {
    $sql .= " AND a.user_id = ?";
    $params[] = $userFilter;
}

if ($actionFilter) {
    $sql .= " AND a.action = ?";
    $params[] = $actionFilter;
}

if ($dateFrom) {
    $sql .= " AND DATE(a.created_at) >= ?";
    $params[] = $dateFrom;
}

if ($dateTo) {
    $sql .= " AND DATE(a.created_at) <= ?";
    $params[] = $dateTo;
}

// Count total
$countSql = str_replace("SELECT a.*, u.username, u.full_name, u.avatar", "SELECT COUNT(*)", $sql);
$countStmt = $conn->prepare($countSql);
$countStmt->execute($params);
$totalRecords = $countStmt->fetchColumn();
$totalPages = ceil($totalRecords / $perPage);

// Get activities
$sql .= " ORDER BY a.created_at DESC LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$activities = $stmt->fetchAll();

// Get all users for filter
$usersStmt = $conn->query("SELECT id, username, full_name FROM users ORDER BY username");
$allUsers = $usersStmt->fetchAll();

// Get unique actions
$actionsStmt = $conn->query("SELECT DISTINCT action FROM activity_log ORDER BY action");
$allActions = $actionsStmt->fetchAll();

$successMsg = $_SESSION['success'] ?? '';
$errorMsg = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Log - FlowNet Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #18181b;
            color: #e4e4e7;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: #09090b;
            border-right: 1px solid #27272a;
            padding: 1.5rem;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: #ef4444;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: #a1a1aa;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }

        .sidebar-link:hover {
            background: #27272a;
            color: #e4e4e7;
        }

        .sidebar-link.active {
            background: #dc2626;
            color: #fff;
        }

        .sidebar-link i {
            font-size: 1.25rem;
            width: 24px;
        }

        .main-content {
            margin-left: 280px;
            padding: 2rem;
        }

        .header {
            margin-bottom: 2rem;
        }

        .header h2 {
            font-size: 2rem;
            font-weight: 700;
            color: #e4e4e7;
        }

        .content-card {
            background: #09090b;
            border: 1px solid #27272a;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .search-bar {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 1fr auto;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .form-control, .form-select {
            background: #18181b;
            border: 1px solid #27272a;
            color: #e4e4e7;
            padding: 0.75rem 1rem;
            border-radius: 8px;
        }

        .form-control:focus, .form-select:focus {
            background: #18181b;
            border-color: #ef4444;
            color: #e4e4e7;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            outline: none;
        }

        .activity-timeline {
            position: relative;
        }

        .activity-item {
            padding: 1.5rem;
            border-bottom: 1px solid #27272a;
            display: flex;
            gap: 1rem;
            transition: all 0.2s;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-item:hover {
            background: #27272a;
        }

        .activity-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, #ef4444, #dc2626);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: #fff;
            flex-shrink: 0;
        }

        .activity-content {
            flex: 1;
        }

        .activity-user {
            font-weight: 600;
            color: #e4e4e7;
            margin-bottom: 0.25rem;
        }

        .activity-action {
            color: #a1a1aa;
            margin-bottom: 0.25rem;
        }

        .activity-details {
            font-size: 0.875rem;
            color: #71717a;
            margin-bottom: 0.5rem;
        }

        .activity-meta {
            font-size: 0.875rem;
            color: #71717a;
            display: flex;
            gap: 1rem;
        }

        .badge-custom {
            padding: 0.375rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-primary {
            background: rgba(59, 130, 246, 0.2);
            color: #60a5fa;
        }

        .badge-success {
            background: rgba(34, 197, 94, 0.2);
            color: #4ade80;
        }

        .badge-warning {
            background: rgba(251, 146, 60, 0.2);
            color: #fb923c;
        }

        .badge-danger {
            background: rgba(239, 68, 68, 0.2);
            color: #f87171;
        }

        .btn-primary {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            color: #fff;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
        }

        .btn-danger {
            background: #dc2626;
            border: none;
            color: #fff;
        }

        .pagination {
            display: flex;
            gap: 0.5rem;
            justify-content: center;
            margin-top: 2rem;
        }

        .page-link {
            background: #27272a;
            border: 1px solid #3f3f46;
            color: #e4e4e7;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.2s;
        }

        .page-link:hover {
            background: #3f3f46;
            color: #fff;
        }

        .page-link.active {
            background: #ef4444;
            border-color: #ef4444;
            color: #fff;
        }

        .page-link.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .alert {
            border-radius: 8px;
            border: 1px solid;
        }

        .alert-success {
            background: rgba(34, 197, 94, 0.1);
            border-color: rgba(34, 197, 94, 0.3);
            color: #4ade80;
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
            color: #f87171;
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #09090b;
        }

        ::-webkit-scrollbar-thumb {
            background: #27272a;
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .search-bar {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <i class="bi bi-shield-lock"></i>
            Admin Panel
        </div>

        <ul class="sidebar-nav">
            <li>
                <a href="index.php" class="sidebar-link">
                    <i class="bi bi-speedometer2"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="users.php" class="sidebar-link">
                    <i class="bi bi-people"></i>
                    Users
                </a>
            </li>
            <li>
                <a href="files.php" class="sidebar-link">
                    <i class="bi bi-files"></i>
                    Files
                </a>
            </li>
            <li>
                <a href="activity.php" class="sidebar-link active">
                    <i class="bi bi-clock-history"></i>
                    Activity Log
                </a>
            </li>
            <li>
                <a href="settings.php" class="sidebar-link">
                    <i class="bi bi-gear"></i>
                    Settings
                </a>
            </li>
            <li style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #27272a;">
                <a href="../dashboard.php" class="sidebar-link">
                    <i class="bi bi-arrow-left"></i>
                    Back to Dashboard
                </a>
            </li>
            <li>
                <a href="../logout.php" class="sidebar-link">
                    <i class="bi bi-box-arrow-right"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <?php if ($successMsg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?= $successMsg ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle"></i> <?= $errorMsg ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="header">
            <h2>Activity Log</h2>
            <p style="color: #71717a;">Monitor all system activities</p>
        </div>

        <div class="content-card">
            <!-- Search & Filter -->
            <form method="GET" class="search-bar">
                <input type="text" class="form-control" name="search" placeholder="Search activity..." value="<?= htmlspecialchars($search) ?>">
                
                <select class="form-select" name="user">
                    <option value="">All Users</option>
                    <?php foreach ($allUsers as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= $userFilter == $u['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($u['full_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select class="form-select" name="action">
                    <option value="">All Actions</option>
                    <?php foreach ($allActions as $a): ?>
                        <option value="<?= $a['action'] ?>" <?= $actionFilter === $a['action'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($a['action']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <input type="date" class="form-control" name="date_from" value="<?= htmlspecialchars($dateFrom) ?>" placeholder="From">
                
                <input type="date" class="form-control" name="date_to" value="<?= htmlspecialchars($dateTo) ?>" placeholder="To">

                <div style="display: flex; gap: 0.5rem;">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i>
                    </button>
                    
                    <?php if ($search || $userFilter || $actionFilter || $dateFrom || $dateTo): ?>
                    <a href="activity.php" class="btn btn-danger">
                        <i class="bi bi-x-lg"></i>
                    </a>
                    <?php endif; ?>
                </div>
            </form>

            <!-- Activity Timeline -->
            <div class="activity-timeline">
                <?php if (empty($activities)): ?>
                    <div style="text-align: center; color: #71717a; padding: 3rem;">
                        <i class="bi bi-inbox" style="font-size: 3rem; display: block; margin-bottom: 1rem;"></i>
                        No activity found
                    </div>
                <?php else: ?>
                    <?php foreach ($activities as $activity): ?>
                    <div class="activity-item">
                        <?php if ($activity['avatar'] && file_exists('../' . $activity['avatar'])): ?>
                            <img src="../<?= $activity['avatar'] ?>" alt="Avatar" class="activity-avatar">
                        <?php else: ?>
                            <div class="activity-avatar">
                                <?= strtoupper(substr($activity['full_name'], 0, 2)) ?>
                            </div>
                        <?php endif; ?>

                        <div class="activity-content">
                            <div class="activity-user">
                                <?= htmlspecialchars($activity['full_name']) ?>
                                <small style="color: #71717a; font-weight: normal;">@<?= htmlspecialchars($activity['username']) ?></small>
                            </div>
                            <div class="activity-action">
                                <span class="badge-custom badge-primary"><?= htmlspecialchars($activity['action']) ?></span>
                            </div>
                            <?php if ($activity['details']): ?>
                                <div class="activity-details">
                                    <?= htmlspecialchars($activity['details']) ?>
                                </div>
                            <?php endif; ?>
                            <div class="activity-meta">
                                <span>
                                    <i class="bi bi-clock"></i>
                                    <?= date('d M Y, H:i', strtotime($activity['created_at'])) ?>
                                </span>
                                <span>
                                    <i class="bi bi-geo-alt"></i>
                                    <?= htmlspecialchars($activity['ip_address']) ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?= $page - 1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k !== 'page', ARRAY_FILTER_USE_KEY)) ?>" class="page-link">
                        <i class="bi bi-chevron-left"></i>
                    </a>
                <?php else: ?>
                    <span class="page-link disabled">
                        <i class="bi bi-chevron-left"></i>
                    </span>
                <?php endif; ?>

                <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                    <a href="?page=<?= $i ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k !== 'page', ARRAY_FILTER_USE_KEY)) ?>" 
                       class="page-link <?= $i === (int)$page ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?= $page + 1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k !== 'page', ARRAY_FILTER_USE_KEY)) ?>" class="page-link">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                <?php else: ?>
                    <span class="page-link disabled">
                        <i class="bi bi-chevron-right"></i>
                    </span>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="mt-3" style="color: #71717a; text-align: center;">
                Showing <?= count($activities) ?> of <?= $totalRecords ?> records
                (Page <?= $page ?> of <?= $totalPages ?>)
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>