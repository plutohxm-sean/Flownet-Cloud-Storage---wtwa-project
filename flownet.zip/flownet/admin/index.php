<?php
require_once '../config.php';

// Require admin access
requireAdmin();

$adminName = $_SESSION['full_name'];

// Get statistics
$stmt = $conn->query("SELECT COUNT(*) as total FROM users");
$totalUsers = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM files");
$totalFiles = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT SUM(file_size) as total FROM files");
$totalStorage = $stmt->fetch()['total'] ?? 0;

$stmt = $conn->query("SELECT COUNT(*) as total FROM shared_files");
$totalShares = $stmt->fetch()['total'];

// Get user growth data (last 7 days)
$userGrowth = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = ?");
    $stmt->execute([$date]);
    $count = $stmt->fetch()['count'];
    $userGrowth[$date] = $count;
}

// Get storage by user (top 5)
$stmt = $conn->query("
    SELECT u.username, SUM(f.file_size) as total_size 
    FROM users u 
    LEFT JOIN files f ON u.id = f.user_id 
    GROUP BY u.id 
    ORDER BY total_size DESC 
    LIMIT 5
");
$storageByUser = $stmt->fetchAll();

// Get file upload trend (last 7 days)
$uploadTrend = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM files WHERE DATE(uploaded_at) = ?");
    $stmt->execute([$date]);
    $count = $stmt->fetch()['count'];
    $uploadTrend[$date] = $count;
}

// Get recent users
$stmt = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
$recentUsers = $stmt->fetchAll();

// Get recent files
$stmt = $conn->query("SELECT f.*, u.username FROM files f JOIN users u ON f.user_id = u.id ORDER BY f.uploaded_at DESC LIMIT 5");
$recentFiles = $stmt->fetchAll();

// Get activity log
$stmt = $conn->query("SELECT a.*, u.username FROM activity_log a JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 10");
$activities = $stmt->fetchAll();

$successMsg = $_SESSION['success'] ?? '';
$errorMsg = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - FlowNet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-dark: #0a0e1a;
            --bg-secondary: #111827;
            --bg-card: #1f2937;
            --bg-hover: #374151;
            --text-primary: #f9fafb;
            --text-secondary: #d1d5db;
            --text-muted: #9ca3af;
            --accent-blue: #3b82f6;
            --accent-purple: #8b5cf6;
            --accent-pink: #ec4899;
            --accent-green: #10b981;
            --accent-orange: #f59e0b;
            --border-color: rgba(75, 85, 99, 0.3);
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.5);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.5);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.6);
        }

        body {
            background: linear-gradient(135deg, var(--bg-dark) 0%, #1a1f35 100%);
            color: var(--text-primary);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            min-height: 100vh;
            font-size: 14px;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: rgba(17, 24, 39, 0.95);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-color);
            padding: 2rem 0;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 24px rgba(0, 0, 0, 0.4);
        }

        .sidebar-logo {
            padding: 0 2rem 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border-bottom: 1px solid var(--border-color);
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .logo-icon i {
            font-size: 1.75rem;
            color: white;
        }

        .logo-text .brand-name {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text .brand-tagline {
            font-size: 0.65rem;
            color: var(--text-muted);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sidebar-nav {
            padding: 1.5rem 0;
        }

        .nav-section-title {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            padding: 0 2rem;
            margin-bottom: 0.5rem;
            letter-spacing: 0.5px;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.875rem 2rem;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.2s;
            font-weight: 500;
            position: relative;
        }

        .sidebar-link:hover {
            background: rgba(59, 130, 246, 0.1);
            color: var(--accent-blue);
        }

        .sidebar-link.active {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(139, 92, 246, 0.2));
            color: var(--accent-blue);
        }

        .sidebar-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 70%;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            border-radius: 0 2px 2px 0;
        }

        .sidebar-link i {
            font-size: 1.25rem;
            width: 24px;
        }

        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 2rem;
        }

        /* Header */
        .page-header {
            margin-bottom: 2rem;
        }

        .page-title {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #fff 0%, #a5b4fc 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.5rem;
        }

        .page-subtitle {
            color: var(--text-muted);
            font-size: 1rem;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card-ultra {
            background: linear-gradient(135deg, var(--bg-card) 0%, rgba(31, 41, 55, 0.6) 100%);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            position: relative;
            overflow: hidden;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .stat-card-ultra::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
            opacity: 0;
            transition: opacity 0.3s;
        }

        .stat-card-ultra:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            border-color: rgba(59, 130, 246, 0.5);
        }

        .stat-card-ultra:hover::before {
            opacity: 1;
        }

        .stat-icon-wrapper {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1.5rem;
            position: relative;
        }

        .stat-icon-wrapper::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 16px;
            padding: 2px;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
        }

        .stat-icon-wrapper i {
            font-size: 2rem;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .stat-label {
            font-size: 0.875rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .stat-trend {
            font-size: 0.875rem;
            color: var(--accent-green);
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }

        /* Charts Section */
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .chart-card-premium {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-md);
            transition: all 0.3s;
        }

        .chart-card-premium:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: rgba(59, 130, 246, 0.3);
        }

        .chart-title {
            font-size: 1.125rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .chart-container {
            height: 320px;
        }

        /* Content Card */
        .content-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
        }

        .card-title {
            font-size: 1.125rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-primary);
        }

        /* Table */
        .table-custom {
            width: 100%;
            margin: 0;
        }

        .table-custom th {
            color: var(--text-muted);
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .table-custom td {
            color: var(--text-secondary);
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .table-custom tr:hover {
            background: var(--bg-hover);
        }

        /* Badge */
        .badge-custom {
            padding: 0.375rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-success {
            background: rgba(16, 185, 129, 0.2);
            color: var(--accent-green);
        }

        .badge-danger {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
        }

        .badge-warning {
            background: rgba(245, 158, 11, 0.2);
            color: var(--accent-orange);
        }

        .badge-info {
            background: rgba(59, 130, 246, 0.2);
            color: var(--accent-blue);
        }

        /* Button */
        .btn-primary-custom {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border: none;
            color: #fff;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
            color: #fff;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
        }

        /* Alert */
        .alert-modern {
            padding: 0.875rem 1rem;
            border-radius: 8px;
            border: 1px solid;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .alert-success-modern {
            background: rgba(16, 185, 129, 0.1);
            border-color: rgba(16, 185, 129, 0.3);
            color: var(--accent-green);
        }

        .alert-danger-modern {
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
            color: #ef4444;
        }

        /* Activity Timeline */
        .activity-item {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            gap: 1rem;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(139, 92, 246, 0.2));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .activity-icon i {
            color: var(--accent-blue);
        }

        .activity-info {
            flex: 1;
        }

        .activity-title {
            color: var(--text-primary);
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .activity-desc {
            color: var(--text-muted);
            font-size: 0.875rem;
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-dark);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--bg-hover);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(75, 85, 99, 0.6);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .charts-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stat-card-ultra,
        .chart-card-premium,
        .content-card {
            animation: fadeInUp 0.6s ease-out backwards;
        }

        .stat-card-ultra:nth-child(1) { animation-delay: 0.1s; }
        .stat-card-ultra:nth-child(2) { animation-delay: 0.2s; }
        .stat-card-ultra:nth-child(3) { animation-delay: 0.3s; }
        .stat-card-ultra:nth-child(4) { animation-delay: 0.4s; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon">
                <i class="bi bi-cloud-lightning-rain-fill"></i>
            </div>
            <div class="logo-text">
                <div class="brand-name">FlowNet</div>
                <div class="brand-tagline">Admin Panel</div>
            </div>
        </div>

        <div class="sidebar-nav">
            <div class="nav-section-title">Main</div>
            <a href="index.php" class="sidebar-link active">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
            <a href="users.php" class="sidebar-link">
                <i class="bi bi-people"></i>
                <span>Users</span>
            </a>
            <a href="files.php" class="sidebar-link">
                <i class="bi bi-files"></i>
                <span>Files</span>
            </a>
            <a href="activity.php" class="sidebar-link">
                <i class="bi bi-clock-history"></i>
                <span>Activity Log</span>
            </a>
            <a href="settings.php" class="sidebar-link">
                <i class="bi bi-gear"></i>
                <span>Settings</span>
            </a>

            <div class="nav-section-title" style="margin-top: 2rem;">Navigation</div>
            <a href="../dashboard.php" class="sidebar-link">
                <i class="bi bi-arrow-left"></i>
                <span>Back to Dashboard</span>
            </a>
            <a href="../logout.php" class="sidebar-link">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <?php if ($successMsg): ?>
        <div class="alert-modern alert-success-modern">
            <i class="bi bi-check-circle-fill" style="font-size: 1.5rem;"></i>
            <span><?= htmlspecialchars($successMsg) ?></span>
        </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
        <div class="alert-modern alert-danger-modern">
            <i class="bi bi-exclamation-circle-fill" style="font-size: 1.5rem;"></i>
            <span><?= htmlspecialchars($errorMsg) ?></span>
        </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="page-header">
            <h1 class="page-title">Admin Dashboard</h1>
            <p class="page-subtitle">Welcome back, <?= htmlspecialchars($adminName) ?>! 👋</p>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card-ultra">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-people"></i>
                </div>
                <div class="stat-label">Total Users</div>
                <div class="stat-value"><?= $totalUsers ?></div>
                <div class="stat-trend">
                    <i class="bi bi-arrow-up"></i>
                    <span>All registered</span>
                </div>
            </div>

            <div class="stat-card-ultra">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-files"></i>
                </div>
                <div class="stat-label">Total Files</div>
                <div class="stat-value"><?= $totalFiles ?></div>
                <div class="stat-trend">
                    <i class="bi bi-arrow-up"></i>
                    <span>All uploaded</span>
                </div>
            </div>

            <div class="stat-card-ultra">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-hdd-stack"></i>
                </div>
                <div class="stat-label">Total Storage</div>
                <div class="stat-value"><?= formatFileSize($totalStorage) ?></div>
                <div class="stat-trend">
                    <i class="bi bi-arrow-up"></i>
                    <span>Space used</span>
                </div>
            </div>

            <div class="stat-card-ultra">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-share"></i>
                </div>
                <div class="stat-label">Total Shares</div>
                <div class="stat-value"><?= $totalShares ?></div>
                <div class="stat-trend">
                    <i class="bi bi-arrow-up"></i>
                    <span>Shared files</span>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-grid">
            <div class="chart-card-premium">
                <h5 class="chart-title">
                    <i class="bi bi-graph-up"></i> User Growth (7 Days)
                </h5>
                <div id="userGrowthChart" class="chart-container"></div>
            </div>

            <div class="chart-card-premium">
                <h5 class="chart-title">
                    <i class="bi bi-cloud-upload"></i> Upload Trend (7 Days)
                </h5>
                <div id="uploadTrendChart" class="chart-container"></div>
            </div>
        </div>

        <div class="charts-grid">
            <div class="chart-card-premium">
                <h5 class="chart-title">
                    <i class="bi bi-person-check"></i> Top 5 Users by Storage
                </h5>
                <div id="storageByUserChart" class="chart-container"></div>
            </div>

            <div class="chart-card-premium">
                <h5 class="chart-title">
                    <i class="bi bi-pie-chart"></i> User Role Distribution
                </h5>
                <div id="userRoleChart" class="chart-container"></div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <!-- Recent Users -->
                <div class="content-card">
                    <h5 class="card-title">
                        <i class="bi bi-people"></i> Recent Users
                    </h5>
                    <div class="table-responsive">
                        <table class="table-custom">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Registered</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentUsers as $user): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($user['full_name']) ?></strong><br>
                                        <small style="color: var(--text-muted);">@<?= htmlspecialchars($user['username']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td>
                                        <span class="badge-custom <?= $user['role'] === 'admin' ? 'badge-danger' : 'badge-info' ?>">
                                            <?= ucfirst($user['role']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge-custom <?= $user['email_verified'] ? 'badge-success' : 'badge-warning' ?>">
                                            <?= $user['email_verified'] ? 'Verified' : 'Pending' ?>
                                        </span>
                                    </td>
                                    <td><?= date('d M Y', strtotime($user['created_at'])) ?></td>
                                    <td>
                                        <a href="users.php?edit=<?= $user['id'] ?>" class="btn-primary-custom btn-sm">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center mt-3">
                        <a href="files.php" class="btn-primary-custom">View All Files</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <!-- Recent Activity -->
                <div class="content-card">
                    <h5 class="card-title">
                        <i class="bi bi-clock-history"></i> Recent Activity
                    </h5>
                    <?php foreach ($activities as $activity): ?>
                    <div class="activity-item">
                        <div class="activity-icon">
                            <i class="bi bi-circle-fill" style="font-size: 0.5rem;"></i>
                        </div>
                        <div class="activity-info">
                            <div class="activity-title">
                                @<?= htmlspecialchars($activity['username']) ?>
                            </div>
                            <div class="activity-desc">
                                <?= htmlspecialchars($activity['action']) ?>
                                <?php if ($activity['details']): ?>
                                    - <?= htmlspecialchars($activity['details']) ?>
                                <?php endif; ?>
                            </div>
                            <div class="activity-desc">
                                <i class="bi bi-clock"></i> <?= date('d M Y H:i', strtotime($activity['created_at'])) ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <div class="text-center mt-3">
                        <a href="activity.php" class="btn-primary-custom">View All Activity</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Highcharts Dark Theme
        Highcharts.setOptions({
            colors: ['#3b82f6', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b', '#6366f1'],
            chart: {
                backgroundColor: 'transparent',
                style: {
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
                }
            },
            title: {
                style: {
                    color: '#f9fafb',
                    fontSize: '16px',
                    fontWeight: '600'
                }
            },
            xAxis: {
                gridLineColor: 'rgba(75, 85, 99, 0.2)',
                labels: {
                    style: {
                        color: '#9ca3af'
                    }
                },
                lineColor: 'rgba(75, 85, 99, 0.3)',
                tickColor: 'rgba(75, 85, 99, 0.3)'
            },
            yAxis: {
                gridLineColor: 'rgba(75, 85, 99, 0.2)',
                labels: {
                    style: {
                        color: '#9ca3af'
                    }
                },
                title: {
                    style: {
                        color: '#d1d5db'
                    }
                }
            },
            tooltip: {
                backgroundColor: 'rgba(17, 24, 39, 0.95)',
                borderColor: 'rgba(75, 85, 99, 0.5)',
                style: {
                    color: '#f9fafb'
                }
            },
            legend: {
                itemStyle: {
                    color: '#f9fafb'
                },
                itemHoverStyle: {
                    color: '#3b82f6'
                }
            },
            credits: {
                enabled: false
            },
            exporting: {
                enabled: false
            }
        });

        // 1. User Growth Chart
        Highcharts.chart('userGrowthChart', {
            chart: {
                type: 'areaspline'
            },
            title: {
                text: null
            },
            xAxis: {
                categories: [
                    <?php foreach (array_keys($userGrowth) as $date): ?>
                        '<?= date('D, M j', strtotime($date)) ?>',
                    <?php endforeach; ?>
                ]
            },
            yAxis: {
                title: {
                    text: 'New Users'
                },
                min: 0
            },
            tooltip: {
                shared: true,
                valueSuffix: ' users'
            },
            plotOptions: {
                areaspline: {
                    fillColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0,
                            x2: 0,
                            y2: 1
                        },
                        stops: [
                            [0, 'rgba(59, 130, 246, 0.5)'],
                            [1, 'rgba(59, 130, 246, 0.05)']
                        ]
                    },
                    marker: {
                        radius: 4
                    },
                    lineWidth: 3
                }
            },
            series: [{
                name: 'New Users',
                data: [
                    <?php foreach ($userGrowth as $count): ?>
                        <?= $count ?>,
                    <?php endforeach; ?>
                ]
            }]
        });

        // 2. Upload Trend Chart
        Highcharts.chart('uploadTrendChart', {
            chart: {
                type: 'column'
            },
            title: {
                text: null
            },
            xAxis: {
                categories: [
                    <?php foreach (array_keys($uploadTrend) as $date): ?>
                        '<?= date('D, M j', strtotime($date)) ?>',
                    <?php endforeach; ?>
                ]
            },
            yAxis: {
                title: {
                    text: 'Files Uploaded'
                },
                min: 0
            },
            tooltip: {
                valueSuffix: ' files'
            },
            plotOptions: {
                column: {
                    borderRadius: 8,
                    dataLabels: {
                        enabled: true,
                        style: {
                            textOutline: 'none'
                        }
                    }
                }
            },
            legend: {
                enabled: false
            },
            series: [{
                name: 'Uploads',
                data: [
                    <?php foreach ($uploadTrend as $count): ?>
                        <?= $count ?>,
                    <?php endforeach; ?>
                ],
                color: '#8b5cf6'
            }]
        });

        // 3. Storage by User Chart
        Highcharts.chart('storageByUserChart', {
            chart: {
                type: 'bar'
            },
            title: {
                text: null
            },
            xAxis: {
                categories: [
                    <?php foreach ($storageByUser as $user): ?>
                        '@<?= addslashes($user['username']) ?>',
                    <?php endforeach; ?>
                ],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Storage (MB)'
                }
            },
            tooltip: {
                valueSuffix: ' MB'
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true,
                        format: '{point.y:.2f} MB',
                        style: {
                            textOutline: 'none'
                        }
                    },
                    borderRadius: 6
                }
            },
            legend: {
                enabled: false
            },
            series: [{
                name: 'Storage Used',
                data: [
                    <?php foreach ($storageByUser as $user): ?>
                        <?= round($user['total_size'] / 1048576, 2) ?>,
                    <?php endforeach; ?>
                ],
                color: '#10b981'
            }]
        });

        // 4. User Role Distribution Chart
        <?php
        $stmt = $conn->query("SELECT role, COUNT(*) as count FROM users GROUP BY role");
        $roleData = $stmt->fetchAll();
        ?>
        Highcharts.chart('userRoleChart', {
            chart: {
                type: 'pie'
            },
            title: {
                text: null
            },
            tooltip: {
                pointFormat: '<b>{point.y} users</b> ({point.percentage:.1f}%)'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.percentage:.1f}%',
                        style: {
                            color: '#f9fafb',
                            textOutline: 'none'
                        }
                    },
                    showInLegend: true,
                    borderColor: 'rgba(17, 24, 39, 0.6)',
                    borderWidth: 2
                }
            },
            series: [{
                name: 'Users',
                colorByPoint: true,
                data: [
                    <?php foreach ($roleData as $role): ?>
                        {
                            name: '<?= ucfirst($role['role']) ?>',
                            y: <?= $role['count'] ?>,
                            color: '<?= $role['role'] === 'admin' ? '#ef4444' : '#3b82f6' ?>'
                        },
                    <?php endforeach; ?>
                ]
            }]
        });
    </script>
</body>
</html>>
                    </div>
                    <div class="text-center mt-3">
                        <a href="users.php" class="btn-primary-custom">View All Users</a>
                    </div>
                </div>

                <!-- Recent Files -->
                <div class="content-card">
                    <h5 class="card-title">
                        <i class="bi bi-files"></i> Recent Files
                    </h5>
                    <div class="table-responsive">
                        <table class="table-custom">
                            <thead>
                                <tr>
                                    <th>Filename</th>
                                    <th>Owner</th>
                                    <th>Size</th>
                                    <th>Encrypted</th>
                                    <th>Uploaded</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentFiles as $file): ?>
                                <tr>
                                    <td>
                                        <i class="bi bi-file-earmark" style="color: var(--accent-blue); margin-right: 0.5rem;"></i>
                                        <?= htmlspecialchars($file['original_name']) ?>
                                    </td>
                                    <td>@<?= htmlspecialchars($file['username']) ?></td>
                                    <td><?= formatFileSize($file['file_size']) ?></td>
                                    <td>
                                        <?php if ($file['encrypted']): ?>
                                            <span class="badge-custom badge-warning"><i class="bi bi-lock"></i> Yes</span>
                                        <?php else: ?>
                                            <span class="badge-custom badge-info">No</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d M Y', strtotime($file['uploaded_at'])) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table