<?php
require_once 'config.php';

$message = '';
$success = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE verification_token = ? AND email_verified = 0");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Verifikasi email
            $stmt = $conn->prepare("UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?");
            $stmt->execute([$user['id']]);
            
            $message = 'Email berhasil diverifikasi! Anda akan diarahkan ke halaman login...';
            $success = true;
            
            // Redirect ke login setelah 3 detik
            header("refresh:3;url=login.php?verified=1");
        } else {
            $message = 'Token verifikasi tidak valid atau email sudah diverifikasi.';
        }
    } catch(PDOException $e) {
        $message = 'Terjadi kesalahan: ' . $e->getMessage();
    }
} else {
    $message = 'Token verifikasi tidak ditemukan.';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Email - FlowNet Storage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            overflow: hidden;
            position: relative;
        }
        
        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        
        .bg-animation span {
            position: absolute;
            display: block;
            width: 20px;
            height: 20px;
            background: rgba(59, 130, 246, 0.1);
            animation: float 25s infinite;
            border-radius: 50%;
        }
        
        .bg-animation span:nth-child(1) {
            left: 10%;
            width: 80px;
            height: 80px;
            animation-delay: 0s;
            animation-duration: 20s;
        }
        
        .bg-animation span:nth-child(2) {
            left: 20%;
            width: 50px;
            height: 50px;
            animation-delay: 2s;
            animation-duration: 25s;
        }
        
        .bg-animation span:nth-child(3) {
            left: 40%;
            width: 60px;
            height: 60px;
            animation-delay: 4s;
            animation-duration: 22s;
        }
        
        .bg-animation span:nth-child(4) {
            left: 60%;
            width: 70px;
            height: 70px;
            animation-delay: 6s;
            animation-duration: 28s;
        }
        
        .bg-animation span:nth-child(5) {
            left: 80%;
            width: 40px;
            height: 40px;
            animation-delay: 8s;
            animation-duration: 24s;
        }
        
        @keyframes float {
            0% {
                top: -100px;
                transform: translateX(0) rotate(0deg);
                opacity: 1;
            }
            100% {
                top: 120vh;
                transform: translateX(100px) rotate(720deg);
                opacity: 0;
            }
        }
        
        /* Container */
        .verify-container {
            position: relative;
            z-index: 1;
            max-width: 500px;
            width: 100%;
            padding: 2rem;
        }
        
        /* Card */
        .verify-card {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 20px;
            padding: 3rem 2rem;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            animation: slideUp 0.5s ease-out;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Logo */
        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
            margin-bottom: 2rem;
        }
        
        .logo i {
            font-size: 2.5rem;
            color: #60a5fa;
        }
        
        .logo span {
            font-size: 2rem;
            font-weight: 700;
            color: #e0e6ed;
        }
        
        /* Status Icon */
        .status-icon {
            width: 120px;
            height: 120px;
            margin: 0 auto 2rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            animation: scaleIn 0.5s ease-out 0.3s both;
        }
        
        @keyframes scaleIn {
            from {
                transform: scale(0);
            }
            to {
                transform: scale(1);
            }
        }
        
        .status-icon.success {
            background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(34, 197, 94, 0.1));
            border: 3px solid #22c55e;
        }
        
        .status-icon.error {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(239, 68, 68, 0.1));
            border: 3px solid #ef4444;
        }
        
        .status-icon i {
            font-size: 4rem;
        }
        
        .status-icon.success i {
            color: #4ade80;
        }
        
        .status-icon.error i {
            color: #f87171;
        }
        
        /* Checkmark Animation */
        .checkmark {
            position: absolute;
            width: 100%;
            height: 100%;
        }
        
        .checkmark::before,
        .checkmark::after {
            content: '';
            position: absolute;
            background: #22c55e;
            border-radius: 2px;
        }
        
        .status-icon.success .checkmark::before {
            width: 4px;
            height: 30px;
            left: 50%;
            top: 35%;
            transform: translateX(-50%) rotate(45deg);
            animation: checkmark-left 0.3s ease-out 0.5s both;
        }
        
        .status-icon.success .checkmark::after {
            width: 4px;
            height: 50px;
            left: 52%;
            top: 38%;
            transform: translateX(-50%) rotate(-45deg);
            animation: checkmark-right 0.3s ease-out 0.7s both;
        }
        
        @keyframes checkmark-left {
            from { height: 0; }
            to { height: 30px; }
        }
        
        @keyframes checkmark-right {
            from { height: 0; }
            to { height: 50px; }
        }
        
        /* Title */
        h3 {
            font-size: 1.75rem;
            font-weight: 700;
            color: #e0e6ed;
            margin-bottom: 1rem;
        }
        
        .status-icon.success ~ h3 {
            color: #4ade80;
        }
        
        .status-icon.error ~ h3 {
            color: #f87171;
        }
        
        /* Message */
        .message {
            color: #94a3b8;
            font-size: 1rem;
            line-height: 1.6;
            margin-bottom: 2rem;
        }
        
        /* Button */
        .btn-login {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            border: none;
            color: #fff;
            padding: 0.875rem 2rem;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
            color: #fff;
        }
        
        /* Loading Spinner */
        .spinner {
            width: 40px;
            height: 40px;
            margin: 1rem auto;
            border: 4px solid rgba(59, 130, 246, 0.2);
            border-top-color: #3b82f6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Countdown */
        .countdown {
            display: inline-block;
            background: rgba(59, 130, 246, 0.1);
            color: #60a5fa;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            margin-top: 1rem;
        }
        
        /* Responsive */
        @media (max-width: 576px) {
            .verify-card {
                padding: 2rem 1.5rem;
            }
            
            .logo span {
                font-size: 1.5rem;
            }
            
            .status-icon {
                width: 100px;
                height: 100px;
            }
            
            h3 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Animated Background -->
    <div class="bg-animation">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>

    <div class="verify-container">
        <div class="verify-card">
            <!-- Logo -->
            <div class="logo">
                <i class="bi bi-cloud-arrow-down-fill"></i>
                <span>FlowNet</span>
            </div>
            
            <!-- Status Icon -->
            <div class="status-icon <?= $success ? 'success' : 'error' ?>">
                <?php if ($success): ?>
                    <i class="bi bi-check-circle-fill"></i>
                    <div class="checkmark"></div>
                <?php else: ?>
                    <i class="bi bi-x-circle-fill"></i>
                <?php endif; ?>
            </div>
            
            <!-- Title -->
            <h3><?= $success ? 'Verifikasi Berhasil!' : 'Verifikasi Gagal' ?></h3>
            
            <!-- Message -->
            <p class="message"><?= $message ?></p>
            
            <?php if ($success): ?>
                <!-- Countdown -->
                <div class="countdown">
                    <i class="bi bi-clock"></i> Redirect dalam <span id="countdown">3</span> detik...
                </div>
                <div class="spinner"></div>
            <?php endif; ?>
            
            <!-- Button -->
            <div>
                <a href="login.php" class="btn-login">
                    <i class="bi bi-box-arrow-in-right"></i> 
                    Ke Halaman Login
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <?php if ($success): ?>
    <script>
        // Countdown timer
        let timeLeft = 3;
        const countdownEl = document.getElementById('countdown');
        
        const timer = setInterval(() => {
            timeLeft--;
            countdownEl.textContent = timeLeft;
            
            if (timeLeft <= 0) {
                clearInterval(timer);
            }
        }, 1000);
    </script>
    <?php endif; ?>
</body>
</html>