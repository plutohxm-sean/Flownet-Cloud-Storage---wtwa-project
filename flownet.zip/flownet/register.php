<?php
require_once 'config.php';
require_once 'mailer.php';

$error = '';
$success = '';

// reCAPTCHA secret (server-side)
// Lebih aman: definisikan RECAPTCHA_SECRET di config.php:
// define('RECAPTCHA_SECRET', 'your-secret');
// lalu kode berikut otomatis pakai nilai itu.
$recaptcha_secret = defined('RECAPTCHA_SECRET') ? RECAPTCHA_SECRET : '6LdXhB4sAAAAACN9lJctB6_VZOJKoyP1FSk0cUUH';

// SITE KEY untuk client (dipakai di form)
$recaptcha_sitekey = '6LdXhB4sAAAAAOk2Db-EoZ7MzMdpXhmxLEtlbWH4';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $gRecaptchaResponse = $_POST['g-recaptcha-response'] ?? '';

    // Validasi input
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($full_name)) {
        $error = 'Semua field harus diisi!';
    } elseif (strlen($username) < 3) {
        $error = 'Username minimal 3 karakter!';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error = 'Username hanya boleh mengandung huruf, angka, dan underscore!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid!';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter!';
    } elseif ($password !== $confirm_password) {
        $error = 'Password tidak cocok!';
    } elseif (empty($gRecaptchaResponse)) {
        $error = 'Harap centang reCAPTCHA.';
    } else {
        // Verifikasi reCAPTCHA di server sebelum registrasi
        $verifyUrl = 'https://www.google.com/recaptcha/api/siteverify';
        $data = [
            'secret' => $recaptcha_secret,
            'response' => $gRecaptchaResponse,
            'remoteip' => $_SERVER['REMOTE_ADDR']
        ];

        $ch = curl_init($verifyUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        $verifyResponse = curl_exec($ch);
        $curlErr = curl_error($ch);
        curl_close($ch);

        if ($verifyResponse === false || !empty($curlErr)) {
            $error = 'Gagal memverifikasi CAPTCHA. Silakan coba lagi.';
        } else {
            $respJson = json_decode($verifyResponse, true);
            if (empty($respJson) || !isset($respJson['success']) || $respJson['success'] !== true) {
                // optionally log $respJson['error-codes']
                $error = 'CAPTCHA tidak valid. Silakan ulangi.';
            } else {
                // reCAPTCHA OK — lanjut registrasi
                try {
                    // Cek apakah username sudah ada
                    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetch()) {
                        $error = 'Username sudah digunakan!';
                    } else {
                        // Cek apakah email sudah ada
                        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
                        $stmt->execute([$email]);
                        if ($stmt->fetch()) {
                            $error = 'Email sudah terdaftar!';
                        } else {
                            // Generate verification token
                            $verificationToken = generateToken(32);

                            // Hash password (gunakan fungsi hashPassword di config.php)
                            $hashedPassword = hashPassword($password);

                            // Insert user
                            $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, verification_token, email_verified, created_at) VALUES (?, ?, ?, ?, ?, 0, NOW())");
                            $stmt->execute([$username, $email, $hashedPassword, $full_name, $verificationToken]);

                            $userId = $conn->lastInsertId();

                            // Kirim email verifikasi
                            if (sendVerificationEmail($email, $username, $verificationToken)) {
                                $success = 'Registrasi berhasil! Email verifikasi telah dikirim ke ' . htmlspecialchars($email) . '. Silakan cek inbox atau folder spam Anda.';
                                logActivity($conn, $userId, 'register', 'New user registration - verification email sent');
                            } else {
                                $success = 'Registrasi berhasil! Namun gagal mengirim email verifikasi. Silakan gunakan <a href="resend_verification.php" style="color: #60a5fa; text-decoration: underline;">resend verification</a> untuk mengirim ulang.';
                                logActivity($conn, $userId, 'register', 'New user registration - email sending failed');
                            }
                        }
                    }
                } catch(PDOException $e) {
                    $error = 'Terjadi kesalahan sistem. Silakan coba lagi nanti.';
                    error_log("Registration error: " . $e->getMessage());
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - FlowNet Storage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        html {
            scroll-behavior: smooth;
        }
        
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
            background-size: 400% 400%;
            background-attachment: fixed;
            animation: gradientShift 15s ease infinite;
            color: #e0e6ed;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            min-height: 100vh;
            padding: 2rem 1rem;
            position: relative;
        }
        
        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 20% 50%, rgba(56, 189, 248, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(59, 130, 246, 0.05) 0%, transparent 50%);
            pointer-events: none;
            z-index: 0;
        }
        
        .register-container {
            width: 100%;
            max-width: 500px;
            position: relative;
            z-index: 1;
            margin: 0 auto;
        }
        
        .brand-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            color: #fff;
            text-decoration: none;
            margin-bottom: 2rem;
        }
        
        .brand-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .register-card {
            background: rgba(30, 41, 59, 0.9);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 16px;
            padding: 2.5rem;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            margin-bottom: 2rem;
        }
        
        .register-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .register-title {
            font-size: 1.75rem;
            font-weight: 700;
            color: #fff;
            margin-bottom: 0.5rem;
        }
        
        .register-subtitle {
            color: #94a3b8;
            font-size: 0.875rem;
        }
        
        .alert-modern {
            padding: 0.875rem 1rem;
            border-radius: 8px;
            border: 1px solid;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            font-size: 0.875rem;
        }
        
        .alert-danger-modern {
            background-color: rgba(248, 81, 73, 0.1);
            border-color: rgba(248, 81, 73, 0.3);
            color: #fca5a5;
        }
        
        .alert-success-modern {
            background-color: rgba(34, 197, 94, 0.1);
            border-color: rgba(34, 197, 94, 0.3);
            color: #86efac;
        }

        .alert-info-modern {
            background-color: rgba(59, 130, 246, 0.1);
            border-color: rgba(59, 130, 246, 0.3);
            color: #93c5fd;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
        }
        
        .form-label-modern {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: #cbd5e1;
            margin-bottom: 0.5rem;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .form-control-modern {
            width: 100%;
            padding: 0.75rem 1rem;
            padding-right: 2.5rem;
            font-size: 0.875rem;
            background: rgba(15, 23, 42, 0.7);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 8px;
            color: #e0e6ed;
            transition: all 0.2s;
        }
        
        .form-control-modern:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            background: rgba(15, 23, 42, 0.9);
        }
        
        .form-control-modern::placeholder {
            color: #64748b;
        }
        
        .input-icon {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 1rem;
            pointer-events: none;
        }
        
        .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 1rem;
            cursor: pointer;
            user-select: none;
            z-index: 10;
        }
        
        .password-toggle:hover {
            color: #94a3b8;
        }
        
        .password-strength {
            margin-top: 0.5rem;
            font-size: 0.75rem;
            display: none;
        }
        
        .password-strength.show {
            display: block;
        }
        
        .strength-meter {
            height: 4px;
            background: rgba(51, 65, 85, 0.6);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 0.5rem;
        }
        
        .strength-bar {
            height: 100%;
            transition: all 0.3s;
            border-radius: 2px;
        }
        
        .strength-weak { width: 33%; background: #f87171; }
        .strength-medium { width: 66%; background: #fbbf24; }
        .strength-strong { width: 100%; background: #34d399; }
        
        .password-match {
            font-size: 0.75rem;
            margin-top: 0.5rem;
            display: none;
        }
        
        .password-match.show {
            display: block;
        }
        
        .match-success {
            color: #86efac;
        }
        
        .match-error {
            color: #fca5a5;
        }
        
        .btn-modern {
            width: 100%;
            padding: 0.875rem 1rem;
            font-size: 0.875rem;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary-modern {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: #fff;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary-modern:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        
        .btn-primary-modern:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .register-footer {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid rgba(51, 65, 85, 0.6);
            font-size: 0.875rem;
            color: #94a3b8;
        }
        
        .register-footer a {
            color: #60a5fa;
            text-decoration: none;
            font-weight: 500;
        }
        
        .register-footer a:hover {
            text-decoration: underline;
        }
        
        /* Responsive */
        @media (max-width: 576px) {
            body {
                padding: 1rem 0.5rem;
            }
            
            .register-card {
                padding: 2rem 1.5rem;
            }
            
            .brand-logo {
                font-size: 1.25rem;
            }
            
            .brand-icon {
                width: 40px;
                height: 40px;
                font-size: 1.25rem;
            }
            
            .register-title {
                font-size: 1.5rem;
            }
        }
        
        @media (max-height: 700px) {
            body {
                padding: 1rem;
            }
            
            .register-card {
                padding: 1.5rem;
            }
            
            .form-group {
                margin-bottom: 1rem;
            }
            
            .register-header {
                margin-bottom: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <a href="login.php" class="brand-logo">
            <div class="brand-icon">
                <i class="bi bi-cloud-arrow-down-fill"></i>
            </div>
            FlowNet
        </a>
        
        <div class="register-card">
            <div class="register-header">
                <h1 class="register-title">Create Account</h1>
                <p class="register-subtitle">Join Flownet Drive to store and share your files</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert-modern alert-danger-modern">
                    <i class="bi bi-exclamation-circle-fill"></i>
                    <span><?= htmlspecialchars($error) ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert-modern alert-success-modern">
                    <i class="bi bi-check-circle-fill"></i>
                    <span><?= $success ?></span>
                </div>
                <div class="alert-modern alert-info-modern">
                    <i class="bi bi-info-circle"></i>
                    <span>Email tidak masuk? <a href="resend_verification.php" style="color: #93c5fd; text-decoration: underline;">Kirim ulang email verifikasi</a></span>
                </div>
            <?php endif; ?>
            
            <form method="POST" id="registerForm">
                <div class="form-group">
                    <label class="form-label-modern">FULL NAME</label>
                    <div class="input-wrapper">
                        <input type="text" class="form-control-modern" name="full_name" 
                               placeholder="tony stark" required 
                               value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
                        <i class="bi bi-person input-icon"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label-modern">USERNAME</label>
                    <div class="input-wrapper">
                        <input type="text" class="form-control-modern" name="username" 
                               placeholder="ironman" required pattern="[a-zA-Z0-9_]{3,}"
                               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                        <i class="bi bi-at input-icon"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label-modern">EMAIL</label>
                    <div class="input-wrapper">
                        <input type="email" class="form-control-modern" name="email" 
                               placeholder="your-email@example.com" required 
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                        <i class="bi bi-envelope input-icon"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label-modern">PASSWORD</label>
                    <div class="input-wrapper">
                        <input type="password" class="form-control-modern" name="password" 
                               id="password" placeholder="••••••••" required minlength="6">
                        <i class="bi bi-eye password-toggle" id="togglePassword"></i>
                    </div>
                    <div class="password-strength" id="passwordStrength">
                        <div class="strength-meter">
                            <div class="strength-bar" id="strengthBar"></div>
                        </div>
                        <span id="strengthText"></span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label-modern">CONFIRM PASSWORD</label>
                    <div class="input-wrapper">
                        <input type="password" class="form-control-modern" name="confirm_password" 
                               id="confirmPassword" placeholder="••••••••" required minlength="6">
                        <i class="bi bi-eye password-toggle" id="toggleConfirmPassword"></i>
                    </div>
                    <div class="password-match" id="passwordMatch"></div>
                </div>

                <!-- reCAPTCHA widget -->
                <div class="form-group" style="margin-top: .75rem; margin-bottom: .5rem;">
                    <!-- load client API above; sitekey disesuaikan -->
                    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                    <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars($recaptcha_sitekey) ?>"></div>
                </div>
                
                <button type="submit" class="btn-modern btn-primary-modern" id="submitBtn">
                    <i class="bi bi-person-plus"></i>
                    Create Account
                </button>
            </form>
            
            <div class="register-footer">
                <p>
                    Already have an account? <a href="login.php">Sign In</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        // Password visibility toggle
        document.getElementById('togglePassword')?.addEventListener('click', function() {
            const password = document.getElementById('password');
            const icon = this;
            if (!password) return;
            if (password.type === 'password') {
                password.type = 'text';
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            } else {
                password.type = 'password';
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            }
        });
        
        document.getElementById('toggleConfirmPassword')?.addEventListener('click', function() {
            const confirmPassword = document.getElementById('confirmPassword');
            const icon = this;
            if (!confirmPassword) return;
            if (confirmPassword.type === 'password') {
                confirmPassword.type = 'text';
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            } else {
                confirmPassword.type = 'password';
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            }
        });
        
        // Password strength checker
        document.getElementById('password')?.addEventListener('input', function() {
            const password = this.value;
            const strengthDiv = document.getElementById('passwordStrength');
            const strengthBar = document.getElementById('strengthBar');
            const strengthText = document.getElementById('strengthText');
            
            if (!strengthDiv || !strengthBar || !strengthText) return;
            
            if (password.length === 0) {
                strengthDiv.classList.remove('show');
                strengthBar.className = 'strength-bar';
                strengthText.textContent = '';
                return;
            }
            
            strengthDiv.classList.add('show');
            
            let strength = 0;
            if (password.length >= 6) strength++;
            if (password.length >= 10) strength++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            if (/\d/.test(password)) strength++;
            if (/[^a-zA-Z0-9]/.test(password)) strength++;
            
            // reset classes
            strengthBar.className = 'strength-bar';
            
            if (strength <= 2) {
                strengthBar.classList.add('strength-weak');
                strengthText.textContent = 'Weak password';
                strengthText.style.color = '#f87171';
            } else if (strength <= 3) {
                strengthBar.classList.add('strength-medium');
                strengthText.textContent = 'Medium password';
                strengthText.style.color = '#fbbf24';
            } else {
                strengthBar.classList.add('strength-strong');
                strengthText.textContent = 'Strong password';
                strengthText.style.color = '#34d399';
            }
            
            checkPasswordMatch();
        });
        
        // Password match checker
        document.getElementById('confirmPassword')?.addEventListener('input', checkPasswordMatch);
        
        function checkPasswordMatch() {
            const passwordEl = document.getElementById('password');
            const confirmEl = document.getElementById('confirmPassword');
            const matchDiv = document.getElementById('passwordMatch');
            const submitBtn = document.getElementById('submitBtn');
            if (!matchDiv || !submitBtn) return;
            
            const password = passwordEl ? passwordEl.value : '';
            const confirmPassword = confirmEl ? confirmEl.value : '';
            
            if (confirmPassword.length === 0) {
                matchDiv.classList.remove('show');
                matchDiv.innerHTML = '';
                submitBtn.disabled = false;
                return;
            }
            
            matchDiv.classList.add('show');
            
            if (password === confirmPassword) {
                matchDiv.innerHTML = '<i class="bi bi-check-circle-fill"></i> Passwords match';
                matchDiv.className = 'password-match show match-success';
                submitBtn.disabled = false;
            } else {
                matchDiv.innerHTML = '<i class="bi bi-x-circle-fill"></i> Passwords do not match';
                matchDiv.className = 'password-match show match-error';
                submitBtn.disabled = true;
            }
        }

        // Optional: prevent multiple submit while recaptcha not ready (basic)
        document.getElementById('registerForm')?.addEventListener('submit', function(e) {
            // If you want extra client-side checks you can add here.
            // Keep submission default to let server validate reCAPTCHA and inputs.
        });
    </script>
</body>
</html>
