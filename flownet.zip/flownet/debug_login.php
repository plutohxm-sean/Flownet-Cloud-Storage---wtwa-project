<?php
require_once 'config.php';

// Debugging Login System
$debug_results = [];
$username_test = 'admin';
$password_test = 'admin123';

// Test 1: Cek koneksi database
try {
    $conn->query("SELECT 1");
    $debug_results['database'] = ['status' => 'success', 'message' => 'Database connection OK'];
} catch(PDOException $e) {
    $debug_results['database'] = ['status' => 'error', 'message' => $e->getMessage()];
}

// Test 2: Cek apakah user admin ada
try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username_test]);
    $user = $stmt->fetch();
    
    if ($user) {
        $debug_results['user_exists'] = [
            'status' => 'success', 
            'message' => 'User admin ditemukan',
            'data' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role'],
                'email_verified' => $user['email_verified'],
                'password_hash' => substr($user['password'], 0, 50) . '...'
            ]
        ];
        
        // Test 3: Verify password
        if (password_verify($password_test, $user['password'])) {
            $debug_results['password'] = ['status' => 'success', 'message' => 'Password COCOK! Login seharusnya berhasil'];
        } else {
            $debug_results['password'] = [
                'status' => 'error', 
                'message' => 'Password TIDAK COCOK dengan hash di database',
                'solution' => 'Hash password perlu di-update'
            ];
            
            // Generate hash baru
            $new_hash = password_hash($password_test, PASSWORD_BCRYPT);
            $debug_results['new_hash'] = [
                'status' => 'info',
                'hash' => $new_hash,
                'query' => "UPDATE users SET password = '{$new_hash}' WHERE username = 'admin';"
            ];
        }
        
        // Test 4: Email verification
        if ($user['email_verified'] == 1 || $user['role'] === 'admin') {
            $debug_results['email_verified'] = ['status' => 'success', 'message' => 'Email verification OK'];
        } else {
            $debug_results['email_verified'] = ['status' => 'error', 'message' => 'Email belum diverifikasi'];
        }
        
    } else {
        $debug_results['user_exists'] = ['status' => 'error', 'message' => 'User admin TIDAK ditemukan di database'];
    }
} catch(PDOException $e) {
    $debug_results['user_exists'] = ['status' => 'error', 'message' => $e->getMessage()];
}

// Test 5: Cek function verifyPassword
if (function_exists('verifyPassword')) {
    $debug_results['function_verify'] = ['status' => 'success', 'message' => 'Function verifyPassword() tersedia'];
} else {
    $debug_results['function_verify'] = ['status' => 'error', 'message' => 'Function verifyPassword() TIDAK ditemukan!'];
}

// Test 6: Session
if (session_status() === PHP_SESSION_ACTIVE) {
    $debug_results['session'] = ['status' => 'success', 'message' => 'Session aktif'];
} else {
    $debug_results['session'] = ['status' => 'warning', 'message' => 'Session belum aktif'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FlowNet - Login Debug Tool</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .header h1 {
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #666;
            font-size: 14px;
        }
        
        .test-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .test-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .test-icon {
            font-size: 32px;
        }
        
        .test-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin-left: auto;
        }
        
        .status-success {
            background: #d4edda;
            color: #155724;
        }
        
        .status-error {
            background: #f8d7da;
            color: #721c24;
        }
        
        .status-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-info {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .test-content {
            color: #555;
            line-height: 1.6;
        }
        
        .data-table {
            width: 100%;
            margin-top: 10px;
            border-collapse: collapse;
        }
        
        .data-table td {
            padding: 8px;
            border-bottom: 1px solid #eee;
        }
        
        .data-table td:first-child {
            font-weight: bold;
            width: 150px;
            color: #667eea;
        }
        
        .code-block {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 15px;
            border-radius: 5px;
            margin-top: 10px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            overflow-x: auto;
            white-space: pre-wrap;
            word-break: break-all;
        }
        
        .solution-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-top: 10px;
            border-radius: 5px;
        }
        
        .solution-box h4 {
            color: #856404;
            margin-bottom: 10px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 15px;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        
        .copy-btn {
            background: #28a745;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            margin-top: 10px;
        }
        
        .copy-btn:hover {
            background: #218838;
        }
        
        .summary {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .summary h3 {
            color: #333;
            margin-bottom: 15px;
        }
        
        .summary-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            margin: 5px 0;
            background: #f8f9fa;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 FlowNet Login Debug Tool</h1>
            <p>Tool untuk mengidentifikasi masalah login admin</p>
        </div>
        
        <?php foreach ($debug_results as $key => $result): ?>
            <div class="test-card">
                <div class="test-header">
                    <div class="test-icon">
                        <?php
                        $icons = [
                            'database' => '🗄️',
                            'user_exists' => '👤',
                            'password' => '🔑',
                            'email_verified' => '✉️',
                            'function_verify' => '⚙️',
                            'session' => '🍪',
                            'new_hash' => '🔐'
                        ];
                        echo $icons[$key] ?? '📋';
                        ?>
                    </div>
                    <div class="test-title">
                        <?php
                        $titles = [
                            'database' => 'Database Connection',
                            'user_exists' => 'User Admin Exists',
                            'password' => 'Password Verification',
                            'email_verified' => 'Email Verification',
                            'function_verify' => 'Function Check',
                            'session' => 'Session Status',
                            'new_hash' => 'New Password Hash'
                        ];
                        echo $titles[$key] ?? ucfirst(str_replace('_', ' ', $key));
                        ?>
                    </div>
                    <span class="status-badge status-<?php echo $result['status']; ?>">
                        <?php echo strtoupper($result['status']); ?>
                    </span>
                </div>
                
                <div class="test-content">
                    <p><strong>Result:</strong> <?php echo $result['message']; ?></p>
                    
                    <?php if (isset($result['data'])): ?>
                        <table class="data-table">
                            <?php foreach ($result['data'] as $field => $value): ?>
                                <tr>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $field)); ?>:</td>
                                    <td><?php echo htmlspecialchars($value); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    <?php endif; ?>
                    
                    <?php if (isset($result['solution'])): ?>
                        <div class="solution-box">
                            <h4>💡 Solusi:</h4>
                            <p><?php echo $result['solution']; ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($result['hash'])): ?>
                        <p><strong>Generated Hash:</strong></p>
                        <div class="code-block" id="hash-<?php echo $key; ?>"><?php echo htmlspecialchars($result['hash']); ?></div>
                        <button class="copy-btn" onclick="copyToClipboard('hash-<?php echo $key; ?>')">📋 Copy Hash</button>
                    <?php endif; ?>
                    
                    <?php if (isset($result['query'])): ?>
                        <p><strong>SQL Query untuk Fix:</strong></p>
                        <div class="code-block" id="query-<?php echo $key; ?>"><?php echo htmlspecialchars($result['query']); ?></div>
                        <button class="copy-btn" onclick="copyToClipboard('query-<?php echo $key; ?>')">📋 Copy Query</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
        
        <div class="summary">
            <h3>📊 Summary & Next Steps</h3>
            
            <?php
            $has_error = false;
            foreach ($debug_results as $result) {
                if ($result['status'] === 'error') {
                    $has_error = true;
                    break;
                }
            }
            
            if (!$has_error && isset($debug_results['password']) && $debug_results['password']['status'] === 'success'):
            ?>
                <div class="summary-item" style="background: #d4edda; color: #155724;">
                    <span style="font-size: 24px;">✅</span>
                    <strong>Semua test PASSED! Login admin seharusnya berfungsi dengan baik.</strong>
                </div>
                <p style="margin-top: 15px; color: #666;">
                    Jika masih belum bisa login, kemungkinan masalah ada di:<br>
                    • File login.php belum di-update<br>
                    • Cache browser (coba hard refresh: Ctrl + F5)<br>
                    • Session yang masih tersimpan (coba hapus cookies)
                </p>
            <?php else: ?>
                <div class="summary-item" style="background: #f8d7da; color: #721c24;">
                    <span style="font-size: 24px;">❌</span>
                    <strong>Ada masalah yang perlu diperbaiki</strong>
                </div>
                <p style="margin-top: 15px; color: #666;">
                    Lihat detail di atas dan ikuti solusi yang diberikan.
                </p>
            <?php endif; ?>
            
            <div style="margin-top: 20px;">
                <a href="login.php" class="btn">🔐 Coba Login Sekarang</a>
                <a href="?refresh=1" class="btn" style="background: #6c757d;">🔄 Refresh Test</a>
            </div>
        </div>
    </div>
    
    <script>
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            const text = element.textContent;
            
            navigator.clipboard.writeText(text).then(() => {
                alert('✅ Berhasil di-copy ke clipboard!');
            }).catch(err => {
                console.error('Failed to copy:', err);
            });
        }
    </script>
</body>
</html>