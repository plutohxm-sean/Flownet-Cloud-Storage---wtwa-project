<?php
session_start();

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FlowNet - Modern Cloud Storage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background: #1e293b;
            color: #e0e6ed;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans', Helvetica, Arial, sans-serif;
            line-height: 1.6;
        }
        
        /* Navbar */
        .navbar-modern {
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(51, 65, 85, 0.6);
            padding: 1rem 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: 600;
            color: #fff !important;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .brand-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }
        
        .nav-link {
            color: #94a3b8 !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            transition: all 0.2s;
            border-radius: 6px;
        }
        
        .nav-link:hover {
            color: #e0e6ed !important;
            background-color: rgba(51, 65, 85, 0.6);
        }
        
        .btn-outline-modern {
            color: #60a5fa;
            border: 1px solid rgba(59, 130, 246, 0.5);
            background-color: transparent;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s;
        }
        
        .btn-outline-modern:hover {
            background-color: rgba(59, 130, 246, 0.1);
            border-color: #60a5fa;
            color: #60a5fa;
        }
        
        .btn-primary-modern {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: #fff;
            border: none;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.2s;
        }
        
        .btn-primary-modern:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }
        
        /* Hero Section */
        .hero-section {
            padding: 120px 0 100px;
            text-align: center;
            background: linear-gradient(180deg, #1e293b 0%, rgba(30, 41, 59, 0.8) 100%);
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 20% 30%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(56, 189, 248, 0.1) 0%, transparent 50%);
            pointer-events: none;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
        }
        
        .hero-badge {
            display: inline-block;
            background: rgba(59, 130, 246, 0.1);
            border: 1px solid rgba(59, 130, 246, 0.3);
            color: #60a5fa;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.875rem;
            font-weight: 600;
            margin-bottom: 2rem;
        }
        
        .hero-section h1 {
            font-size: 4rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            background: linear-gradient(135deg, #fff, #cbd5e1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .hero-section .lead {
            font-size: 1.25rem;
            color: #94a3b8;
            margin-bottom: 2.5rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn-hero {
            padding: 1rem 2.5rem;
            font-size: 1.125rem;
            border-radius: 10px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            transition: all 0.3s;
        }
        
        /* Stats Section */
        .stats-section {
            background: rgba(15, 23, 42, 0.6);
            padding: 80px 0;
            border-top: 1px solid rgba(51, 65, 85, 0.6);
            border-bottom: 1px solid rgba(51, 65, 85, 0.6);
        }
        
        .stat-box {
            text-align: center;
            padding: 2rem;
            background: rgba(30, 41, 59, 0.6);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 16px;
            transition: all 0.3s;
            height: 100%;
        }
        
        .stat-box:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 32px rgba(0,0,0,0.4);
            border-color: rgba(59, 130, 246, 0.5);
        }
        
        .stat-icon {
            font-size: 3.5rem;
            color: #60a5fa;
            margin-bottom: 1.5rem;
        }
        
        .stat-box h5 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.75rem;
            color: #e0e6ed;
        }
        
        .stat-box p {
            color: #94a3b8;
            margin: 0;
        }
        
        /* Features Section */
        .features-section {
            padding: 100px 0;
            background: #1e293b;
        }
        
        .section-title {
            text-align: center;
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 4rem;
            color: #e0e6ed;
        }
        
        .feature-card {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(51, 65, 85, 0.6);
            border-radius: 16px;
            padding: 2.5rem;
            text-align: center;
            transition: all 0.3s;
            height: 100%;
        }
        
        .feature-card:hover {
            transform: translateY(-12px);
            box-shadow: 0 16px 40px rgba(0,0,0,0.5);
            border-color: rgba(59, 130, 246, 0.5);
        }
        
        .feature-icon {
            font-size: 3.5rem;
            color: #60a5fa;
            margin-bottom: 1.5rem;
        }
        
        .feature-card h4 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #e0e6ed;
        }
        
        .feature-card p {
            color: #94a3b8;
            margin: 0;
        }
        
        /* About Section */
        .about-section {
            padding: 100px 0;
            background: rgba(15, 23, 42, 0.6);
            border-top: 1px solid rgba(51, 65, 85, 0.6);
        }
        
        .about-section h2 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #e0e6ed;
        }
        
        .about-section .lead {
            font-size: 1.25rem;
            color: #94a3b8;
            margin-bottom: 1.5rem;
        }
        
        .tech-list {
            list-style: none;
            padding: 0;
        }
        
        .tech-list li {
            padding: 0.875rem 0;
            font-size: 1.125rem;
            color: #94a3b8;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .tech-list i {
            color: #22c55e;
            font-size: 1.5rem;
        }
        
        .about-icon {
            font-size: 15rem;
            color: #60a5fa;
            opacity: 0.7;
        }
        
        /* CTA Section */
        .cta-section {
            padding: 100px 0;
            text-align: center;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(37, 99, 235, 0.1) 100%);
            border-top: 1px solid rgba(59, 130, 246, 0.3);
        }
        
        .cta-section h2 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #e0e6ed;
        }
        
        .cta-section p {
            font-size: 1.25rem;
            margin-bottom: 2.5rem;
            color: #94a3b8;
        }
        
        .btn-cta {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: #fff;
            padding: 1.25rem 3rem;
            font-size: 1.25rem;
            border-radius: 12px;
            font-weight: 600;
            border: none;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .btn-cta:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 32px rgba(59, 130, 246, 0.4);
        }
        
        /* Footer */
        .footer {
            background: rgba(15, 23, 42, 0.95);
            border-top: 1px solid rgba(51, 65, 85, 0.6);
            padding: 3rem 0;
            text-align: center;
        }
        
        .footer p {
            margin: 0.5rem 0;
            color: #94a3b8;
        }
        
        .footer small {
            color: #64748b;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2.5rem;
            }
            
            .section-title {
                font-size: 2rem;
            }
            
            .about-icon {
                font-size: 8rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-modern">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <div class="brand-icon">
                    <i class="bi bi-cloud-arrow-down-fill"></i>
                </div>
                FlowNet
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" style="background-color: rgba(51, 65, 85, 0.6); border: 1px solid rgba(71, 85, 105, 0.6);">
                <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item ms-2">
                        <a class="btn-outline-modern" href="login.php">
                            <i class="bi bi-box-arrow-in-right"></i> Sign In
                        </a>
                    </li>
                    <li class="nav-item ms-2">
                        <a class="btn-primary-modern" href="register.php">
                            <i class="bi bi-person-plus"></i> Get Started
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container hero-content">
            <div class="hero-badge">
                <i class="bi bi-lightning-charge-fill"></i> Modern Cloud Storage
            </div>
            <h1>Secure Your Files<br>Store with Confidence</h1>
            <p class="lead">FlowNet provides enterprise-grade cloud storage with military-level encryption. Store, share, and access your files from anywhere, anytime.</p>
            <div class="hero-buttons">
                <a href="register.php" class="btn-primary-modern btn-hero">
                    <i class="bi bi-rocket-takeoff"></i> Start Free
                </a>
                <a href="login.php" class="btn-outline-modern btn-hero">
                    <i class="bi bi-box-arrow-in-right"></i> Sign In
                </a>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-icon">
                            <i class="bi bi-shield-fill-check"></i>
                        </div>
                        <h5>Secure & Encrypted</h5>
                        <p>Military-grade AES-256 encryption protects your files</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-icon">
                            <i class="bi bi-share-fill"></i>
                        </div>
                        <h5>Easy Sharing</h5>
                        <p>Share files with full access control and permissions</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-icon">
                            <i class="bi bi-lightning-charge-fill"></i>
                        </div>
                        <h5>Lightning Fast</h5>
                        <p>Upload and download at maximum speed without limits</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features-section">
        <div class="container">
            <h2 class="section-title">Powerful Features</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="bi bi-cloud-upload-fill feature-icon"></i>
                        <h4>File Upload</h4>
                        <p>Upload files up to 50MB with support for all popular file formats</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="bi bi-lock-fill feature-icon"></i>
                        <h4>End-to-End Encryption</h4>
                        <p>Protect sensitive files with military-grade encryption technology</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="bi bi-people-fill feature-icon"></i>
                        <h4>File Sharing</h4>
                        <p>Share files with other users and manage access permissions easily</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="bi bi-download feature-icon"></i>
                        <h4>Fast Download</h4>
                        <p>Download your files anytime with optimal speed and reliability</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="bi bi-envelope-check-fill feature-icon"></i>
                        <h4>Email Verification</h4>
                        <p>Account security with automatic email verification system</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="bi bi-activity feature-icon"></i>
                        <h4>Activity Logs</h4>
                        <p>Monitor and track all your file activities in real-time</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2>About FlowNet</h2>
                    <p class="lead">FlowNet is a modern cloud storage platform built with focus on simplicity, security, and high performance.</p>
                    <p style="color: #94a3b8;">Built using cutting-edge technologies and best practices in web development, FlowNet provides a secure, fast, and reliable file storage solution for both personal and business needs.</p>
                    <ul class="tech-list mt-4">
                        <li><i class="bi bi-check-circle-fill"></i> Modern UI with Bootstrap & Custom CSS</li>
                        <li><i class="bi bi-check-circle-fill"></i> Backend Logic with PHP 8+</li>
                        <li><i class="bi bi-check-circle-fill"></i> MySQL Database with PDO</li>
                        <li><i class="bi bi-check-circle-fill"></i> AES-256 Encryption for Maximum Security</li>
                        <li><i class="bi bi-check-circle-fill"></i> Email Integration with SMTP</li>
                    </ul>
                </div>
                <div class="col-md-6 text-center">
                    <i class="bi bi-cloud-check-fill about-icon"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <h2>Ready to Get Started?</h2>
            <p>Sign up now and get free access to our cloud storage platform!</p>
            <a href="register.php" class="btn-cta">
                <i class="bi bi-rocket-takeoff"></i> Get Started Free
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Sean Antonio Tarigan. FlowNet - Workshop Teknologi Web dan Aplikasi TRI.</p>
            <small>Built with modern web technologies • PHP • MySQL • Bootstrap</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>