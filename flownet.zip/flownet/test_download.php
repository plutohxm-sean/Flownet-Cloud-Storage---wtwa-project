<?php
// Test download dengan path absolut
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    die("Please login first");
}

echo "<h2>Download Path Test</h2>";
echo "<style>
    body { background: #1e293b; color: #e0e6ed; font-family: monospace; padding: 2rem; }
    .success { color: #4ade80; }
    .error { color: #f87171; }
    pre { background: #0f172a; padding: 1rem; border-radius: 4px; }
</style>";

$userId = $_SESSION['user_id'];

// Get files
$stmt = $conn->prepare("SELECT * FROM files WHERE user_id = ? LIMIT 5");
$stmt->execute([$userId]);
$files = $stmt->fetchAll();

if (empty($files)) {
    echo "<p class='error'>No files found for user ID: $userId</p>";
    exit;
}

echo "<h3>Files for User ID: $userId</h3>";
echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>ID</th><th>Filename</th><th>Path in DB</th><th>Full Path</th><th>Exists?</th><th>Readable?</th><th>Action</th></tr>";

foreach ($files as $file) {
    $baseDir = __DIR__;
    $relPath = $file['file_path'];
    $fullPath = $baseDir . '/' . $relPath;
    $exists = file_exists($fullPath);
    $readable = $exists ? is_readable($fullPath) : false;
    
    echo "<tr>";
    echo "<td>{$file['id']}</td>";
    echo "<td>" . htmlspecialchars($file['original_name']) . "</td>";
    echo "<td><code>$relPath</code></td>";
    echo "<td><code>$fullPath</code></td>";
    echo "<td>" . ($exists ? "<span class='success'>✓ Yes</span>" : "<span class='error'>✗ No</span>") . "</td>";
    echo "<td>" . ($readable ? "<span class='success'>✓ Yes</span>" : "<span class='error'>✗ No</span>") . "</td>";
    echo "<td>";
    
    if ($exists && $readable) {
        echo "<a href='test_download.php?download={$file['id']}' style='color: #4ade80;'>Download Test</a>";
    } else {
        echo "<span class='error'>Cannot download</span>";
    }
    
    echo "</td>";
    echo "</tr>";
}

echo "</table>";

// Handle download
if (isset($_GET['download'])) {
    $fileId = $_GET['download'];
    
    $stmt = $conn->prepare("SELECT * FROM files WHERE id = ? AND user_id = ?");
    $stmt->execute([$fileId, $userId]);
    $file = $stmt->fetch();
    
    if ($file) {
        $baseDir = __DIR__;
        $filePath = $baseDir . '/' . $file['file_path'];
        
        if (file_exists($filePath) && is_readable($filePath)) {
            // If encrypted, decrypt
            if ($file['encrypted']) {
                $tempFile = sys_get_temp_dir() . '/' . uniqid() . '_' . basename($file['original_name']);
                
                try {
                    decryptFile($filePath, $tempFile, $file['encryption_key']);
                    $downloadPath = $tempFile;
                } catch (Exception $e) {
                    die("Decryption error: " . $e->getMessage());
                }
            } else {
                $downloadPath = $filePath;
            }
            
            // Send file
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file['original_name']) . '"');
            header('Content-Length: ' . filesize($downloadPath));
            
            readfile($downloadPath);
            
            // Cleanup
            if ($file['encrypted'] && isset($tempFile) && file_exists($tempFile)) {
                unlink($tempFile);
            }
            
            exit;
        } else {
            echo "<p class='error'>File not accessible: $filePath</p>";
        }
    } else {
        echo "<p class='error'>File not found in database</p>";
    }
}

echo "<hr>";
echo "<h3>Debug Info</h3>";
echo "<pre>";
echo "Base Directory: " . __DIR__ . "\n";
echo "User ID: " . $userId . "\n";
echo "Session Info: " . print_r($_SESSION, true);
echo "</pre>";
?>